--░█████╗░░██████╗██╗░░░██╗░█████╗░███╗░░██╗
--██╔══██╗██╔════╝╚██╗░██╔╝██╔══██╗████╗░██║
--██║░░╚═╝╚█████╗░░╚████╔╝░██║░░██║██╔██╗██║
--██║░░██╗░╚═══██╗░░╚██╔╝░░██║░░██║██║╚████║
--╚█████╔╝██████╔╝░░░██║░░░╚█████╔╝██║░╚███║
--░╚════╝░╚═════╝░░░░╚═╝░░░░╚════╝░╚═╝░░╚══╝
function CheckOnlineVersion()
	major, minor, build, patch = menu.get_game_version()
	if build ~= 3095 then
		main = menu.add_submenu("⚠The game current version is: "..major.."."..minor.."."..build.."."..patch)
		main:add_submenu("Game updated!!!")
		main:add_submenu("The sctipt is outdated!!!")
	end
end
CheckOnlineVersion()
require_game_build(3095) -- GTA Online version 1.68

local function Texterrrsgg(text)
	mainMenu4:add_action(text,  function() end)
end

local function Text1(text)
	Online:add_action(text,  function() end)
end

local function Text(text)
	Offlinex64:add_action(text,  function() end)
end

local function Text(text)
	Offlinex64:add_submenu(text,  function() end)
end

local function Text3(text)
	menu.add_action(text,  function() end)
end

-- get the right variable prefix
if stats.get_int("MPPLY_LAST_MP_CHAR") == 0 then
  MPX = "MP0_"
else
  MPX = "MP1_"
end

function MPX()return stats.get_int("MPPLY_LAST_MP_CHAR")end

local function MPX()
	return "MP" .. stats.get_int("MPPLY_LAST_MP_CHAR") .. "_"
end
--------------------------------------------------------------------------------------------------------

mainMenu4 = menu.add_submenu("【 CSYON 】 SubMenu E4")

Texterrrsgg("**************************************************************************")
Texterrrsgg("            ** CSYON SubMenu 1.68 **                  ")
Texterrrsgg("                               **✅ V19 **                   ")
Texterrrsgg("            ** ⚠️Game Build Version 3095⚠️ **                  ")
Texterrrsgg("**************************************************************************")
--------------------------------------------------------------------------------------------------------
Online= mainMenu4:add_submenu("🚨 Csyon Submenu")
--------------------------------------------------------------------------------------------------------
mainMenu4:add_action("------------------------------------------------------", function() end)
Offlinex64 = mainMenu4:add_submenu("          	**💬 Read Me 💬**                        ")
mainMenu4:add_action("------------------------------------------------------", function() end)
--------------------------------------------------------------------------------------------------------
CSYON167 = Online:add_submenu("🚗Vehicle Features")
CSYON168 = Online:add_submenu("🛩️🚁🚗Services Requests")
CSYON24 = Online:add_submenu("🚗Tuning?")
CSYON387 = Online:add_submenu("🎲Casino Options")
CSYON212 = Online:add_submenu("⚠info for help")
--------------------------------------------------------------------------------------------------------

Offlinex6333t = Offlinex64:add_submenu("                        **🔽 Credits 🔼**                        ")

Text ("                        ** CSYON **                        ")
Text ("                        ** Thanks for Support my work**                        ")
Text ("                        ** Thanks to all for lua scripts sharing**                        ")
Text ("                        ** on Unknowncheats**                        ")


Text("**********************************************************")

Text("          🐨 UKC : CSYON")

Text("🐨 Warning : you are not allowed Copying and selling this script")

Text("**********************************************************")

Text("   🐨 Discord Server :")
Text("   🐨 https://discord.gg/JaCvtj6yQK")


Text("**********************************************************")

Text("   Download Vote in UKC A+  ")
Text("   thanks for Support  ")

Text("**********************************************************")
--------------------------------------------------------------------------------------------------------
--CSYONS167 = CSYON167:add_submenu("🚗 Vehicles options or Features? ")
CSYONS168 = CSYON168:add_submenu("🛩️🚁🚗Services Requests?")
CSYONS24 = CSYON24:add_submenu("🚗Tuning?")
CSYONS387 = CSYON387:add_submenu("🎰Casino Features? ")
CSYONS212 = CSYON212:add_submenu("⚠ReadMe")
--------------------------------------------------------------------------------------------------------

CSYONS212:add_action("***********************************************************", function() end)
CSYONS212:add_action("for Help join my Discord Server", function() end)
CSYONS212:add_action("https://discord.gg/JaCvtj6yQK", function() end)
CSYONS212:add_action("***********************************************************", function() end)
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------
lolGlobal = 27237
lolGlobal2 = 27238
CrazyGlobal = 262145
csyonnn = 0
	CSYONS387:add_int_range("Acquire Chips Limit", 50000, 0, 2147483646,
		function()
			return csyonnn
		end,
		function(ACL)
			globals.set_int(CrazyGlobal + lolGlobal, ACL)
			globals.set_int(CrazyGlobal + lolGlobal2, ACL)
			csyonnn = ACL
		end)
--------------------------------------------------------------------------------------------------------
		local function PlayerID()
			return globals.get_int(2672761)
			--return ped:get_player_id()
		end

LWCC = 278 + 14 -- casino master lucky wheel win state local
CCLW = 278 + 45 -- casino master lucky wheel prize state local
CasinoLuckyWheel = script("casino_lucky_wheel")
prize_ids = {
			-1, -- Nothing
			0, -- Clothing 1
			8, -- Clothing 2
			12, -- Clothing 3
			16, -- Clothing 4
			1, -- 2,500 RP
			5, -- 5,000 RP
			9, -- 7,500 RP
			13, -- 10,000 RP
			17, -- 15,000 RP
			2, -- $20,000
			6, -- $30,000
			14, -- $40,000
			19, -- $50,000
			3, -- 10,000 Chips
			7, -- 15,000 Chips
			10, -- 20,000 Chips
			15, -- 25,000 Chips
			4, -- Discount
			11, -- Mystery
			18, -- Vehicle
			}
			prize_names = {
			"Select",
			"Clothing 1",
			"Clothing 2",
			"Clothing 3",
			"Clothing 4",
			"2,500 RP",
			"5,000 RP",
			"7,500 RP",
			"10,000 RP",
			"15,000 RP",
			"$20,000",
			"$30,000",
			"$40,000",
			"$50,000",
			"10,000 Chips",
			"15,000 Chips",
			"20,000 Chips",
			"25,000 Chips",
			"Discount",
			"Mystery",
			"Vehicle"
			}

			Csyon = 1
	CSYONS387:add_array_item("Select Prize (before «S»)", prize_names,
		function()
			return Csyon
		end,
		function(SelLuckyPrize)
			LuckyWheelCasino = 117 + 1 + (PlayerID() * 5)
			if CasinoLuckyWheel:get_int(LuckyWheelCasino) ~= -1 then
				Csyon = SelLuckyPrize
				CasinoLuckyWheel:set_int(LuckyWheelCasino, prize_ids[Csyon])
			end
		end)

			csyon = 1
	CSYONS387:add_array_item("⚠ Give Prize", prize_names, function()
			return csyon
		end,
		function(GiveLuckyPrize)
			csyon = GiveLuckyPrize
			CasinoLuckyWheel:set_int(LWCC, prize_ids[csyon])
            CasinoLuckyWheel:set_int(CCLW, 11)
			csyon = 1
		end)

CSYONS387:add_action("Reset Casino Chip Purchase", function() stats.set_int("MPPLY_CASINO_CHIPS_PUR_GD", 0) stats.set_int("MPPLY_CASINO_CHIPS_PURTIM", 0) end)

--------------------------------------------------------------------------------------------------------
Suspension = CSYONS24:add_submenu("Suspension")
Traction = CSYONS24:add_submenu("Traction")
Roll_Bar = CSYONS24:add_submenu("Roll Bar")
--------------------------------------------------------------------------------------------------------
Suspension:add_float_range("Front Bias", 0.01, 0.0, 1.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_bias_front()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_bias_front(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Suspension:add_float_range("Force", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_force()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_force(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Suspension:add_float_range("Height", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_height()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_height(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Suspension:add_float_range("Lower Limit", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_lower_limit()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_lower_limit(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Suspension:add_float_range("Upper Limit", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_upper_limit()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_upper_limit(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Suspension:add_float_range("Raise", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_raise()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_raise(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Suspension:add_float_range("Compression Damping", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_comp_damp()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_comp_damp(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Suspension:add_float_range("Rebound Damping", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_rebound_damp()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_rebound_damp(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Traction:add_float_range("Front Bias", 0.01, 0.0, 1.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_traction_bias_front()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_traction_bias_front(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Traction:add_float_range("Lateral Curve", 0.01, 0.0, 1.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_traction_curve_lateral()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_traction_curve_lateral(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Traction:add_float_range("Maximum Curve", 0.01, 0.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_traction_curve_max()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_traction_curve_max(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Traction:add_float_range("Minimum Curve", 0.01, 0.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_traction_curve_min()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_traction_curve_min(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Traction:add_float_range("Loss Multiplier", 0.01, 0.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_traction_loss_multiplier()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_traction_loss_multiplier(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Traction:add_float_range("Max Spring Delta", 0.01, 0.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_traction_spring_delta_max()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_traction_spring_delta_max(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Roll_Bar:add_float_range("Front Bias", 0.01, 0.0, 1.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_anti_roll_bar_bias_front()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_anti_roll_bar_bias_front(value)
	end
end)
--------------------------------------------------------------------------------------------------------
Roll_Bar:add_float_range("Force", 0.01, 0.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_anti_roll_bar_force()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_anti_roll_bar_force(value)
	end
end)
--------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------
CSYONS168:add_action("Spawn Avenger", function() menu.deliver_avenger() end)
CSYONS168:add_action("Spawn Kosatska", function() menu.deliver_kosatka() end)
CSYONS168:add_action("Spawn Mobile Command Center", function() menu.deliver_moc() end)
CSYONS168:add_action("Spawn Terrorbyte", function() menu.deliver_terrorbyte() end)
CSYONS168:add_action("Deliver Kosatka Avisa Submarine", function() menu.deliver_avisa() end)
CSYONS168:add_action("Deliver Kosatka Dinghy", function() menu.deliver_dinghy() end)
CSYONS168:add_action("Deliver Kostaka Sea Sparrow", function() menu.deliver_seasparrow() end)

CSYONS168:add_action("Request Acid delivery bike", function() globals.set_int(2738587 + 994, 1) end)
CSYONS168:add_action("Request Ballistic Armor", function() globals.set_int(2738587 + 901, 1) end)
CSYONS168:add_action("Request Ammo Drop", function() globals.set_int(2738587 + 891, 1) end)
CSYONS168:add_action("Become Ballistic Armor Directly", function() globals.set_int(2738587 + 902, 1) end)
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
CSYONS167 = CSYON167:add_submenu("Wheels Mod Section")
--------------------------------------------------------------------------------------------------------
F1Mod = false
OldF1Hash = 0
CSYONS167:add_toggle("F1 - Covers", function()
	return F1Mod
end, function()
	F1Mod = not F1Mod
	if F1Mod then
		if localplayer ~= nil then
			if localplayer:is_in_vehicle() then
				OldF1Hash = localplayer:get_current_vehicle():get_model_hash()
				localplayer:get_current_vehicle():set_model_hash(1492612435)
			end
		end
	else
		if localplayer ~= nil then
			if localplayer:is_in_vehicle() then
				localplayer:get_current_vehicle():set_model_hash(OldF1Hash)
			end
		end
	end
end)
--------------------------------------------------------------------------------------------------------
F1Mod = false
OldF1Hash = 0
CSYONS167:add_toggle("F1 - Covers v2", function()
return F1Mod
end, function()
F1Mod = not F1Mod
if F1Mod then
if localplayer ~= nil then
if localplayer:is_in_vehicle() then
OldF1Hash = localplayer:get_current_vehicle():get_model_hash()
localplayer:get_current_vehicle():set_model_hash(1492612435)
end
end
else
if localplayer ~= nil then
if localplayer:is_in_vehicle() then
localplayer:get_current_vehicle():set_model_hash(OldF1Hash)
end
end
end
end)
--------------------------------------------------------------------------------------------------------
BennyMod = false
OldBennyHash = 0
CSYONS167:add_toggle("Bennys - Covers", function()
return BennyMod
end, function()
BennyMod = not BennyMod
if BennyMod then
if localplayer ~= nil then
if localplayer:is_in_vehicle() then
OldBennyHash = localplayer:get_current_vehicle():get_model_hash()
localplayer:get_current_vehicle():set_model_hash(196747873)
end
end
else
if localplayer ~= nil then
if localplayer:is_in_vehicle() then
localplayer:get_current_vehicle():set_model_hash(OldBennyHash)
end
end
end
end)
--------------------------------------------------------------------------------------------------------
BennyMod = false
OldBennyHash = 0
CSYONS167:add_toggle("Bennys - Covers", function()
	return BennyMod
end, function()
	BennyMod = not BennyMod
	if BennyMod then
		if localplayer ~= nil then
			if localplayer:is_in_vehicle() then
				OldBennyHash = localplayer:get_current_vehicle():get_model_hash()
				localplayer:get_current_vehicle():set_model_hash(196747873)
			end
		end
	else
		if localplayer ~= nil then
			if localplayer:is_in_vehicle() then
				localplayer:get_current_vehicle():set_model_hash(OldBennyHash)
			end
		end
	end
end)
--------------------------------------------------------------------------------------------------------
CSYONS167 = CSYON167:add_submenu("Custom Plate")
--------------------------------------------------------------------------------------------------------
PlateChar = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", ""}
PI1 = PlateChar[1]
PI1Current = 1
CSYONS167:add_array_item("Char #1", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI1Current
	end
end, function(value)
	PI1 = PlateChar[value]
	PI1Current = value
end)
--------------------------------------------------------------------------------------------------------
PI2 = PlateChar[1]
PI2Current = 1
CSYONS167:add_array_item("Char #2", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI2Current
	end
end, function(value)
	PI2 = PlateChar[value]
	PI2Current = value
end)
--------------------------------------------------------------------------------------------------------
PI3 = PlateChar[1]
PI3Current = 1
CSYONS167:add_array_item("Char #3", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI3Current
	end
end, function(value)
	PI3 = PlateChar[value]
	PI3Current = value
end)
--------------------------------------------------------------------------------------------------------
PI4 = PlateChar[1]
PI4Current = 1
CSYONS167:add_array_item("Char #4", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI4Current
	end
end, function(value)
	PI4 = PlateChar[value]
	PI4Current = value
end)
--------------------------------------------------------------------------------------------------------
PI5 = PlateChar[1]
PI5Current = 1
CSYONS167:add_array_item("Char #5", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI5Current
	end
end, function(value)
	PI5 = PlateChar[value]
	PI5Current = value
end)
--------------------------------------------------------------------------------------------------------
PI6 = PlateChar[1]
PI6Current = 1
CSYONS167:add_array_item("Char #6", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI6Current
	end
end, function(value)
	PI6 = PlateChar[value]
	PI6Current = value
end)
--------------------------------------------------------------------------------------------------------
PI7 = PlateChar[1]
PI7Current = 1
CSYONS167:add_array_item("Char #7", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI7Current
	end
end, function(value)
	PI7 = PlateChar[value]
	PI7Current = value
end)
--------------------------------------------------------------------------------------------------------
PI8 = PlateChar[1]
PI8Current = 1
CSYONS167:add_array_item("Char #8", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI8Current
	end
end, function(value)
	PI8 = PlateChar[value]
	PI8Current = value
end)
--------------------------------------------------------------------------------------------------------
CSYONS167:add_bare_item("", function()
	return "Apply plate: " .. PI1 .. PI2 .. PI3 .. PI4 .. PI5 .. PI6 .. PI7 .. PI8
end, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		localplayer:get_current_vehicle():set_number_plate_text(PI1 .. PI2 .. PI3 .. PI4 .. PI5 .. PI6 .. PI7 .. PI8)
	end
end, function()
end, function()
end)
--------------------------------------------------------------------------------------------------------
CSYONS167:add_toggle("Horn E",function()return Horn end,function(v)
	Horn=v if v then menu.send_key_down(69)else menu.send_key_up(69)end end)
--------------------------------------------------------------------------------------------------------
--menu.register_hotkey(45, carBoost) --Insert key
menu.register_hotkey(45, function()return carBoost end) --- Insert key
--------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------
--functions for carboost
local cars_data = {}
local multiplier_percent = 100
local function boostVehicle(vehicle_data, hash, vehicle, boost)
	if boost then --boost mode
		accel = vehicle_data[1] * (17 * (multiplier_percent / 100))
		brake_force = vehicle_data[2] * (23 * (multiplier_percent / 100))
		gravity = 19.7
		handbrake_force = vehicle_data[4] * (14 * (multiplier_percent / 100))
		initial_drive_force = vehicle_data[5] * (690 * (multiplier_percent / 100))   --nice
		traction_min = 6 + (2 * (multiplier_percent / 100))   --very high traction. Used without roll_centre modification, the car will constantly flip
		traction_max = vehicle_data[7] + (2 * (multiplier_percent / 100))
		traction_bias_front = 0.420
		up_shift = 10000  --huge shift values, causing cars to get stuck in gear and accelerate rapidly
		down_shift = 10000
		max_flat_vel = 10000
		--mass_offset = vector3(0,2,1)  --puts the centre of mass up and in front of the car, making it more stable EDIT: actually this option is quite buggy, only gets applied on reload like vehicle_mass and causes cars to flip uncontrollably. Just gonna ignore it.
		collision_dmg_multiplier = 0
		engine_dmg_multiplier = 0
		if multiplier_percent >= 100 then
			--Dont increase the following roll_centre variables more than 100%. Makes things flip.
			multiplier_percent = 100
		end
		roll_centre_front = vehicle_data[15] + (0.300 * (multiplier_percent / 100)) --these two stop the car from rolling even at high speeds, it rolls inwards instead
		roll_centre_rear = vehicle_data[16] + (0.300 * (multiplier_percent	/ 100))
		drive_bias = 0.5   --all wheel drive
		traction_loss_mult = 1
		initial_drag_coeff = 1  --no drag forces
	else --restore mode
		accel = vehicle_data[1]
		brake_force = vehicle_data[2]
		gravity = vehicle_data[3]
		handbrake_force = vehicle_data[4]
		initial_drive_force = vehicle_data[5]
		traction_min = vehicle_data[6]
		traction_max = vehicle_data[7]
		traction_bias_front = vehicle_data[8]
		up_shift = vehicle_data[9]
		down_shift = vehicle_data[10]
		max_flat_vel = vehicle_data[11]
		--mass_offset = vehicle_data[12]
		collision_dmg_multiplier = vehicle_data[13]
		engine_dmg_multiplier = vehicle_data[14]
		roll_centre_front = vehicle_data[15]
		roll_centre_rear = vehicle_data[16]
		drive_bias = vehicle_data[17]
		traction_loss_mult = vehicle_data[18]
		initial_drag_coeff = vehicle_data[19]
	end
	
	vehicle:set_acceleration(accel)
	vehicle:set_brake_force(brake_force)
	vehicle:set_gravity(gravity)
	vehicle:set_handbrake_force(handbrake_force)
	vehicle:set_initial_drive_force(initial_drive_force)
	vehicle:set_traction_curve_min(traction_min)
	vehicle:set_traction_curve_max(traction_max)
	vehicle:set_traction_bias_front(traction_bias_front)
	vehicle:set_up_shift(up_shift)
	vehicle:set_down_shift(down_shift)
	vehicle:set_initial_drive_max_flat_velocity(max_flat_vel)
	--vehicle:set_centre_of_mass_offset(mass_offset)
	vehicle:set_roll_centre_height_front(roll_centre_front)
	vehicle:set_roll_centre_height_rear(roll_centre_rear)
	vehicle:set_drive_bias_front(drive_bias)
	vehicle:set_collision_damage_multiplier(collision_dmg_multiplier)
	vehicle:set_engine_damage_multiplier(engine_dmg_multiplier)
	vehicle:set_traction_loss_multiplier(traction_loss_mult)
	vehicle:set_initial_drag_coeff(initial_drag_coeff)
	vehicle:set_max_speed(10000)
end
 
local function reloadVehicle(vehicle)
	--Check if car has been found in the table, then restore, otherwise exit
	restore = cars_data[vehicle:get_model_hash()]
	if restore then
		boostVehicle(restore, vehicle:get_model_hash(), vehicle, false)
	end
end
 
--------------------------------
--boosted car handling logic, insert key
--------------------------------
function carBoost()
	if localplayer ~= nil and localplayer:is_in_vehicle() then 
		current = localplayer:get_current_vehicle()
		if current == nil then return end
 
		--check if car has been modified already by the modified gravity value, if not, try to save and modify it
		if current:get_gravity() ~= 19.7 then
			
			::retry::
			--Save car data to map if its not in there already
			if not cars_data[current:get_model_hash()] then
				cars_data[current:get_model_hash()] = {
					current:get_acceleration(),			--1
					current:get_brake_force(),			--2
					current:get_gravity(),				--3
					current:get_handbrake_force(),		--4
					current:get_initial_drive_force(),	--5
					current:get_traction_curve_min(),	--6
					current:get_traction_curve_max(),	--7
					current:get_traction_bias_front(),	--8
					current:get_up_shift(),				--9
					current:get_down_shift(),			--10
					current:get_initial_drive_max_flat_velocity(),	--11
					current:get_centre_of_mass_offset(),			--12
					current:get_collision_damage_multiplier(),		--13
					current:get_engine_damage_multiplier(),			--14
					current:get_roll_centre_height_front(),			--15	
					current:get_roll_centre_height_rear(),			--16
					current:get_drive_bias_front(),					--17
					current:get_traction_loss_multiplier(),			--18
					current:get_initial_drag_coeff()				--19
					}
			end
			
			--boost car if data has been read successfully
			boostVehicle(cars_data[current:get_model_hash()], current:get_model_hash(), current, true)
			
			--Check if the boost worked, else reload the vehicle object again and try once more
			--This is usually necessary when changing to a new car of the same type, or when the old one gets destroyed and called back
			if current:get_gravity() ~= 19.7 then
				cars_data[current:get_model_hash()] = nil
				goto retry
			end
		else
			reloadVehicle(current)
		end
	end
end
--------------------------------------------------------------------------------------------------------
CSYONS167:add_int_range("Car Boost strength |%", 5, 0, 690, function() return multiplier_percent end, function(value) multiplier_percent = value end)
CSYONS167:add_action("Reset all modified cars' handling", function()
	for hash, data in pairs(cars_data) do
		reloadVehicle(data[hash])
	end
end)
--------------------------------------------------------------------------------------------------------
menu.register_hotkey(110, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then 
		vehicle = localplayer:get_current_vehicle()
		grav = vehicle:get_gravity()
		vehicle:set_gravity(-50)
		sleep(0.2)
		vehicle:set_gravity(grav)
	end
end)
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action("Heal Vehicle", function()
	if localplayer == nil then
		return
	end
	
	current_vehicle = localplayer:get_current_vehicle()
	if current_vehicle ~= nil then
		if current_vehicle:get_health() < 1000 then
			current_vehicle:set_health(1000)
		end
	end
end)
--------------------------------------------------------------------------------------------------------
local heal_vehicle_on_change = false
CSYONS167:add_toggle("Heal Vehicle on Change", function() 
	return heal_vehicle_on_change 
end, function(value)
	heal_vehicle_on_change = value
end)
--------------------------------------------------------------------------------------------------------
CSYONS167 = CSYON167:add_submenu("🚗Car Features🚗")
local function superChargeVehicle()
	if localplayer == nil then
		return
	end
	
	current_vehicle = localplayer:get_current_vehicle()
		if current_vehicle ~= nil then
			current_vehicle:set_acceleration(1.59)
			current_vehicle:set_gravity(16.8)

		end
end
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action("Active Car Speed Hack", superChargeVehicle)
--------------------------------------------------------------------------------------------------------
CSYONS168:add_action("🚁 Request luxury Helicopter", function() menu.trigger_heli_vip_pickup() end)
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action("Destroy Vehicle", function() menu.kill_current_vehicle() end)
--------------------------------------------------------------------------------------------------------
CSYONS167sr=CSYON167:add_submenu("Speedometer")
local units_selection = 1
local units_text = {"kilometres per hour", "miles per hour", "metres per second"}
local units_text_short = {"km/h", "m/s", "mi/h"}
local units_text_numberplate = {"kmh", "mps", "mph"}
local units_value = {3.6, 1, 2.2369362921, 3.280839895}
local numberplate_enabled = false
local numberplate_key = {87, 65, 83, 68}-- W, A, S, D
local numberplate_ref = {}
--------------------------------------------------------------------------------------------------------
local function round(value, dec)
	dec = dec or 0
	return tonumber(string.format("%." .. dec .. "f", value))
end
 --------------------------------------------------------------------------------------------------------
local function get_vehicle_speed(veh)
	if not veh then return 0 end
	local velocity = veh:get_velocity()
	return math.sqrt(velocity.x ^ 2 + velocity.y ^ 2 + velocity.z ^ 2)
end
 --------------------------------------------------------------------------------------------------------
CSYONS167sr:add_toggle("Speed display on", function() return constantupdate  end, function(n) constantupdate = n  end)
 --------------------------------------------------------------------------------------------------------
CSYONS167sr:add_toggle("Speedometer Numberplates", function()
	return numberplate_enabled
end, function(value)
	numberplate_enabled = value
	if value then
		for i = 1, #numberplate_key do
			numberplate_ref[i] = menu.register_hotkey(numberplate_key[i], function()
				if not localplayer:is_in_vehicle() then return end
				local veh = localplayer:get_current_vehicle()
				if not veh then return end
				local speed = round(get_vehicle_speed(veh) * units_value[units_selection], 0)
				veh:set_number_plate_text((speed < 10 and "   " or speed < 100 and "  " or speed < 1000 and " " or "") .. speed .. " " .. units_text_numberplate[units_selection])
			end)
		end
	else
		for i = 1, #numberplate_ref do
			menu.remove_hotkey(numberplate_ref[i])
		end
	end
end)
 --------------------------------------------------------------------------------------------------------
CSYONS167sr:add_array_item("Speed unit", units_text, function()
	return units_selection
end, function(value)
	units_selection = value
end)
--------------------------------------------------------------------------------------------------------
CSYONS167sr:add_bare_item("Speed", function()
	if not localplayer:is_in_vehicle() then return "Speed: not in vehicle" end
	local veh = localplayer:get_current_vehicle()
	if not veh then return "Speed: invalid vehicle" end
	local speed = round(get_vehicle_speed(veh) * units_value[units_selection], 1)
	return "Speed: " .. speed .. " " .. units_text_short[units_selection]
end, function() end, function() end, function() end)
--------------------------------------------------------------------------------------------------------
CSYONS167:add_toggle("Vehicle God Mode", function()
	return vehiclegodmode
end, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
            localplayer:get_current_vehicle():set_godmode(true)
	end
end)
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action("Repair Vehicle", function() menu.repair_online_vehicle() end)
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action("Remove Insurance Claims", function() menu.remove_insurance_claims() end)
--------------------------------------------------------------------------------------------------------
CSYONS167i = CSYONS167:add_submenu("Call Vehicle from Mechanicer")
function s(x)		--sleep
for i=1,x*4*10^7 do end end
function gi(x,o)		--get or set a global variable
local i=globals.get_int(x) if o and o~=i then globals.set_int(x,o) end return i end
function wf(x,o,i,l)		--wait for a global variable
for x=1,100*x do x=gi(o) if l and x~=i or not l and x==i then return else s(0.01) end end end
gpv={2359980,1586468,2793343,2639791}
function spvx()		--get the current personal vehicle controller global variable
return gpv[2]+104+142*gi(gpv[1]) end
function spv(x,guarda)		
    if x then 
        if gi(gpv[3])~=-1 then 
            gi(spvx(),4)
            wf(5,gpv[3],-1)
        end
        gi(gpv[1],x)
    end
    if guarda  then --to know if he keeps the car or calls him
    --
    else
    menu.remove_insurance_claims()  --remove insurance 
    menu.deliver_personal_vehicle() -- call the personal vehicle 
	sleep(1)
	menu.enter_personal_vehicle()
    end
end
--------------------------------------------------------------------------------------------------------
h=menu.register_hotkey 
CSYONS167i:add_int_range("Personal vehicle number",
1,0,300,function() return gi(gpv[1]) end,spv)
h(97,function() spv() end) --Press num1 for spawn & enter current PV
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action("Vehicle in Fire for Explode", function() FireVeh() end)
function FireVeh()
	local vehicle = localplayer:get_current_vehicle()
	vehicle:set_health(-500)
end
--------------------------------------------------------------------------------------------------------
CSYONS167:add_toggle("Realistic Car Damage v2 Buggy", function() return RealCar end, function() RealCar = not RealCar (RealCar) end)
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action("Realistic Car Damage", function() RealCar() end)
function RealCar()
	local vehicle = localplayer:get_current_vehicle()
	vehicle:set_engine_damage_multiplier(800000)
	vehicle:set_deformation_damage_multiplier(800000)
	vehicle:set_collision_damage_multiplier(800000)
end
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action("resolve Vehicle", function() resolveCar(Vehicle()) end)
function resolveCar(Vehicle)
	local inCar = localplayer:is_in_vehicle()
	if inCar == true then
		VehP = Vehicle:get_position()
		VehR = Vehicle:get_rotation()
		VehP.z = VehP.z + 1
		VehR.y = 0
		VehR.z = 0
		Vehicle:set_position(VehP)
		Vehicle:set_rotation(VehR)
	end
end
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action("Retrieve Person Vehicle", function()  menu.retrieve_personal_vehicle() end)
--------------------------------------------------------------------------------------------------------
config = {
	use_metric = true
}
 
function display_online_vehicle_speed()
	if localplayer == nil then
		return
	end 
	
	local current_vehicle = localplayer:get_current_vehicle()
	if current_vehicle == nil or not localplayer:is_in_vehicle() then
		return
	end
	
	local velocity = current_vehicle:get_velocity()
	local mps = math.sqrt(velocity.x * velocity.x + velocity.y * velocity.y + velocity.z * velocity.z)
	
	if config['use_metric'] == true then 
		globals.set_string(2703735 + 2400 + 1 + 8, "AMCH_KMHN", 32)
		globals.set_int(2703735 + 2400 + 1 + 3, math.floor(mps * 3.6 + 0.5))
	else
		globals.set_string(2703735 + 2400 + 1 + 8, "AMCH_MPHN", 32)
		globals.set_int(2703735 + 2400 + 1 + 3, math.floor(mps * 0.6214 + 0.5))
	end
 
	globals.set_string(2703735 + 2400 + 1 + 21, "FM_AE_SORT_3", 16)
	globals.set_int(2703735 + 2400 + 1 + 1, 11)
	globals.set_int(2703735 + 2400 + 1 + 2, 1)
end
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action("Show current speed", display_online_vehicle_speed)
--------------------------------------------------------------------------------------------------------
CSYONS167:add_toggle("Automatically Repair Vehicle", function() return autorepairvehicle end, function(value) autorepairvehicle = value end) 
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action("Vehicle No Collision", function()
if localplayer:is_in_vehicle() then
   current_vehicle = localplayer:get_current_vehicle()
   vehicle:set_suspension_bias_front(-5)
   vehicle:set_suspension_comp_damp(-10)
   vehicle:set_suspension_force(-5)
   vehicle:set_suspension_height(-10)
   vehicle:set_suspension_lower_limit(-5)
   vehicle:set_suspension_raise(-10)
   vehicle:set_suspension_rebound_damp(-5)
   vehicle:set_suspension_upper_limit(-10)
   vehicle:set_drift_tyres_enabled(-5)
   vehicle:set_drift_vehicle_reduced_suspension(bool -10)
   end
end)
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action("Vehicle Max Speed", function()
if localplayer:is_in_vehicle() then
   current_vehicle = localplayer:get_current_vehicle()
   current_vehicle:set_max_speed(1000.00)
   end
end)
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action(" Return car garage", function() menu.deliver_personal_vehicle() end)
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action(" Get in your car", function() menu.enter_personal_vehicle() end)
--------------------------------------------------------------------------------------------------------
function hsvToRgb(h, s, v)
    local r, g, b
  
    local i = math.floor(h * 6);
    local f = h * 6 - i;
    local p = v * (1 - s);
    local q = v * (1 - f * s);
    local t = v * (1 - (1 - f) * s);
  
    i = i % 6
    if i == 0 then r, g, b = v, t, p
    elseif i == 1 then r, g, b = q, v, p
    elseif i == 2 then r, g, b = p, v, t
    elseif i == 3 then r, g, b = p, q, v
    elseif i == 4 then r, g, b = t, p, v
    elseif i == 5 then r, g, b = v, p, q
    end
  
    return math.floor(r * 255), math.floor(g * 255), math.floor(b * 255)
end
--------------------------------------------------------------------------------------------------------
b = false
s = 0.5
CSYONS167:add_toggle("Smooth Rainbow Car",function() return b end,function() b = not b menu.emit_event("Rainbow_Vehicle_Start") end)
--------------------------------------------------------------------------------------------------------
CSYONS167:add_float_range("Rainbow Speed", 0.1, 0.1, 2.0,function() return s end,function(v) s = v end)
--------------------------------------------------------------------------------------------------------
menu.register_callback("Rainbow_Vehicle_Start", function()
    t = 0
    while b == true do
        t=t+1
        p = localplayer
        v = p and p:get_current_vehicle() or nil
        if v then
            c_r,c_g,c_b = hsvToRgb(t/100 * s, 1, 1)
            v:set_custom_primary_colour(c_r,c_g,c_b)
            v:set_custom_secondary_colour(c_r,c_g,c_b)
        end
        sleep(0.01)
    end
end)
--------------------------------------------------------------------------------------------------------
local Plates={ "Csyon", "ADMIN", "ROCKSTAR", "Kiddion", "L7NEG", "Csyons", "CSYON", "Joker", "JOKER", "J0K3R", "joker" }
local function Veh() if localplayer:is_in_vehicle() then return localplayer:get_current_vehicle() else return nil end end
CSYONS167:add_array_item("Set Number Plate 🚘", Plates, function()
if Veh() then for x=1, #Plates do if Plates[x]==Veh():get_number_plate_text() then return x end end return 1 end end, function(t)
  if Veh() then Veh():set_number_plate_text(Plates[t]) end
end)
--------------------------------------------------------------------------------------------------------
--CSYONS167:add_toggle("Drift Mode",function() return driftmode,driftmodes end) --- Recommend use Futo or Kuruma
--------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------
optionnames = {"current_vehicle","acceleration","traction_curve_max","traction_curve_min","steering_lock","drift_tyres_enabled"}
vocalse = {0, 0.9, 0.6, 1.2, 60, true}
default = {}
driftmode = false
drifthotkeys = 105
--------------------------------------------------------------------------------------------------------
function driftmodes()
v=localplayer and localplayer:is_in_vehicle() and localplayer:get_current_vehicle() 
if v then 
	driftmode=not v:get_drift_tyres_enabled() 
	currentset={v} for i=2,#optionnames do currentset[i]=v["get_"..optionnames[i]](v) end 
	indefault=#default+1 for i=1,#default do if default[i][1]==v then indefault=i break end end 
	default[indefault]=default[indefault] or {v} for i=2,#vocalse do if currentset[i]~=vocalse[i] then default[indefault][i]=currentset[i] end end 
	set=driftmode and vocalse or default[indefault] 
	for i=2,#optionnames do if set[i] then v["set_"..optionnames[i]](v,set[i]) end end 
end end   
--------------------------------------------------------------------------------------------------------
   local function driftSuspension()
	if localplayer == nil then
		return
	end	
	current_vehicle = localplayer:get_current_vehicle()
		if current_vehicle ~= nil then
            current_vehicle:set_drift_vehicle_reduced_suspension(true)
		end
end
--------------------------------------------------------------------------------------------------------
CSYONS167:add_action("Drift Vehicle Reduced Suspension", driftSuspension)
menu.register_hotkey(105, driftSuspension) --numpad9
--------------------------------------------------------------------------------------------------------
   CsyonNM = false
	CSYONS167:add_toggle("Nitrous Mod (shift)", function() return CsyonNM end, function() CsyonNM = not CsyonNM ActivateNOOS(CsyonNM) end)

	--Nitrous Mod

		Csyonnm = false
		function NOOSBoost()
			if localplayer:is_in_vehicle() then
				if Csyonnm == false then
					menu.send_key_press(201)
					menu.send_key_press(200)
					menu.send_key_press(69)
					Csyonnm = true
				else
					menu.send_key_press(201)
					menu.send_key_press(200)
					Csyonnm = false
				end
			end
		end

		function ActivateNOOS(Enabled)
			if not localplayer:is_in_vehicle() then
				a2 = false
				return end
			if Enabled then
				nitroboost_hotkey1 = menu.register_hotkey(16, NOOSBoost)
			else
				menu.remove_hotkey(nitroboost_hotkey1)
			end
		end


--------------------------------------------------------------------------------------------------------
--CSYONS9:add_action("------------------------------------------------------", function() end)
----Vehicle Spawn Start
--CSYONS167ui = CSYON5:add_submenu("🚗Spawn Vehicles")
local CSYONS167ui = CSYON167:add_submenu("🚗 Vehicles Spawner")
local CurrentHash = nil
local SavedVehicles = 0
local vehicle = nil
--category
local CarSubBoat = CSYONS167ui:add_submenu("Boats🚤")
local CarSubCompacts = CSYONS167ui:add_submenu("Compacts🚗")
local CarSubCoupes = CSYONS167ui:add_submenu("Coupes🚗")
local CarSubCycles = CSYONS167ui:add_submenu("Cycles🚘")
local CarSubEmergency = CSYONS167ui:add_submenu("Emergency🚑")
local CarSubHelicopters = CSYONS167ui:add_submenu("Helicopters🚁")
local CarSubIndustrial = CSYONS167ui:add_submenu("Industrial🚛")
local CarSubMilitary = CSYONS167ui:add_submenu("Military🚓")
local CarSubMotorcycles = CSYONS167ui:add_submenu("Motorcycles🏍️")
local CarSubMuscle = CSYONS167ui:add_submenu("Muscle🚗")
local CarSubOffRoad = CSYONS167ui:add_submenu("Off-Road🚗")
local CarSubPlanes = CSYONS167ui:add_submenu("Planes✈️")
local CarSubSedans = CSYONS167ui:add_submenu("Sedans🚘")
local CarSubService = CSYONS167ui:add_submenu("Service🚕")
local CarSubSports = CSYONS167ui:add_submenu("Sports🚘")
local CarSubSuperSports = CSYONS167ui:add_submenu("Super Sports🚘")
local CarSubSUV = CSYONS167ui:add_submenu("SUVs🚚")
local CarSubUtility = CSYONS167ui:add_submenu("Utility🚗")
local CarSubVans = CSYONS167ui:add_submenu("Vans🚚")
local CarSubCommercial = CSYONS167ui:add_submenu("Commercial🚛")
local CarSubSuperVehicles = CSYONS167ui:add_submenu("Supervehicles🚘")
local CarSubSpecial = CSYONS167ui:add_submenu("Special Vehicles🏎️")
local CarSubSaves = CSYONS167ui:add_submenu("Saved Vehicles🚘🚗")
local Other = CSYONS167ui:add_submenu("Other Features🛺")
local Logs = Other:add_submenu("Logs📄")
Logs:add_action("Csyon SubMenu Loaded", function()sleep(0.1)end)

-- Vehicle Spawn System ()
function SpawnVehicle(Hash)
    local pos = localplayer:get_position()
    globals.set_int(2639889 + 46, Hash)
    globals.set_float(2639889 + 42, pos.x)
    globals.set_float(2639889 + 43, pos.y)
    globals.set_float(2639889 + 44, pos.z)
    globals.set_boolean(2639889 + 41, true)
    sleep(0.5)
    menu.send_key_press(70)
    Logs:add_action("Csyon's Vehicle Spawned" .. Hash, function()SpawnVehicle(Hash)end)
end
function SaveVehicle()
        vehicle = localplayer:get_current_vehicle()
        CurrentHash = vehicle:get_model_hash()
        SavedVehicles = SavedVehicles + 1
        CarSubSaves:add_action("Saved Vehicle #" .. SavedVehicles .. "| " .. CurrentHash,
         function()SpawnVehicle(CurrentHash)end)
        Logs:add_action("Vehicle Saved | " .. CurrentHash, function()SpawnVehicle(CurrentHash)end)
end
-- Saves
CarSubSaves:add_action("Save Vehicle", function()SaveVehicle()end)

--Vehicles  

-- Boats
CarSubBoat:add_action("Spawn Dinghy1", function()SpawnVehicle(1033245328)end)
CarSubBoat:add_action("Spawn Dinghy2", function()SpawnVehicle(276773164)end)
CarSubBoat:add_action("Spawn Dinghy3", function()SpawnVehicle(509498602)end)
CarSubBoat:add_action("Spawn Dinghy4", function()SpawnVehicle(867467158)end)
CarSubBoat:add_action("Spawn Jetmax", function()SpawnVehicle(861409633)end)
CarSubBoat:add_action("Spawn Marquis", function()SpawnVehicle(-1043459709)end)
CarSubBoat:add_action("Spawn SeaShark", function()SpawnVehicle(-1030275036)end)
CarSubBoat:add_action("Spawn SeaShark2", function()SpawnVehicle(-616331036)end)
CarSubBoat:add_action("Spawn SeaShark3", function()SpawnVehicle(-311022263)end)
CarSubBoat:add_action("Spawn Speeder", function()SpawnVehicle(231083307)end)
CarSubBoat:add_action("Spawn Speeder2", function()SpawnVehicle(437538602)end)
CarSubBoat:add_action("Spawn Squalo", function()SpawnVehicle(400514754)end)
CarSubBoat:add_action("Spawn Submersible", function()SpawnVehicle(771711535)end)
CarSubBoat:add_action("Spawn Submersible2", function()SpawnVehicle(-1066334226)end)
CarSubBoat:add_action("Spawn Suntrap", function()SpawnVehicle(-282946103)end)
CarSubBoat:add_action("Spawn Toro", function()SpawnVehicle(1070967343)end)
CarSubBoat:add_action("Spawn Toro2", function()SpawnVehicle(908897389)end)
CarSubBoat:add_action("Spawn Tropic", function()SpawnVehicle(290013743)end)
CarSubBoat:add_action("Spawn Tropic2", function()SpawnVehicle(1448677353)end)
CarSubBoat:add_action("Spawn Tug", function()SpawnVehicle(-2100640717)end)

-- Compacts
CarSubCompacts:add_action("Spawn Blista", function()SpawnVehicle(-344943009)end)
CarSubCompacts:add_action("Spawn Blista2", function()SpawnVehicle(1039032026)end)
CarSubCompacts:add_action("Spawn Blista3", function()SpawnVehicle(-591651781)end)
CarSubCompacts:add_action("Spawn Brioso", function()SpawnVehicle(1549126457)end)
CarSubCompacts:add_action("Spawn Dilettante", function()SpawnVehicle(-1130810103)end)
CarSubCompacts:add_action("Spawn Dilettante2", function()SpawnVehicle(1682114128)end)
CarSubCompacts:add_action("Spawn Issi2", function()SpawnVehicle(-1177863319)end)
CarSubCompacts:add_action("Spawn Panto", function()SpawnVehicle(-431692672)end)
CarSubCompacts:add_action("Spawn Prairie", function()SpawnVehicle(-1450650718)end)
CarSubCompacts:add_action("Spawn Rhapsody", function()SpawnVehicle(841808271)end)

-- Coupes
CarSubCoupes:add_action("Spawn CogCabrio", function()SpawnVehicle(330661258)end)
CarSubCoupes:add_action("Spawn Exemplar", function()SpawnVehicle(-5153954)end)
CarSubCoupes:add_action("Spawn F620", function()SpawnVehicle(-591610296)end)
CarSubCoupes:add_action("Spawn Felon", function()SpawnVehicle(-391594584)end)
CarSubCoupes:add_action("Spawn Felon2", function()SpawnVehicle(-89291282)end)
CarSubCoupes:add_action("Spawn Jackal", function()SpawnVehicle(-624529134)end)
CarSubCoupes:add_action("Spawn Kanjo", function()SpawnVehicle(64075878)end)
CarSubCoupes:add_action("Spawn Oracle", function()SpawnVehicle(1348744438)end)
CarSubCoupes:add_action("Spawn Oracle2", function()SpawnVehicle(-511601230)end)
CarSubCoupes:add_action("Spawn Postlude", function()SpawnVehicle(294678663)end)
CarSubCoupes:add_action("Spawn Sentinel", function()SpawnVehicle(1349725314)end)
CarSubCoupes:add_action("Spawn Sentinel2", function()SpawnVehicle(873639469)end)
CarSubCoupes:add_action("Spawn Windsor", function()SpawnVehicle(1581459400)end)
CarSubCoupes:add_action("Spawn Windsor2", function()SpawnVehicle(1930048799)end)
CarSubCoupes:add_action("Spawn Zion", function()SpawnVehicle(-1122289213)end)
CarSubCoupes:add_action("Spawn Zion2", function()SpawnVehicle(-1193103848)end)

-- Cycles
CarSubCycles:add_action("Spawn BMX", function()SpawnVehicle(1131912276)end)
CarSubCycles:add_action("Spawn Cruiser", function()SpawnVehicle(448402357)end)
CarSubCycles:add_action("Spawn Fixter", function()SpawnVehicle(-836512833)end)
CarSubCycles:add_action("Spawn Scorcher", function()SpawnVehicle(-186537451)end)
CarSubCycles:add_action("Spawn TriBike", function()SpawnVehicle(1127861609)end)
CarSubCycles:add_action("Spawn TriBike2", function()SpawnVehicle(-1233807380)end)
CarSubCycles:add_action("Spawn TriBike3", function()SpawnVehicle(-400295096)end)

-- Emergency
CarSubEmergency:add_action("Spawn Ambulance", function()SpawnVehicle(1171614426)end)
CarSubEmergency:add_action("Spawn FBI", function()SpawnVehicle(1127131465)end)
CarSubEmergency:add_action("Spawn FBI2", function()SpawnVehicle(-1647941228)end)
CarSubEmergency:add_action("Spawn FireTruck", function()SpawnVehicle(1938952078)end)
CarSubEmergency:add_action("Spawn PrisonBus", function()SpawnVehicle(-2007026063)end)
CarSubEmergency:add_action("Spawn Police", function()SpawnVehicle(2046537925)end)
CarSubEmergency:add_action("Spawn Police2", function()SpawnVehicle(-1627000575)end)
CarSubEmergency:add_action("Spawn Police3", function()SpawnVehicle(1912215274)end)
CarSubEmergency:add_action("Spawn Police4", function()SpawnVehicle(-1973172295)end)
CarSubEmergency:add_action("Spawn PoliceOld1", function()SpawnVehicle(-1536924937)end)
CarSubEmergency:add_action("Spawn PoliceOld2", function()SpawnVehicle(-1779120616)end)
CarSubEmergency:add_action("Spawn PoliceTransport", function()SpawnVehicle(456714581)end)
CarSubEmergency:add_action("Spawn PoliceBike", function()SpawnVehicle(-34623805)end)
CarSubEmergency:add_action("Spawn PoliceHelicopter", function()SpawnVehicle(353883353)end)
CarSubEmergency:add_action("Spawn ParkRanger", function()SpawnVehicle(741586030)end)
CarSubEmergency:add_action("Spawn Predator", function()SpawnVehicle(-488123221)end)
CarSubEmergency:add_action("Spawn Riot", function()SpawnVehicle(-1205689942)end)
CarSubEmergency:add_action("Spawn Sheriff", function()SpawnVehicle(-1683328900)end)
CarSubEmergency:add_action("Spawn Sheriff2", function()SpawnVehicle(1922257928)end)

-- Helicopters
CarSubHelicopters:add_action("Spawn Annihilator", function()SpawnVehicle(837858166)end)
CarSubHelicopters:add_action("Spawn Buzzard", function()SpawnVehicle(788747387)end)
CarSubHelicopters:add_action("Spawn Buzzard2", function()SpawnVehicle(745926877)end)
CarSubHelicopters:add_action("Spawn Cargobob", function()SpawnVehicle(-50547061)end)
CarSubHelicopters:add_action("Spawn Cargobob2", function()SpawnVehicle(1621617168)end)
CarSubHelicopters:add_action("Spawn Cargobob3", function()SpawnVehicle(1394036463)end)
CarSubHelicopters:add_action("Spawn Cargobob4", function()SpawnVehicle(2025593404)end)
CarSubHelicopters:add_action("Spawn Canoda", function()SpawnVehicle(-477831899)end)
CarSubHelicopters:add_action("Spawn Frogger", function()SpawnVehicle(744705981)end)
CarSubHelicopters:add_action("Spawn Frogger2", function()SpawnVehicle(1949211328)end)
CarSubHelicopters:add_action("Spawn Maverick", function()SpawnVehicle(-1660661558)end)
CarSubHelicopters:add_action("Spawn Savage", function()SpawnVehicle(-82626025)end)
CarSubHelicopters:add_action("Spawn Skylift", function()SpawnVehicle(1044954915)end)
CarSubHelicopters:add_action("Spawn Supervolito", function()SpawnVehicle(710198397)end)
CarSubHelicopters:add_action("Spawn Supervolito2", function()SpawnVehicle(-1671539132)end)
CarSubHelicopters:add_action("Spawn Swift", function()SpawnVehicle(-339587598)end)
CarSubHelicopters:add_action("Spawn Swift2", function()SpawnVehicle(1075432268)end)
CarSubHelicopters:add_action("Spawn Valkyrie", function()SpawnVehicle(-1600252419)end)
CarSubHelicopters:add_action("Spawn Valkyrie2", function()SpawnVehicle(1543134283)end)
CarSubHelicopters:add_action("Spawn Volatus", function()SpawnVehicle(-1845487887)end)

-- Industrial
CarSubIndustrial:add_action("Spawn Bulldozer", function()SpawnVehicle(1886712733)end)
CarSubIndustrial:add_action("Spawn Cutter", function()SpawnVehicle(-1006919392)end)
CarSubIndustrial:add_action("Spawn Dump", function()SpawnVehicle(-2130482718)end)
CarSubIndustrial:add_action("Spawn Flatbed", function()SpawnVehicle(1353720154)end)
CarSubIndustrial:add_action("Spawn Guardian", function()SpawnVehicle(-2107990196)end)
CarSubIndustrial:add_action("Spawn Handler", function()SpawnVehicle(444583674)end)
CarSubIndustrial:add_action("Spawn Mixer", function()SpawnVehicle(-784816453)end)
CarSubIndustrial:add_action("Spawn Mixer2", function()SpawnVehicle(475220373)end)
CarSubIndustrial:add_action("Spawn Rubble", function()SpawnVehicle(-1705304628)end)
CarSubIndustrial:add_action("Spawn TipTruck", function()SpawnVehicle(48339065)end)
CarSubIndustrial:add_action("Spawn TipTruck2", function()SpawnVehicle(-947761570)end)

-- Military
CarSubMilitary:add_action("Spawn APC", function()SpawnVehicle(562680400)end)
CarSubMilitary:add_action("Spawn Barracks", function()SpawnVehicle(-823509173)end)
CarSubMilitary:add_action("Spawn Barracks2", function()SpawnVehicle(1074326203)end)
CarSubMilitary:add_action("Spawn Barracks3", function()SpawnVehicle(630371791)end)
CarSubMilitary:add_action("Spawn Crusader", function()SpawnVehicle(321739290)end)
CarSubMilitary:add_action("Spawn Halftrack", function()SpawnVehicle(-32236122)end)
CarSubMilitary:add_action("Spawn Rhino", function()SpawnVehicle(782665360)end)
CarSubMilitary:add_action("Spawn Trailersmall2", function()SpawnVehicle(-1881846085)end)

-- Motorcycles
CarSubMotorcycles:add_action("Spawn Akuma", function()SpawnVehicle(1672195559)end)
CarSubMotorcycles:add_action("Spawn Avarus", function()SpawnVehicle(-2115793025)end)
CarSubMotorcycles:add_action("Spawn Bagger", function()SpawnVehicle(-2140431165)end)
CarSubMotorcycles:add_action("Spawn Bati2", function()SpawnVehicle(-891462355)end)
CarSubMotorcycles:add_action("Spawn Bati", function()SpawnVehicle(-114291515)end)
CarSubMotorcycles:add_action("Spawn BF400", function()SpawnVehicle(86520421)end)
CarSubMotorcycles:add_action("Spawn Blazer4", function()SpawnVehicle(-440768424)end)
CarSubMotorcycles:add_action("Spawn CarbonRS", function()SpawnVehicle(11251904)end)
CarSubMotorcycles:add_action("Spawn Chimera", function()SpawnVehicle(6774487)end)
CarSubMotorcycles:add_action("Spawn Cliffhanger", function()SpawnVehicle(390201602)end)
CarSubMotorcycles:add_action("Spawn Daemon2", function()SpawnVehicle(-1404136503)end)
CarSubMotorcycles:add_action("Spawn Daemon", function()SpawnVehicle(2006142190)end)
CarSubMotorcycles:add_action("Spawn Defiler", function()SpawnVehicle(822018448)end)
CarSubMotorcycles:add_action("Spawn Double", function()SpawnVehicle(-1670998136)end)
CarSubMotorcycles:add_action("Spawn Enduro", function()SpawnVehicle(1753414259)end)
CarSubMotorcycles:add_action("Spawn Esskey", function()SpawnVehicle(2035069708)end)
CarSubMotorcycles:add_action("Spawn Faggio", function()SpawnVehicle(-1842748181)end)
CarSubMotorcycles:add_action("Spawn Faggio2", function()SpawnVehicle(55628203)end)
CarSubMotorcycles:add_action("Spawn Faggio3", function()SpawnVehicle(-1289178744)end)
CarSubMotorcycles:add_action("Spawn Fcr2", function()SpawnVehicle(-757735410)end)
CarSubMotorcycles:add_action("Spawn Fcr", function()SpawnVehicle(627535535)end)
CarSubMotorcycles:add_action("Spawn Gargoyle", function()SpawnVehicle(741090084)end)
CarSubMotorcycles:add_action("Spawn Hakuchou2", function()SpawnVehicle(-255678177)end)
CarSubMotorcycles:add_action("Spawn Hakuchou", function()SpawnVehicle(1265391242)end)
CarSubMotorcycles:add_action("Spawn Hexer", function()SpawnVehicle(301427732)end)
CarSubMotorcycles:add_action("Spawn Innovation", function()SpawnVehicle(-159126838)end)
CarSubMotorcycles:add_action("Spawn Lectro", function()SpawnVehicle(640818791)end)
CarSubMotorcycles:add_action("Spawn Manchez", function()SpawnVehicle(-1523428744)end)
CarSubMotorcycles:add_action("Spawn Manchez2", function()SpawnVehicle(1384502824)end)
CarSubMotorcycles:add_action("Spawn Nemesis", function()SpawnVehicle(-634879114)end)
CarSubMotorcycles:add_action("Spawn Nightblade", function()SpawnVehicle(-1606187161)end)
CarSubMotorcycles:add_action("Spawn Oppressor", function()SpawnVehicle(884483972)end)
CarSubMotorcycles:add_action("Spawn OppressorMK2", function()SpawnVehicle(884483972)end)
CarSubMotorcycles:add_action("Spawn PCJ", function()SpawnVehicle(-909201658)end)
CarSubMotorcycles:add_action("Spawn Ratbike", function()SpawnVehicle(1873600305)end)
CarSubMotorcycles:add_action("Spawn Ruffian", function()SpawnVehicle(-893578776)end)
CarSubMotorcycles:add_action("Spawn Sanchez2", function()SpawnVehicle(-1453280962)end)
CarSubMotorcycles:add_action("Spawn Sanchez", function()SpawnVehicle(788045382)end)
CarSubMotorcycles:add_action("Spawn Sanctus", function()SpawnVehicle(1491277511)end)
CarSubMotorcycles:add_action("Spawn Shotaro", function()SpawnVehicle(-405626514)end)
CarSubMotorcycles:add_action("Spawn Sovereign", function()SpawnVehicle(743478836)end)
CarSubMotorcycles:add_action("Spawn Thrust", function()SpawnVehicle(1836027715)end)
CarSubMotorcycles:add_action("Spawn Vader", function()SpawnVehicle(-140902153)end)
CarSubMotorcycles:add_action("Spawn Vindicator", function()SpawnVehicle(-1353081087)end)
CarSubMotorcycles:add_action("Spawn Vortex", function()SpawnVehicle(-609625092)end)
CarSubMotorcycles:add_action("Spawn Wolfsbane", function()SpawnVehicle(-618617997)end)
CarSubMotorcycles:add_action("Spawn Zombiea", function()SpawnVehicle(-1009268949)end)
CarSubMotorcycles:add_action("Spawn Zombieb", function()SpawnVehicle(-570033273)end)

-- Muscle
CarSubMuscle:add_action("Spawn Blade", function()SpawnVehicle(-1205801634)end)
CarSubMuscle:add_action("Spawn Buccaneer", function()SpawnVehicle(-682211828)end)
CarSubMuscle:add_action("Spawn Buccaneer2", function()SpawnVehicle(-1013450936)end)
CarSubMuscle:add_action("Spawn Broadway", function()SpawnVehicle(-1933242328)end)
CarSubMuscle:add_action("Spawn Chino", function()SpawnVehicle(349605904)end)
CarSubMuscle:add_action("Spawn Chino2", function()SpawnVehicle(-1361687965)end)
CarSubMuscle:add_action("Spawn Dominator", function()SpawnVehicle(80636076)end)
CarSubMuscle:add_action("Spawn Dominator2", function()SpawnVehicle(-915704871)end)
CarSubMuscle:add_action("Spawn Dukes", function()SpawnVehicle(723973206)end)
CarSubMuscle:add_action("Spawn Dukes2", function()SpawnVehicle(-326143852)end)
CarSubMuscle:add_action("Spawn Eudora", function()SpawnVehicle(-1249788006)end)
CarSubMuscle:add_action("Spawn Faction", function()SpawnVehicle(-2119578145)end)
CarSubMuscle:add_action("Spawn Faction2", function()SpawnVehicle(-1790546981)end)
CarSubMuscle:add_action("Spawn Faction3", function()SpawnVehicle(-2039755226)end)
CarSubMuscle:add_action("Spawn Gauntlet", function()SpawnVehicle(-1800170043)end)
CarSubMuscle:add_action("Spawn Gauntlet2", function()SpawnVehicle(349315417)end)
CarSubMuscle:add_action("Spawn Greenwood", function()SpawnVehicle(40817712)end)
CarSubMuscle:add_action("Spawn Hotknife", function()SpawnVehicle(37348240)end)
CarSubMuscle:add_action("Spawn Ruinerzz8", function()SpawnVehicle(51706945532)end)
CarSubMuscle:add_action("Spawn Lurcher", function()SpawnVehicle(2068293287)end)
CarSubMuscle:add_action("Spawn Moonbeam", function()SpawnVehicle(525509695)end)
CarSubMuscle:add_action("Spawn Moonbeam2", function()SpawnVehicle(1896491931)end)
CarSubMuscle:add_action("Spawn Nightshade", function()SpawnVehicle(-1943285540)end)
CarSubMuscle:add_action("Spawn Phoenix", function()SpawnVehicle(-2095439403)end)
CarSubMuscle:add_action("Spawn Picador", function()SpawnVehicle(1507916787)end)
CarSubMuscle:add_action("Spawn RatLoader", function()SpawnVehicle(-667151410)end)
CarSubMuscle:add_action("Spawn RatLoader2", function()SpawnVehicle(-589178377)end)
CarSubMuscle:add_action("Spawn Ruiner", function()SpawnVehicle(-227741703)end)
CarSubMuscle:add_action("Spawn Ruiner2", function()SpawnVehicle(941494461)end)
CarSubMuscle:add_action("Spawn SabreGT", function()SpawnVehicle(-1685021548)end)
CarSubMuscle:add_action("Spawn SabreGT2", function()SpawnVehicle(223258115)end)
CarSubMuscle:add_action("Spawn Sadler2", function()SpawnVehicle(734217681)end)
CarSubMuscle:add_action("Spawn SlamVan", function()SpawnVehicle(729783779)end)
CarSubMuscle:add_action("Spawn SlamVan2", function()SpawnVehicle(833469436)end)
CarSubMuscle:add_action("Spawn SlamVan3", function()SpawnVehicle(1119641113)end)
CarSubMuscle:add_action("Spawn Stalion", function()SpawnVehicle(1923400478)end)
CarSubMuscle:add_action("Spawn Stalion2", function()SpawnVehicle(-401643538)end)
CarSubMuscle:add_action("Spawn Tampa", function()SpawnVehicle(972671128)end)
CarSubMuscle:add_action("Spawn Tampa3", function()SpawnVehicle(-1210451983)end)
CarSubMuscle:add_action("Spawn Tahoma", function()SpawnVehicle(461850249)end)
CarSubMuscle:add_action("Spawn Tulip", function()SpawnVehicle(268758436)end)
CarSubMuscle:add_action("Spawn Vigero", function()SpawnVehicle(-825837129)end)
CarSubMuscle:add_action("Spawn Vigero2", function()SpawnVehicle(1758379524)end)
CarSubMuscle:add_action("Spawn Virgo", function()SpawnVehicle(-498054846)end)
CarSubMuscle:add_action("Spawn Virgo2", function()SpawnVehicle(-899509638)end)
CarSubMuscle:add_action("Spawn Virgo3", function()SpawnVehicle(16646064)end)
CarSubMuscle:add_action("Spawn Voodoo", function()SpawnVehicle(2006667053)end)
CarSubMuscle:add_action("Spawn Voodoo2", function()SpawnVehicle(523724515)end)
CarSubMuscle:add_action("Spawn Weevil", function()SpawnVehicle(1644055914)end)

-- OffRoad
CarSubOffRoad:add_action("Spawn BfInjection", function()SpawnVehicle(1126868326)end)
CarSubOffRoad:add_action("Spawn Bifta", function()SpawnVehicle(-349601129)end)
CarSubOffRoad:add_action("Spawn Blazer", function()SpawnVehicle(-2128233223)end)
CarSubOffRoad:add_action("Spawn Blazer2", function()SpawnVehicle(-48031959)end)
CarSubOffRoad:add_action("Spawn Blazer3", function()SpawnVehicle(-1269889662)end)
CarSubOffRoad:add_action("Spawn Blazer5", function()SpawnVehicle(-1590337689)end)
CarSubOffRoad:add_action("Spawn Bodhi2", function()SpawnVehicle(-1435919434)end)
CarSubOffRoad:add_action("Spawn Brawler", function()SpawnVehicle(-1479664699)end)
CarSubOffRoad:add_action("Spawn Boar", function()SpawnVehicle(996383885)end)
CarSubOffRoad:add_action("Spawn DLoader", function()SpawnVehicle(1770332643)end)
CarSubOffRoad:add_action("Spawn Dune", function()SpawnVehicle(-1661854193)end)
CarSubOffRoad:add_action("Spawn Dune2", function()SpawnVehicle(534258863)end)
CarSubOffRoad:add_action("Spawn Dune3", function()SpawnVehicle(1897744184)end)
CarSubOffRoad:add_action("Spawn Dune4", function()SpawnVehicle(-827162039)end)
CarSubOffRoad:add_action("Spawn Dune5", function()SpawnVehicle(-312295511)end)
CarSubOffRoad:add_action("Spawn Drauger", function()SpawnVehicle(768236378)end)
CarSubOffRoad:add_action("Spawn Insurgent", function()SpawnVehicle(-1860900134)end)
CarSubOffRoad:add_action("Spawn Insurgent2", function()SpawnVehicle(2071877360)end)
CarSubOffRoad:add_action("Spawn Insurgent3", function()SpawnVehicle(-1924433270)end)
CarSubOffRoad:add_action("Spawn Kalahari", function()SpawnVehicle(92612664)end)
CarSubOffRoad:add_action("Spawn Lifeguard", function()SpawnVehicle(469291905)end)
CarSubOffRoad:add_action("Spawn Marshall", function()SpawnVehicle(1233534620)end)
CarSubOffRoad:add_action("Spawn Mesa", function()SpawnVehicle(914654722)end)
CarSubOffRoad:add_action("Spawn Mesa2", function()SpawnVehicle(-748008636)end)
CarSubOffRoad:add_action("Spawn Mesa3", function()SpawnVehicle(-2064372143)end)
CarSubOffRoad:add_action("Spawn Monster", function()SpawnVehicle(-845961253)end)
CarSubOffRoad:add_action("Spawn Nightshark", function()SpawnVehicle(433954513)end)
CarSubOffRoad:add_action("Spawn RancherXL", function()SpawnVehicle(-2064372143)end)
CarSubOffRoad:add_action("Spawn RancherXL2", function()SpawnVehicle(-845961253)end)
CarSubOffRoad:add_action("Spawn Rebel", function()SpawnVehicle(-1207771834)end)
CarSubOffRoad:add_action("Spawn Rebel2", function()SpawnVehicle(-2045594037)end)
CarSubOffRoad:add_action("Spawn Sandking", function()SpawnVehicle(-1189015600)end)
CarSubOffRoad:add_action("Spawn Sandking2", function()SpawnVehicle(989381445)end)
CarSubOffRoad:add_action("Spawn Technical", function()SpawnVehicle(-2096818938)end)
CarSubOffRoad:add_action("Spawn Technical2", function()SpawnVehicle(1180875963)end)
CarSubOffRoad:add_action("Spawn Technical3", function()SpawnVehicle(1356124575)end)
CarSubOffRoad:add_action("Spawn TrophyTruck", function()SpawnVehicle(101905590)end)
CarSubOffRoad:add_action("Spawn TrophyTruck2", function()SpawnVehicle(-663299102)end)

-- Planes
CarSubPlanes:add_action("Spawn Besra", function()SpawnVehicle(1824333165)end)
CarSubPlanes:add_action("Spawn Blimp", function()SpawnVehicle(-150975354)end)
CarSubPlanes:add_action("Spawn Blimp2", function()SpawnVehicle(-613725916)end)
CarSubPlanes:add_action("Spawn CargoPlane", function()SpawnVehicle(368211810)end)
CarSubPlanes:add_action("Spawn Cuban800", function()SpawnVehicle(-644710429)end)
CarSubPlanes:add_action("Spawn Dodo", function()SpawnVehicle(-901163259)end)
CarSubPlanes:add_action("Spawn Duster", function()SpawnVehicle(-970356638)end)
CarSubPlanes:add_action("Spawn Hydra", function()SpawnVehicle(970385471)end)
CarSubPlanes:add_action("Spawn Jet", function()SpawnVehicle(1058115860)end)
CarSubPlanes:add_action("Spawn Lazer", function()SpawnVehicle(-1281684762)end)
CarSubPlanes:add_action("Spawn Luxor", function()SpawnVehicle(621481054)end)
CarSubPlanes:add_action("Spawn Luxor2", function()SpawnVehicle(-1214293858)end)
CarSubPlanes:add_action("Spawn Mammatus", function()SpawnVehicle(-1746576111)end)
CarSubPlanes:add_action("Spawn Miljet", function()SpawnVehicle(165154707)end)
CarSubPlanes:add_action("Spawn Nimbus", function()SpawnVehicle(-1295027632)end)
CarSubPlanes:add_action("Spawn Shamal", function()SpawnVehicle(-1214505995)end)
CarSubPlanes:add_action("Spawn Stunt", function()SpawnVehicle(-2122757008)end)
CarSubPlanes:add_action("Spawn Titan", function()SpawnVehicle(1981688531)end)
CarSubPlanes:add_action("Spawn Velum", function()SpawnVehicle(-1673356438)end)
CarSubPlanes:add_action("Spawn Velum2", function()SpawnVehicle(1077420264)end)
CarSubPlanes:add_action("Spawn Vestra", function()SpawnVehicle(1341619767)end)

-- Sedans
CarSubSedans:add_action("Spawn Asea", function()SpawnVehicle(-1809822327)end)
CarSubSedans:add_action("Spawn Asea2", function()SpawnVehicle(-1807623979)end)
CarSubSedans:add_action("Spawn Asterope", function()SpawnVehicle(-1903012613)end)
CarSubSedans:add_action("Spawn Cog55", function()SpawnVehicle(906642318)end)
CarSubSedans:add_action("Spawn Cog552", function()SpawnVehicle(704435172)end)
CarSubSedans:add_action("Spawn Cognoscenti", function()SpawnVehicle(-2030171296)end)
CarSubSedans:add_action("Spawn Cognoscenti2", function()SpawnVehicle(-604842630)end)
CarSubSedans:add_action("Spawn Emperor", function()SpawnVehicle(-685276541)end)
CarSubSedans:add_action("Spawn Emperor2", function()SpawnVehicle(-1883002148)end)
CarSubSedans:add_action("Spawn Emperor3", function()SpawnVehicle(-1241712818)end)
CarSubSedans:add_action("Spawn Fugitive", function()SpawnVehicle(1909141499)end)
CarSubSedans:add_action("Spawn Glendale", function()SpawnVehicle(75131841)end)
CarSubSedans:add_action("Spawn Ingot", function()SpawnVehicle(-1289722222)end)
CarSubSedans:add_action("Spawn Intruder", function()SpawnVehicle(886934177)end)
CarSubSedans:add_action("Spawn Limo2", function()SpawnVehicle(-114627507)end)
CarSubSedans:add_action("Spawn Premier", function()SpawnVehicle(-1883869285)end)
CarSubSedans:add_action("Spawn Primo", function()SpawnVehicle(-1150599089)end)
CarSubSedans:add_action("Spawn Primo2", function()SpawnVehicle(-2040426790)end)
CarSubSedans:add_action("Spawn Regina", function()SpawnVehicle(-14495224)end)
CarSubSedans:add_action("Spawn Romero", function()SpawnVehicle(627094268)end)
CarSubSedans:add_action("Spawn Rhinehart", function()SpawnVehicle(1855505138)end)
CarSubSedans:add_action("Spawn Stanier", function()SpawnVehicle(-1477580979)end)
CarSubSedans:add_action("Spawn Stratum", function()SpawnVehicle(1723137093)end)
CarSubSedans:add_action("Spawn Stretch", function()SpawnVehicle(-1961627517)end)
CarSubSedans:add_action("Spawn Surge", function()SpawnVehicle(-1894894188)end)
CarSubSedans:add_action("Spawn Tailgater", function()SpawnVehicle(-1008861746)end)
CarSubSedans:add_action("Spawn Warrener", function()SpawnVehicle(1373123368)end)
CarSubSedans:add_action("Spawn Washington", function()SpawnVehicle(1777363799)end)

-- Service
CarSubService:add_action("Spawn Airbus", function()SpawnVehicle(1283517198)end)
CarSubService:add_action("Spawn Brickade", function()SpawnVehicle(-305727417)end)
CarSubService:add_action("Spawn Brickade2 | (Acid Lab)", function()SpawnVehicle(-1576586413)end)
CarSubService:add_action("Spawn Bus", function()SpawnVehicle(-713569950)end)
CarSubService:add_action("Spawn Coach", function()SpawnVehicle(-2072933068)end)
CarSubService:add_action("Spawn Rallytruck", function()SpawnVehicle(-2103821244)end)
CarSubService:add_action("Spawn RentalBus", function()SpawnVehicle(-1098802077)end)
CarSubService:add_action("Spawn Taxi", function()SpawnVehicle(-956048545)end)
CarSubService:add_action("Spawn Tourbus", function()SpawnVehicle(1941029835)end)
CarSubService:add_action("Spawn Trash", function()SpawnVehicle(1917016601)end)
CarSubService:add_action("Spawn Trash2", function()SpawnVehicle(-1255698084)end)

-- Super Sports
CarSubSuperSports:add_action("Spawn Ardent", function()SpawnVehicle(0x97E5533)end)
CarSubSuperSports:add_action("Spawn Byte2", function()SpawnVehicle(0xCE6B35A4)end)
CarSubSuperSports:add_action("Spawn Casco", function()SpawnVehicle(0x3822BDFE	)end)
CarSubSuperSports:add_action("Spawn Cheetah", function()SpawnVehicle(0xD4E5F4D)end)
CarSubSuperSports:add_action("Spawn Coquette", function()SpawnVehicle(0x3C4E2113)end)
CarSubSuperSports:add_action("Spawn Deluxo", function()SpawnVehicle(0x586765FB)end)
CarSubSuperSports:add_action("Spawn Fagaloa", function()SpawnVehicle(0x6068AD86)end)
CarSubSuperSports:add_action("Spawn Feltzer", function()SpawnVehicle(0xA29D6D10)end)
CarSubSuperSports:add_action("Spawn GT500", function()SpawnVehicle(0x8408F33A)end)
CarSubSuperSports:add_action("Spawn Infernos 2", function()SpawnVehicle(0xAC33179C)end)
CarSubSuperSports:add_action("Spawn JB700", function()SpawnVehicle(0x3EAB5555)end)
CarSubSuperSports:add_action("Spawn More SOon!", function()SpawnVehicle()end)
CarSubSuperSports:add_action("Spawn ", function()SpawnVehicle()end)
CarSubSuperSports:add_action("Spawn ", function()SpawnVehicle()end)
CarSubSuperSports:add_action("Spawn ", function()SpawnVehicle()end)
CarSubSuperSports:add_action("Spawn ", function()SpawnVehicle()end)
CarSubSuperSports:add_action("Spawn ", function()SpawnVehicle()end)
CarSubSuperSports:add_action("Spawn ", function()SpawnVehicle()end)

CarSubSuperSports:add_action("Spawn Roosevelt", function()SpawnVehicle(117401876)end)
CarSubSuperSports:add_action("Spawn Roosevelt v2", function()SpawnVehicle(0xDC19D101)end)

-- Sports
CarSubSports:add_action("Spawn 300R", function()SpawnVehicle(1076201208)end)
CarSubSports:add_action("Spawn Alpha", function()SpawnVehicle(767087018)end)
CarSubSports:add_action("Spawn Banshee", function()SpawnVehicle(-1041692462)end)
CarSubSports:add_action("Spawn Banshee2", function()SpawnVehicle(633712403)end)
CarSubSports:add_action("Spawn BestiaGTS", function()SpawnVehicle(1274868363)end)
CarSubSports:add_action("Spawn Buffalo", function()SpawnVehicle(-304802106)end)
CarSubSports:add_action("Spawn Buffalo2", function()SpawnVehicle(736902334)end)
CarSubSports:add_action("Spawn Buffalo3", function()SpawnVehicle(237764926)end)
CarSubSports:add_action("Spawn Carbonizzare", function()SpawnVehicle(2072687711)end)
CarSubSports:add_action("Spawn Comet2", function()SpawnVehicle(-1045541610)end)
CarSubSports:add_action("Spawn Comet3", function()SpawnVehicle(-2022483795)end)
CarSubSports:add_action("Spawn Corsita", function()SpawnVehicle(754687673)end)
CarSubSports:add_action("Spawn Coquette", function()SpawnVehicle(108773431)end)
CarSubSports:add_action("Spawn Elegy", function()SpawnVehicle(196747873)end)
CarSubSports:add_action("Spawn Elegy2", function()SpawnVehicle(-566387422)end)
CarSubSports:add_action("Spawn Entity", function()SpawnVehicle(1748565021)end)
CarSubSports:add_action("Spawn Everon", function()SpawnVehicle(-131348178)end)
CarSubSports:add_action("Spawn Feltzer2", function()SpawnVehicle(-1995326987)end)
CarSubSports:add_action("Spawn Feltzer3", function()SpawnVehicle(-1566741232)end)
CarSubSports:add_action("Spawn Furoregt", function()SpawnVehicle(-1089039904)end)
CarSubSports:add_action("Spawn Fusilade", function()SpawnVehicle(499169875)end)
CarSubSports:add_action("Spawn Futo", function()SpawnVehicle(2016857647)end)
CarSubSports:add_action("Spawn Infernus2", function()SpawnVehicle(-1405937764)end)
CarSubSports:add_action("Spawn Jester", function()SpawnVehicle(-1297672541)end)
CarSubSports:add_action("Spawn Jester2", function()SpawnVehicle(-1106353882)end)
CarSubSports:add_action("Spawn Khamelion", function()SpawnVehicle(544021352)end)
CarSubSports:add_action("Spawn Kuruma", function()SpawnVehicle(-1372848492)end)
CarSubSports:add_action("Spawn ArmoredKuruma", function()SpawnVehicle(410882957)end)
CarSubSports:add_action("Spawn LM87", function()SpawnVehicle(10917683)end)
CarSubSports:add_action("Spawn Lynx", function()SpawnVehicle(482197771)end)
CarSubSports:add_action("Spawn Massacro", function()SpawnVehicle(-142942670)end)
CarSubSports:add_action("Spawn Massacro2", function()SpawnVehicle(-631760477)end)
CarSubSports:add_action("Spawn Ninef", function()SpawnVehicle(1032823388)end)
CarSubSports:add_action("Spawn Ninef2", function()SpawnVehicle(-1461482751)end)
CarSubSports:add_action("Spawn tenf", function()SpawnVehicle(893984159)end)
CarSubSports:add_action("Spawn tenf2", function()SpawnVehicle(274946574)end)
CarSubSports:add_action("Spawn Omnis", function()SpawnVehicle(-777172681)end)
CarSubSports:add_action("Spawn Omnisegt", function()SpawnVehicle(505223465)end)
CarSubSports:add_action("Spawn Panthere", function()SpawnVehicle(2100457220)end)
CarSubSports:add_action("Spawn Penumbra", function()SpawnVehicle(-377465520)end)
CarSubSports:add_action("Spawn RapidGT", function()SpawnVehicle(-1934452204)end)
CarSubSports:add_action("Spawn RapidGT2", function()SpawnVehicle(1737773231)end)
CarSubSports:add_action("Spawn Raptor", function()SpawnVehicle(-674927303)end)
CarSubSports:add_action("Spawn Ruston", function()SpawnVehicle(719660200)end)
CarSubSports:add_action("Spawn Schafter2", function()SpawnVehicle(-1255452397)end)
CarSubSports:add_action("Spawn Schafter3", function()SpawnVehicle(-1485523546)end)
CarSubSports:add_action("Spawn Schafter4", function()SpawnVehicle(1489967196)end)
CarSubSports:add_action("Spawn Schafter5", function()SpawnVehicle(-888242983)end)
CarSubSports:add_action("Spawn Schafter6", function()SpawnVehicle(1922255844)end)
CarSubSports:add_action("Spawn Schwarzer", function()SpawnVehicle(-746882698)end)
CarSubSports:add_action("Spawn Seven70", function()SpawnVehicle(-1757836725)end)
CarSubSports:add_action("Spawn Specter", function()SpawnVehicle(1886268224)end)
CarSubSports:add_action("Spawn Specter2", function()SpawnVehicle(1074745671)end)
CarSubSports:add_action("Spawn Sultan", function()SpawnVehicle(970598228)end)
CarSubSports:add_action("Spawn Surano", function()SpawnVehicle(384071873)end)
CarSubSports:add_action("Spawn sm722", function()SpawnVehicle(775514032)end)
CarSubSports:add_action("Spawn Tampa2", function()SpawnVehicle(-1071380347)end)
CarSubSports:add_action("Spawn Torero", function()SpawnVehicle(165394758)end)
CarSubSports:add_action("Spawn Tropos", function()SpawnVehicle(1887331236)end)
CarSubSports:add_action("Spawn Verlierer2", function()SpawnVehicle(1102544804)end)
CarSubSports:add_action("Spawn Virtue", function()SpawnVehicle(669204833)end)

-- SUV
CarSubSUV:add_action("Spawn BJXL", function()SpawnVehicle(850565707)end)
CarSubSUV:add_action("Spawn Baller", function()SpawnVehicle(-808831384)end)
CarSubSUV:add_action("Spawn Baller2", function()SpawnVehicle(142944341)end)
CarSubSUV:add_action("Spawn Baller3", function()SpawnVehicle(1878062887)end)
CarSubSUV:add_action("Spawn Baller4", function()SpawnVehicle(634118882)end)
CarSubSUV:add_action("Spawn Baller5", function()SpawnVehicle(470404958)end)
CarSubSUV:add_action("Spawn Baller6", function()SpawnVehicle(666166960)end)
CarSubSUV:add_action("Spawn Cavalcade", function()SpawnVehicle(2006918058)end)
CarSubSUV:add_action("Spawn Cavalcade2", function()SpawnVehicle(-789894171)end)
CarSubSUV:add_action("Spawn Contender", function()SpawnVehicle(683047626)end)
CarSubSUV:add_action("Spawn Dubsta", function()SpawnVehicle(1177543287)end)
CarSubSUV:add_action("Spawn Dubsta2", function()SpawnVehicle(-394074634)end)
CarSubSUV:add_action("Spawn Dubsta3", function()SpawnVehicle(-1237253773)end)
CarSubSUV:add_action("Spawn FQ2", function()SpawnVehicle(-1137532101)end)
CarSubSUV:add_action("Spawn Granger", function()SpawnVehicle(-1775728740)end)
CarSubSUV:add_action("Spawn Gresley", function()SpawnVehicle(-1543762099)end)
CarSubSUV:add_action("Spawn Habanero", function()SpawnVehicle(884422927)end)
CarSubSUV:add_action("Spawn Huntley", function()SpawnVehicle(486987393)end)
CarSubSUV:add_action("Spawn Issi", function()SpawnVehicle(1550581940)end)
CarSubSUV:add_action("Spawn Landstalker", function()SpawnVehicle(1269098716)end)
CarSubSUV:add_action("Spawn Patriot", function()SpawnVehicle(-808457413)end)
CarSubSUV:add_action("Spawn Radi", function()SpawnVehicle(-1651067813)end)
CarSubSUV:add_action("Spawn Rocoto", function()SpawnVehicle(2136773105)end)
CarSubSUV:add_action("Spawn Seminole", function()SpawnVehicle(1221512915)end)
CarSubSUV:add_action("Spawn Serrano", function()SpawnVehicle(1337041428)end)
CarSubSUV:add_action("Spawn XLS", function()SpawnVehicle(1203490606)end)
CarSubSUV:add_action("Spawn XLS2", function()SpawnVehicle(-432008408)end)

-- Utility
CarSubUtility:add_action("Spawn Airtug", function()SpawnVehicle(1560980623)end)
CarSubUtility:add_action("Spawn Caddy", function()SpawnVehicle(1147287684)end)
CarSubUtility:add_action("Spawn Caddy2", function()SpawnVehicle(-537896628)end)
CarSubUtility:add_action("Spawn Caddy3", function()SpawnVehicle(-769147461)end)
CarSubUtility:add_action("Spawn Docktug", function()SpawnVehicle(-884690486)end)
CarSubUtility:add_action("Spawn Forklift", function()SpawnVehicle(1491375716)end)
CarSubUtility:add_action("Spawn Mower", function()SpawnVehicle(1783355638)end)
CarSubUtility:add_action("Spawn Ripley", function()SpawnVehicle(-845979911)end)
CarSubUtility:add_action("Spawn Sadler", function()SpawnVehicle(-599568815)end)
CarSubUtility:add_action("Spawn Scrap", function()SpawnVehicle(-1700801569)end)
CarSubUtility:add_action("Spawn TowTruck", function()SpawnVehicle(-1323100960)end)
CarSubUtility:add_action("Spawn TowTruck2", function()SpawnVehicle(-442313018)end)
CarSubUtility:add_action("Spawn Tractor", function()SpawnVehicle(1641462412)end)
CarSubUtility:add_action("Spawn Tractor2", function()SpawnVehicle(-2076478498)end)
CarSubUtility:add_action("Spawn Tractor3", function()SpawnVehicle(1445631933)end)
CarSubUtility:add_action("Spawn TrailerLarge", function()SpawnVehicle(1502869817)end)
CarSubUtility:add_action("Spawn TrailerS4", function()SpawnVehicle(-1100548694)end)
CarSubUtility:add_action("Spawn UtilliTruck", function()SpawnVehicle(516990260)end)
CarSubUtility:add_action("Spawn UtilliTruck2", function()SpawnVehicle(887537515)end)
CarSubUtility:add_action("Spawn UtilliTruck3", function()SpawnVehicle(2132890591)end)

-- Vans
CarSubVans:add_action("Spawn Bison", function()SpawnVehicle(-16948145)end)
CarSubVans:add_action("Spawn Bison2", function()SpawnVehicle(2072156101)end)
CarSubVans:add_action("Spawn Bison3", function()SpawnVehicle(1739845664)end)
CarSubVans:add_action("Spawn BobcatXL", function()SpawnVehicle(1069929536)end)
CarSubVans:add_action("Spawn Boxville", function()SpawnVehicle(-1987130134)end)
CarSubVans:add_action("Spawn Boxville2", function()SpawnVehicle(-233098306)end)
CarSubVans:add_action("Spawn Boxville3", function()SpawnVehicle(121658888)end)
CarSubVans:add_action("Spawn Boxville4", function()SpawnVehicle(444171386)end)
CarSubVans:add_action("Spawn Boxville5", function()SpawnVehicle(682434785)end)
CarSubVans:add_action("Spawn Burrito", function()SpawnVehicle(-1346687836)end)
CarSubVans:add_action("Spawn Burrito2", function()SpawnVehicle(-907477130)end)
CarSubVans:add_action("Spawn Burrito3", function()SpawnVehicle(-1743316013)end)
CarSubVans:add_action("Spawn Burrito4", function()SpawnVehicle(893081117)end)
CarSubVans:add_action("Spawn Burrito5", function()SpawnVehicle(1132262048)end)
CarSubVans:add_action("Spawn Camper", function()SpawnVehicle(1876516712)end)
CarSubVans:add_action("Spawn GBurrito", function()SpawnVehicle(-1745203402)end)
CarSubVans:add_action("Spawn GBurrito2", function()SpawnVehicle(296357396)end)
CarSubVans:add_action("Spawn Journey", function()SpawnVehicle(296357396)end)
CarSubVans:add_action("Spawn Journey2", function()SpawnVehicle(-1627077503)end)
CarSubVans:add_action("Spawn Minivan", function()SpawnVehicle(-310465116)end)
CarSubVans:add_action("Spawn Minivan2", function()SpawnVehicle(-1126264336)end)
CarSubVans:add_action("Spawn Paradise", function()SpawnVehicle(1488164764)end)
CarSubVans:add_action("Spawn Pony", function()SpawnVehicle(-119658072)end)
CarSubVans:add_action("Spawn Pony2", function()SpawnVehicle(943752001)end)
CarSubVans:add_action("Spawn Rumpo", function()SpawnVehicle(1162065741)end)
CarSubVans:add_action("Spawn Rumpo2", function()SpawnVehicle(-1776615689)end)
CarSubVans:add_action("Spawn Rumpo3", function()SpawnVehicle(1475773103)end)
CarSubVans:add_action("Spawn Speedo", function()SpawnVehicle(-810318068)end)
CarSubVans:add_action("Spawn Speedo2", function()SpawnVehicle(728614474)end)
CarSubVans:add_action("Spawn Surfer", function()SpawnVehicle(699456151)end)
CarSubVans:add_action("Spawn Surfer2", function()SpawnVehicle(-1311240698)end)
CarSubVans:add_action("Spawn Surfer3", function()SpawnVehicle(-1035489563)end)
CarSubVans:add_action("Spawn Taco", function()SpawnVehicle(1951180813)end)
CarSubVans:add_action("Spawn Youga", function()SpawnVehicle(65402552)end)
CarSubVans:add_action("Spawn Youga2", function()SpawnVehicle(1026149675)end)

-- Commercial
CarSubCommercial:add_action("Spawn Benson", function()SpawnVehicle(2053223216)end)
CarSubCommercial:add_action("Spawn Biff", function()SpawnVehicle(850991848)end)
CarSubCommercial:add_action("Spawn Hauler", function()SpawnVehicle(1518533038)end)
CarSubCommercial:add_action("Spawn Hauler2", function()SpawnVehicle(387748548)end)
CarSubCommercial:add_action("Spawn Mule", function()SpawnVehicle(904750859)end)
CarSubCommercial:add_action("Spawn Mule2", function()SpawnVehicle(-1050465301)end)
CarSubCommercial:add_action("Spawn Mule3", function()SpawnVehicle(-2052737935)end)
CarSubCommercial:add_action("Spawn Packer", function()SpawnVehicle(569305213)end)
CarSubCommercial:add_action("Spawn Phantom", function()SpawnVehicle(-2137348917)end)
CarSubCommercial:add_action("Spawn Phantom2", function()SpawnVehicle(-1649536104)end)
CarSubCommercial:add_action("Spawn Phantom3", function()SpawnVehicle(177270108)end)
CarSubCommercial:add_action("Spawn Pounder", function()SpawnVehicle(2112052861)end)
CarSubCommercial:add_action("Spawn Stockade", function()SpawnVehicle(1747439474)end)
CarSubCommercial:add_action("Spawn Stockade2", function()SpawnVehicle(-214455498)end)

----Vehicle Spawn End

local cars_data = {}
local function waitForVehicleData()
	local tries = 0
	while tries <= 250 do
		-- try getting a vehicle and its handling data
		veh = localplayer:get_current_vehicle()
		local temp_data = {
					veh:get_acceleration(),			--1
					veh:get_brake_force(),			--2
					veh:get_gravity(),				--3
					veh:get_handbrake_force(),		--4
					veh:get_initial_drive_force(),	--5
					veh:get_traction_curve_min(),	--6
					veh:get_traction_curve_max(),	--7
					veh:get_traction_bias_front(),	--8
					veh:get_up_shift(),				--9
					veh:get_down_shift(),			--10
					veh:get_initial_drive_max_flat_velocity(),	--11
					veh:get_centre_of_mass_offset(),			--12
					veh:get_collision_damage_multiplier(),		--13
					veh:get_engine_damage_multiplier(),			--14
					veh:get_roll_centre_height_front(),			--15	
					veh:get_roll_centre_height_rear(),			--16
					veh:get_drive_bias_front(),					--17
					veh:get_traction_loss_multiplier(),			--18
					veh:get_initial_drag_coeff()				--19
					}
		
		--do a rough check if the vehicle data we got actually makes sense, else try getting the vehicle object again
		--this is to work around a bug in Kiddions LUA vehicle implementation where often
		--the vehicle handling data in a vehicle object will be broken, leaving to bs data when using get methods
		--and being unable to change the handling later with set methods
		--once we find a working veh object, it gets saved in the table and returned so it can be used to modify on later
		if (temp_data[8] >= 0 and temp_data[8] <= 1) and
		   (temp_data[11] >= 10 and temp_data[11] <= 500) and
		   (temp_data[17] >= 0 and temp_data[17] <= 1) then
		    -- save the working veh object with model hash as key in the table so we can use it later
			temp_data[veh:get_model_hash()] = veh
			return temp_data
		end
		--try again if the data we got looked weird
		sleep(0.02)
		tries = tries + 1
	end
end

--░█████╗░░██████╗██╗░░░██╗░█████╗░███╗░░██╗
--██╔══██╗██╔════╝╚██╗░██╔╝██╔══██╗████╗░██║
--██║░░╚═╝╚█████╗░░╚████╔╝░██║░░██║██╔██╗██║
--██║░░██╗░╚═══██╗░░╚██╔╝░░██║░░██║██║╚████║
--╚█████╔╝██████╔╝░░░██║░░░╚█████╔╝██║░╚███║
--░╚════╝░╚═════╝░░░░╚═╝░░░░╚════╝░╚═╝░░╚══╝