--░█████╗░░██████╗██╗░░░██╗░█████╗░███╗░░██╗
--██╔══██╗██╔════╝╚██╗░██╔╝██╔══██╗████╗░██║
--██║░░╚═╝╚█████╗░░╚████╔╝░██║░░██║██╔██╗██║
--██║░░██╗░╚═══██╗░░╚██╔╝░░██║░░██║██║╚████║
--╚█████╔╝██████╔╝░░░██║░░░╚█████╔╝██║░╚███║
--░╚════╝░╚═════╝░░░░╚═╝░░░░╚════╝░╚═╝░░╚══╝
function CheckOnlineVersion()
	major, minor, build, patch = menu.get_game_version()
	if build ~= 3095 then
		main = menu.add_submenu("⚠The game current version is: "..major.."."..minor.."."..build.."."..patch)
		main:add_submenu("Game updated!!!")
		main:add_submenu("The sctipt is outdated!!!")
	end
end
CheckOnlineVersion()
require_game_build(3095) -- GTA Online version 1.68

local function CSYONTEXT(text)
	mainMenu4:add_action(text,  function() end)
end

local function TextC(text)
	Online:add_action(text,  function() end)
end

local function TextCO(text)
	Offlinex64:add_action(text,  function() end)
end

local function TextCM(text)
	menu.add_action(text,  function() end)
end

local function Text(text)
	Offlinex64:add_action(text,  function() end)
end

local function Text(text)
	Offlinex64:add_submenu(text,  function() end)
end

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--Required Stats--
		
		MPX = PI 
		PI = stats.get_int("MPPLY_LAST_MP_CHAR") 
		if PI == 0 then MPX = "MP0_" else MPX = "MP1_" end
		ASS = script("appsecuroserv")
		GCS = script("gb_contraband_sell")
		GCB = script("gb_contraband_buy")
		AMW = script("am_mp_warehouse")
		GB = script("gb_gunrunning")
		FMC = script("fm_mission_controller")
		FMC20 = script("fm_mission_controller_2020") 
		FormatMoney = (function (n)
		n = tostring(n) return n:reverse():gsub("%d%d%d", "%1,"):reverse():gsub("^,", "") end)
		freemodeglobal = 262145 
                fmC2020 = script("fm_mission_controller_2020")
                fmC = script("fm_mission_controller")
                function TP(x, y, z, yaw, roll, pitch)
                if localplayer:is_in_vehicle()
                then
                localplayer:get_current_vehicle():set_position(x, y, z)
                localplayer:get_current_vehicle():set_rotation(yaw, roll, pitch)
                else localplayer:set_position(x, y, z)
                localplayer:set_rotation(yaw, roll, pitch)
                end
                end 

                function smallPlayer()
            	if localplayer == nil then
		return nil
         	end
        	return localplayer:get_config_flag(223)
                end

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


mainMenu4 = menu.add_submenu("【 CSYON 】 SubMenu E3")

CSYONTEXT("**************************************************************************")
CSYONTEXT("            ** CSYON SubMenu 1.68 **                  ")
CSYONTEXT("                               **✅ v17 **                   ")
CSYONTEXT("            ** ⚠️Game Build Version 3095⚠️ **                  ")
CSYONTEXT("**************************************************************************")
	
Online= mainMenu4:add_submenu("🚨 Csyon Submenu")
mainMenu4:add_action("------------------------------------------------------", function() end)
Offlinex64 = mainMenu4:add_submenu("          	**💬 Read Me 💬**                        ")
mainMenu4:add_action("------------------------------------------------------", function() end)
--------------------------------------------------------------------------------------------------------
CSYON39 = Online:add_submenu("🔫🙍Heists Menu")
CSYON45 = Online:add_submenu("⚠info for help")
--------------------------------------------------------------------------------------------------------
CSYONS99 = CSYON45:add_submenu("⚠ReadMe")
CSYONS99:add_action("***********************************************************", function() end)
CSYONS99:add_action("for Help join my Discord Server", function() end)
CSYONS99:add_action("https://discord.gg/JaCvtj6yQK", function() end)
CSYONS99:add_action("***********************************************************", function() end)
--------------------------------------------------------------------------------------------------------
CSYONCONTRACTS = CSYON39:add_submenu("📄Contracts Data Editor")
CSYONCarShopPrep = CSYON39:add_submenu("🚗Auto Shop Preps Editor")
CSYONSAPARTMENT = CSYON39:add_submenu("🏠Apartment Data Editor")
CSYONCASINO = CSYON39:add_submenu("🎰Casino Data Editor")
CSYONSPERICO = CSYON39:add_submenu("🏝️Cayo Perlco Editior")
CSYONSCAYO =  CSYON39 :add_submenu("🏝️Cayo Perico Cooldown Editior")
CSYONDOMSDAY = CSYON39:add_submenu("🏚️Doomsday Heist Editor")
CSYONCasinoTP = CSYON39:add_submenu("🎰Teleport The Casino ")  
CSYONCAYOPERICOTP = CSYON39:add_submenu("🏝️Teleport The Cayo Perico ")  
CompleteHeists = CSYON39:add_submenu("🏝️🏚📄Complete instant heist📄🎰🚗")  
--------------------------------------------------------------------------------------------------------
function MPX()return stats.get_int("MPPLY_LAST_MP_CHAR")end

local function MPX()
	return "MP" .. stats.get_int("MPPLY_LAST_MP_CHAR") .. "_"
end

CompleteHeists:add_action("heist passed", function()
	if script("fm_mission_controller"):is_active() then
		if script("fm_mission_controller"):get_bool(3228) then
			script("fm_mission_controller"):set_int(31656, joaat("CSYON"))
			script("fm_mission_controller"):set_int(19710, 12)
		end
	end
	if script("fm_mission_controller_2020"):is_active() then
		if script("fm_mission_controller_2020"):get_bool(18627) then
			script("fm_mission_controller_2020"):set_int(50279, joaat("CSYON"))
			script("fm_mission_controller_2020"):set_int(48513, 9)
		end
	end
end)

CSYONSCAYO:add_action("Remove cooldown for Cayo Perico Heist", function()
	mpIndex = globals.get_int(1574918)
	if mpIndex == 0 then
                 stats.set_int("MP0_H4_TARGET_POSIX", 1659429119)  --[[1659429119 Parameter Set]]
		 stats.set_int("MP0_H4_COOLDOWN", 0)
	         stats.set_int("MP0_H4_COOLDOWN_HARD", 0)
	else
		  stats.set_int("MP1_H4_COOLDOWN", 0)
                  stats.set_int("MP1_H4_TARGET_POSIX", 1659429119)
		  stats.set_int("MP1_H4_COOLDOWN_HARD", 0)
	end
end)

local function teleport_myself(x,y,z)
    localplayer:set_position((vector3(x, y, z)))
end
 

CSYONCasinoTP:add_action("Diamond Casino - Hack Vault 1", function()
	teleport_myself(2510.261475, -224.366699, -72.037163)
end)
 
CSYONCasinoTP:add_action("Diamond Casino - Hack Vault 2", function()
	teleport_myself(2533.521729, -225.209366, -72.037163)
end)
 
CSYONCasinoTP:add_action("Diamond Casino - Hack Vault 3", function()
	teleport_myself(2537.823486, -237.452118, -72.037163)
end)

CSYONCasinoTP:add_action("Diamond Casino - Hack Vault 4", function()
	teleport_myself(2534.049561, -248.194931, -72.037163)
end)

CSYONCasinoTP:add_action("Diamond Casino - Hack Vault 5", function()
	teleport_myself(2520.342773, -255.425705, -72.037178)
end)

CSYONCasinoTP:add_action("Diamond Casino - Hack Vault 6", function()
	teleport_myself(2509.844238, -250.968552, -72.037170)
end)

CSYONCasinoTP:add_action("Diamond Casino - Cash Vault Lobby Enter", function()
	teleport_myself(2521.761719, -287.359192, -60.022976)
end)

CSYONCasinoTP:add_action("Diamond Casino - Cash Vault Lobby Exit", function()
	teleport_myself(2521.876709, -284.334869, -60.022999)
end)

local function teleport_myself(x,y,z)
    localplayer:set_position((vector3(x, y, z)))
end
 

CSYONCAYOPERICOTP:add_action("CayoPerico - Main Dock", function()
	teleport_myself(4947.496094, -5168.458008, 1.234270)
end)
 
CSYONCAYOPERICOTP:add_action("CayoPerico - Main Loot", function()
	teleport_myself(5010.065430, -5751.291504, 14.184451)
end)
 
CSYONCAYOPERICOTP:add_action("CayoPerico - Office", function()
	teleport_myself(5010.203613, -5753.518555, 27.545284)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Vault Loot", function()
	teleport_myself(4999.764160, -5747.863770, 14.840000)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Main Loot Gate", function()
	teleport_myself(5009.156738, -5753.715820, 14.173852)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - North Safe Point", function()
	teleport_myself(4961.050781, -5791.280762, 24.966309)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - StorageRoom1", function()
	teleport_myself(5080.922852, -5756.109375, 14.529646)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - StorageRoom2", function()
	teleport_myself(5028.794922, -5735.571777, 16.565603)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - StorageRoom3", function()
	teleport_myself(5008.020020, -5787.345215, 16.531713)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - StorageRoom4", function()
	teleport_myself(5000.289062, -5749.532715, 13.540483)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - PowerStation", function()
	teleport_myself(4477.102539, -4597.295898, 4.283014)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - CommTower", function()
	teleport_myself(5266.018555, -5427.736328, 64.297134)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Main Dock Loot #01", function()
	teleport_myself(4924.384766, -5243.334473, 1.223530)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Main Dock Loot #02", function()
	teleport_myself(4999.082520, -5165.239746, 1.464267)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Main Dock Loot #03", function()
	teleport_myself(4504.116211, -4555.046387, 2.871900)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Main Dock Loot #04", function()
	teleport_myself(4437.779785, -4447.757812, 3.028435)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Main Dock Loot #05", function()
	teleport_myself(5136.357910, -4607.321289, 1.332651)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Main Dock Loot #06", function()
	teleport_myself(5064.508789, -4596.458008, 1.552215)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Main Dock Loot #07", function()
	teleport_myself(5090.897949, -4682.269043, 1.107239)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Main Dock Loot #08", function()
	teleport_myself(5194.034668, -5135.017090, 2.046481)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Main Dock Loot #09", function()
	teleport_myself(5330.440918, -5270.056641, 31.886101)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Main Dock Loot #10", function()
	teleport_myself(4999.170898, -5165.166504, 1.464278)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Main Dock Loot #11", function()
	teleport_myself(4961.721680, -5108.724609, 1.681915)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Hack Tower #01", function()
	teleport_myself(5265.228516, -5429.266113, 107.849457)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Hack Tower #02", function()
	teleport_myself(5266.385742, -5431.791992, 89.423813)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Hack Tower #03", function()
	teleport_myself(5265.713867, -5427.803711, 139.747101)
end)

CSYONCAYOPERICOTP:add_action("CayoPerico - Exit", function()
	teleport_myself(4990.778809, -5716.004395, 18.580210)
end)

CSYONDOMSDAY:add_array_item("Doomsday Act", {"I:Data Breaches", "II:Bogdan Problem", "III:Doomsday Senario"}, function()
 return xox_22 end, function(value)
 xox_22 = value
 if value == 1
 then GGP = 503
 GGS = 229383
 elseif
 value == 2
 then GGP = 240
 GGS = 229378
 elseif
 value == 3
 then GGP = 16368
 GGS = 229380
 end
 stats.set_int(MPX .. "GANGOPS_FLOW_MISSION_PROG", GGP)
 stats.set_int(MPX .. "GANGOPS_HEIST_STATUS", GGS)
 stats.set_int(MPX .. "GANGOPS_FLOW_NOTIFICATIONS", 1557)
 end) 

CSYONDOMSDAY:add_action("Complete All", function()
 stats.set_int(MPX.."GANGOPS_FM_MISSION_PROG", -1) end) 
CSYONDOMSDAY:add_action("Reset Heist", function()
 stats.set_int(MPX.."GANGOPS_FLOW_MISSION_PROG", 240)
 stats.set_int(MPX.."GANGOPS_HEIST_STATUS", 0)
 stats.set_int(MPX.."GANGOPS_FLOW_NOTIFICATIONS", 1557)
 end) 

CSYONDOMSDAY:add_action("-----", function()
 end) 

CSYONDOMSDAY:add_action("Instant Finish $$", function()
 fmC:set_int(19679, 12)
 fmC:set_int(19679 + 2686, 10000000)
 fmC:set_int(28298 + 1, 99999)
 fmC:set_int(31554 + 69, 99999)
 end) 

CSYONDOMSDAY:add_action("(Wait 5 secs  to use after loading, press", function()
 end) 

CSYONDOMSDAY:add_action("again 5 secs after loading inside building)", function()
 end) 

CSYONDOMSDAY:add_action("-----", function()
 end) 

CSYONDOMSDAY:add_action("Bypass Act III Hack", function()
 fmC:set_int(1400, 3)
 end) 

CSYONDOMSDAY:add_action("Kill mission npcs", function()
 menu.kill_all_mission_peds()
 end) 

CSYONDOMSDAY:add_action("Kill all npcs", function()
 menu.kill_all_npcs()
 end)

CSYONLELMENU = CSYONDOMSDAY:add_submenu("Cuts")
 CSYONLELMENU:add_array_item("Max $ Cuts% All", {"I:Data Breaches", "II:Bogdan Problem", "III:Doomsday Senario"}, function()
 return xox_23 end, function(value)
 if value == 1 then
 globals.set_int(1967694, 209)
 globals.set_int(1967695, 209)
 globals.set_int(1967696, 209)
 globals.set_int(1967697, 209)
 elseif
 value == 2 then
 globals.set_int(1967694, 143)
 globals.set_int(1967695, 143)
 globals.set_int(1967696, 143)
 globals.set_int(1967697, 143)
 elseif
 value == 3 then
 globals.set_int(1967694, 113)
 globals.set_int(1967695, 113)
 globals.set_int(1967696, 113)
 globals.set_int(1967697, 113)
 end
 xox_23 = value
 end)

CSYONLELMENU:add_action("                      ~Manual %~ ", function()
 end) 

CSYONLELMENU:add_int_range("Doomsday Player 1", 1.0, 15, 313, function()
 return
 globals.get_int(1967694)
 end, function(value)
 globals.set_int(1967694, value)
 end) 

CSYONLELMENU:add_int_range("Doomsday Player 2", 1.0, 15, 313, function()
 return
 globals.get_int(1967695)
 end, function(value)
 globals.set_int(1967695, value)
 end) 

CSYONLELMENU:add_int_range("Doomsday Player 3", 1.0, 15, 313, function()
 return
 globals.get_int(1967696)
 end, function(value)
 globals.set_int(1967696, value)
 end) 

CSYONLELMENU:add_int_range("Doomsday Player 4", 1.0, 15, 313, function()
 return
 globals.get_int(1967697)
 end, function(value)
 globals.set_int(1967697, value)
 end)


CSYONSPERICO:add_array_item("Presets", {"H.Panther Only", "H.PinkD Only", "H.B.Bonds Only", "H.R.Necklace Only", "H.Tequila Only", "N.Panther Only", "N.PinkD Only", "N.B.Bonds Only", "N.R.Necklace Only", "N.Tequila Only"}, function()
 return xox_15 end, function(v)
 if v == 1
 then
 stats.set_int(MPX().."H4_PROGRESS", 131055)
 stats.set_int(MPX().."H4_MISSIONS", 65535)
 stats.set_int(MPX().."H4CNF_TARGET", 5)
 stats.set_int(MPX().."H4CNF_WEAPONS", 2)
 stats.set_int(MPX().."H4CNF_UNIFORM", -1)
 stats.set_int(MPX().."H4CNF_TROJAN", 5)
 stats.set_int(MPX().."H4LOOT_GOLD_C", 0)
 stats.set_int(MPX().."H4LOOT_GOLD_C_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_PAINT", 0)
 stats.set_int(MPX().."H4LOOT_PAINT_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_PAINT_V", 403500)
 stats.set_int(MPX().."H4LOOT_CASH_I", 0)
 stats.set_int(MPX().."H4LOOT_CASH_C", 0)
 stats.set_int(MPX().."H4LOOT_WEED_I", 0)
 stats.set_int(MPX().."H4LOOT_COKE_I", 0)
 elseif v == 2
 then
 stats.set_int(MPX().."H4_PROGRESS", 131055)
 stats.set_int(MPX().."H4_MISSIONS", 65535)
 stats.set_int(MPX().."H4CNF_TARGET", 3)
 stats.set_int(MPX().."H4CNF_WEAPONS", 2)
 stats.set_int(MPX().."H4CNF_UNIFORM", -1)
 stats.set_int(MPX().."H4CNF_TROJAN", 5)
 stats.set_int(MPX().."H4LOOT_GOLD_C", 0)
 stats.set_int(MPX().."H4LOOT_GOLD_C_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_PAINT", 0)
 stats.set_int(MPX().."H4LOOT_PAINT_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_CASH_I", 0)
 stats.set_int(MPX().."H4LOOT_CASH_C", 0)
 stats.set_int(MPX().."H4LOOT_WEED_I", 0)
 stats.set_int(MPX().."H4LOOT_COKE_I", 0)
 elseif v == 3
 then
 stats.set_int(MPX().."H4_PROGRESS", 131055)
 stats.set_int(MPX().."H4_MISSIONS", 65535)
 stats.set_int(MPX().."H4CNF_TARGET", 2)
 stats.set_int(MPX().."H4CNF_WEAPONS", 2)
 stats.set_int(MPX().."H4CNF_UNIFORM", -1)
 stats.set_int(MPX().."H4CNF_TROJAN", 5)
 stats.set_int(MPX().."H4LOOT_GOLD_C", 0)
 stats.set_int(MPX().."H4LOOT_GOLD_C_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_PAINT", 0)
 stats.set_int(MPX().."H4LOOT_PAINT_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_CASH_I", 0)
 stats.set_int(MPX().."H4LOOT_CASH_C", 0)
 stats.set_int(MPX().."H4LOOT_WEED_I", 0)
 stats.set_int(MPX().."H4LOOT_COKE_I", 0)
 elseif v == 4
 then
 stats.set_int(MPX().."H4_PROGRESS", 131055)
 stats.set_int(MPX().."H4_MISSIONS", 65535)
 stats.set_int(MPX().."H4CNF_TARGET", 1)
 stats.set_int(MPX().."H4CNF_WEAPONS", 2)
 stats.set_int(MPX().."H4CNF_UNIFORM", -1)
 stats.set_int(MPX().."H4CNF_TROJAN", 5)
 stats.set_int(MPX().."H4LOOT_GOLD_C", 0)
 stats.set_int(MPX().."H4LOOT_GOLD_C_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_PAINT", 0)
 stats.set_int(MPX().."H4LOOT_PAINT_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_CASH_I", 0)
 stats.set_int(MPX().."H4LOOT_CASH_C", 0)
 stats.set_int(MPX().."H4LOOT_WEED_I", 0)
 stats.set_int(MPX().."H4LOOT_COKE_I", 0)
 elseif v == 5
 then
 stats.set_int(MPX().."H4_PROGRESS", 131055)
 stats.set_int(MPX().."H4_MISSIONS", 65535)
 stats.set_int(MPX().."H4CNF_TARGET", 0)
 stats.set_int(MPX().."H4CNF_WEAPONS", 2)
 stats.set_int(MPX().."H4CNF_UNIFORM", -1)
 stats.set_int(MPX().."H4CNF_TROJAN", 5)
 stats.set_int(MPX().."H4LOOT_GOLD_C", 0)
 stats.set_int(MPX().."H4LOOT_GOLD_C_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_PAINT", 0)
 stats.set_int(MPX().."H4LOOT_PAINT_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_CASH_I", 0)
 stats.set_int(MPX().."H4LOOT_CASH_C", 0)
 stats.set_int(MPX().."H4LOOT_WEED_I", 0)
 stats.set_int(MPX().."H4LOOT_COKE_I", 0)
 elseif v == 6
 then
 stats.set_int(MPX().."H4_PROGRESS", 126823)
 stats.set_int(MPX().."H4_MISSIONS", 65535)
 stats.set_int(MPX().."H4CNF_TARGET", 5)
 stats.set_int(MPX().."H4CNF_WEAPONS", 2)
 stats.set_int(MPX().."H4CNF_UNIFORM", -1)
 stats.set_int(MPX().."H4CNF_TROJAN", 5)
 stats.set_int(MPX().."H4LOOT_GOLD_C", 0)
 stats.set_int(MPX().."H4LOOT_GOLD_C_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_PAINT", 0)
 stats.set_int(MPX().."H4LOOT_PAINT_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_CASH_I", 0)
 stats.set_int(MPX().."H4LOOT_CASH_C", 0)
 stats.set_int(MPX().."H4LOOT_WEED_I", 0)
 stats.set_int(MPX().."H4LOOT_COKE_I", 0)
 elseif v == 7
 then
 stats.set_int(MPX().."H4_PROGRESS", 126823)
 stats.set_int(MPX().."H4_MISSIONS", 65535)
 stats.set_int(MPX().."H4CNF_TARGET", 3)
 stats.set_int(MPX().."H4CNF_WEAPONS", 2)
 stats.set_int(MPX().."H4CNF_UNIFORM", -1)
 stats.set_int(MPX().."H4CNF_TROJAN", 5)
 stats.set_int(MPX().."H4LOOT_GOLD_C", 0)
 stats.set_int(MPX().."H4LOOT_GOLD_C_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_PAINT", 0)
 stats.set_int(MPX().."H4LOOT_PAINT_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_CASH_I", 0)
 stats.set_int(MPX().."H4LOOT_CASH_C", 0)
 stats.set_int(MPX().."H4LOOT_WEED_I", 0)
 stats.set_int(MPX().."H4LOOT_COKE_I", 0)
 elseif v == 8
 then
 stats.set_int(MPX().."H4_PROGRESS", 126823)
 stats.set_int(MPX().."H4_MISSIONS", 65535)
 stats.set_int(MPX().."H4CNF_TARGET", 2)
 stats.set_int(MPX().."H4CNF_WEAPONS", 2)
 stats.set_int(MPX().."H4CNF_UNIFORM", -1)
 stats.set_int(MPX().."H4CNF_TROJAN", 5)
 stats.set_int(MPX().."H4LOOT_GOLD_C", 0)
 stats.set_int(MPX().."H4LOOT_GOLD_C_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_PAINT", 0)
 stats.set_int(MPX().."H4LOOT_PAINT_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_CASH_I", 0)
 stats.set_int(MPX().."H4LOOT_CASH_C", 0)
 stats.set_int(MPX().."H4LOOT_WEED_I", 0)
 stats.set_int(MPX().."H4LOOT_COKE_I", 0)
 elseif v == 9
 then
 stats.set_int(MPX().."H4_PROGRESS", 126823)
 stats.set_int(MPX().."H4_MISSIONS", 65535)
 stats.set_int(MPX().."H4CNF_TARGET", 1)
 stats.set_int(MPX().."H4CNF_WEAPONS", 2)
 stats.set_int(MPX().."H4CNF_UNIFORM", -1)
 stats.set_int(MPX().."H4CNF_TROJAN", 5)
 stats.set_int(MPX().."H4LOOT_GOLD_C", 0)
 stats.set_int(MPX().."H4LOOT_GOLD_C_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_PAINT", 0)
 stats.set_int(MPX().."H4LOOT_PAINT_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_PAINT_V", 403500)
 stats.set_int(MPX().."H4LOOT_CASH_I", 0)
 stats.set_int(MPX().."H4LOOT_CASH_C", 0)
 stats.set_int(MPX().."H4LOOT_WEED_I", 0)
 stats.set_int(MPX().."H4LOOT_COKE_I", 0)
 elseif v == 10
 then
 stats.set_int(MPX().."H4_PROGRESS", 126823)
 stats.set_int(MPX().."H4_MISSIONS", 65535)
 stats.set_int(MPX().."H4CNF_TARGET", 0)
 stats.set_int(MPX().."H4CNF_WEAPONS", 2)
 stats.set_int(MPX().."H4CNF_UNIFORM", -1)
 stats.set_int(MPX().."H4CNF_TROJAN", 5)
 stats.set_int(MPX().."H4LOOT_GOLD_C", 0)
 stats.set_int(MPX().."H4LOOT_GOLD_C_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_PAINT", 0)
 stats.set_int(MPX().."H4LOOT_PAINT_SCOPED", 0)
 stats.set_int(MPX().."H4LOOT_CASH_I", 0)
 stats.set_int(MPX().."H4LOOT_CASH_C", 0)
 stats.set_int(MPX().."H4LOOT_WEED_I", 0)
 end
 xox_15 = v
 end)

CSYONSPERICO:add_array_item("Primary Target", {"Tequila", "Ruby Necklace", "Bearer Bonds", "Pink Diamond", "Panther Statue"}, function()
 return
 xox_0 end, function(value)
 xox_0 = value
 if value == 1
 then
 stats.set_int(MPX() .. "H4CNF_TARGET", 0)
 elseif
 value == 2
 then
 stats.set_int(MPX() .. "H4CNF_TARGET", 1)
 elseif
 value == 3
 then
 stats.set_int(MPX() .. "H4CNF_TARGET", 2)
 elseif
 value == 4
 then
 stats.set_int(MPX() .. "H4CNF_TARGET", 3)
 elseif
 value == 5
 then
 stats.set_int(MPX() .. "H4CNF_TARGET", 5)
 end
 end)

CSYONP = CSYONSPERICO:add_submenu("Secondary Targets") 
CSYONP:add_array_item("All Compound Storages", {"Gold", "Paintings", "Cocaine", "Weed", "Cash"}, function()
 return
 xox_1 end, function(value)
 if value == 1
 then
 stats.set_int(MPX() .. "H4LOOT_GOLD_C", -1)
 stats.set_int(MPX() .. "H4LOOT_GOLD_C_SCOPED", -1)
 elseif
 value == 2
 then
 stats.set_int(MPX() .. "H4LOOT_PAINT", -1)
 stats.set_int(MPX() .. "H4LOOT_PAINT_SCOPED", -1)
 stats.set_int(MPX() .. "H4LOOT_PAINT_V", 403500)
 elseif
 value == 3
 then
 stats.set_int(MPX() .. "H4LOOT_COKE_C", -1)
 stats.set_int(MPX() .. "H4LOOT_COKE_C_SCOPED", -1)
 elseif
 value == 4
 then
 stats.set_int(MPX() .. "H4LOOT_WEED_C", -1)
 stats.set_int(MPX() .. "H4LOOT_WEED_C_SCOPED", -1)
 elseif
 value == 5
 then
 stats.set_int(MPX() .. "H4LOOT_CASH_C", -1)
 stats.set_int(MPX() .. "H4LOOT_CASH_C_SCOPED", -1)
 end
 xox_1 = value
 end)

CSYONP:add_array_item("All Island Storages", {"Gold", "Cocaine", "Weed", "Cash"}, function()
 return
 xox_2 end, function(value)
 if value == 1
 then
 stats.set_int(MPX() .. "H4LOOT_GOLD_I", -1)
 stats.set_int(MPX() .. "H4LOOT_GOLD_I_SCOPED", -1)
 elseif
 value == 2
 then
 stats.set_int(MPX() .. "H4LOOT_COKE_I", -1)
 stats.set_int(MPX() .. "H4LOOT_COKE_I_SCOPED", -1)
 elseif
 value == 3
 then
 stats.set_int(MPX() .. "H4LOOT_WEED_I", -1)
 stats.set_int(MPX() .. "H4LOOT_WEED_I_SCOPED", -1)
 elseif
 value == 4
 then
 stats.set_int(MPX() .. "H4LOOT_CASH_I", -1)
 stats.set_int(MPX() .. "H4LOOT_CASH_I_SCOPED", -1)
 end
 xox_2 = value
 end) 

CSYONSPERICO:add_array_item("Weapons", {"Aggressor", "Conspirator", "Crackshot", "Saboteur", "Marksman"}, function()
 return xox_3 end, function(value)
 if value == 1
 then
 stats.set_int(MPX() .. "H4CNF_WEAPONS", 1)
 elseif value == 2
 then
 stats.set_int(MPX() .. "H4CNF_WEAPONS", 2)
 elseif value == 3
 then
 stats.set_int(MPX() .. "H4CNF_WEAPONS", 3)
 elseif value == 4
 then
 stats.set_int(MPX() .. "H4CNF_WEAPONS", 4)
 elseif value == 5
 then
 stats.set_int(MPX() .. "H4CNF_WEAPONS", 5)
 end
 xox_3 = value
 end)

CSYONSPERICO:add_array_item("Approach Vehicles", {"Kosatka", "Alkonost", "Velum", "Stealth Annihilator", "Patrol Boat", "Longfin", "All Vehicles"}, function() return xox_4 end, function(value) if value == 1 then stats.set_int(MPX() .. "H4_MISSIONS", 65283) elseif value == 2 then stats.set_int(MPX() .. "H4_MISSIONS", 65413) elseif value == 3 then stats.set_int(MPX() .. "H4_MISSIONS", 65289) elseif value == 4 then stats.set_int(MPX() .. "H4_MISSIONS", 65425) elseif value == 5 then stats.set_int(MPX() .. "H4_MISSIONS", 65313) elseif value == 6 then stats.set_int(MPX() .. "H4_MISSIONS", 65345) elseif value == 7 then stats.set_int(MPX() .. "H4_MISSIONS", 65535) end xox_4 = value end)	
CSYONSPERICO:add_array_item("Difficulty", {"Normal", "Hard"}, function() return xox_5 end, function(value) if value == 1 then stats.set_int(MPX() .. "H4_PROGRESS", 126823) elseif value == 2 then stats.set_int(MPX() .. "H4_PROGRESS", 131055) end xox_5 = value end)
CSYONSPERICO:add_action("       ---> Complete Preps - Finale <---", function() stats.set_int(MPX() .. "H4CNF_UNIFORM", -1) stats.set_int(MPX() .. "H4CNF_GRAPPEL", -1) stats.set_int(MPX() .. "H4CNF_TROJAN", 5) stats.set_int(MPX() .. "H4CNF_WEP_DISRP", 3) stats.set_int(MPX() .. "H4CNF_ARM_DISRP", 3) stats.set_int(MPX() .. "H4CNF_HEL_DISRP", 3) end)
CSYONSPERICO:add_action("All POI", function() stats.set_int(MPX() .. "H4CNF_BS_GEN", -1) stats.set_int(MPX() .. "H4CNF_BS_ENTR", 63) stats.set_int(MPX() .. "H4CNF_APPROACH", -1) end) CSYONSPERICO:add_action("---", function() end)
CSYONSPERICO:add_action("Instant Finish $$", function() fmC2020:set_int(42280, 51338752) fmC2020:set_int(43655, 50) end) --Local_42279.f_1375[1] & Local_42279.f_1

CsyonCayoPerico =  CSYONSPERICO :add_submenu("Skip Cayo Perico Cooldown Menu")

CsyonCayoPerico:add_action("Skip Cayo Cooldown (Friends Mode)", function()
	 mpIndex = globals.get_int(1574918)
	 if mpIndex == 0 then
				  stats.set_int("MP0_H4_TARGET_POSIX", 1659429119)  --[[1659429119 Parameter Set]]
		  stats.set_int("MP0_H4_COOLDOWN", 0)
			  stats.set_int("MP0_H4_COOLDOWN_HARD", 0)
	 else
		   stats.set_int("MP1_H4_COOLDOWN", 0)
				   stats.set_int("MP1_H4_TARGET_POSIX", 1659429119)
		   stats.set_int("MP1_H4_COOLDOWN_HARD", 0)
	 end
 end)
 
 CsyonCayoPerico:add_action("Skip Cayo Cooldown (Solo Mode)", function()
	 mpIndex = globals.get_int(1574918)
	 if mpIndex == 0 then
				  stats.set_int("MP0_H4_TARGET_POSIX", 1659643454)  --[[1659643454 Paramter Set]]
		   stats.set_int("MP0_H4_COOLDOWN", 0)
			  stats.set_int("MP0_H4_COOLDOWN_HARD", 0)
	 else
		  stats.set_int("MP1_H4_COOLDOWN", 0)
				  stats.set_int("MP1_H4_TARGET_POSIX", 1659643454)
		  stats.set_int("MP1_H4_COOLDOWN_HARD", 0)
	 end 
 end)

CSYONSPERICO:add_action("(Wait 5 secs to use after cutscene)", function() end)CSYONSPERICO:add_action("---", function() end) local function npcC(e) if not localplayer then return end if e then globals.set_float(RPN1, 0) globals.set_float(RPN2, 0) else globals.set_float(RPN1, -0.1) globals.set_float(RPN2, -0.02) end end CSYONSPERICO:add_toggle("Remove Pavel n Fencing Cut", function() return e28 end, function() e28 = not e28 npcC(e28) end) local function Cctv(e) if not localplayer then return end if e then menu.remove_cctvs() else menu.remove_cctvs(nil) end end
CSYONSPERICO:add_toggle("Remove CCTV", function() return e6 end, function() e6 = not e6 Cctv(e6) end) CSYONSPERICO:add_action("Skip Drainage cut", function() if fmC2020:is_active() then if fmC2020:get_int(26746) >= 3 or fmC2020:get_int(26746) <= 6 then fmC2020:set_int(26746, 6) end end end) CSYONSPERICO:add_action("Bypass Fingerprint Cloner ", function() if fmC2020 and fmC2020:is_active() then if fmC2020:get_int(22032) == 4 then fmC2020:set_int(22032, 5) end end end)
CSYONSPERICO:add_action("Quick Plasma Cutter", function() fmC2020:set_float(27985 + 3, 99.9) end) CSYONSPERICO:add_int_range("Cayo Lifes - Self", 1.0, 1, 999999999, function() return fmC2020:get_int(48647 + 865 + 1) end, function(life) if fmC2020 and fmC2020:is_active() then fmC2020:set_int(48647 + 865 + 1, life) end end) CSYONSPERICO:add_action("Kill mission npcs", function() menu.kill_all_mission_peds() end) CSYONSPERICO:add_action("Kill all npcs", function() menu.kill_all_npcs() end) CSYONSPERICO:add_action("---", function() end)
CSYONSPERICO:add_int_range("Real Take", 289700, 100000, 8691000, function() return fmC2020:get_int(45687+1392+53) end, function(v) fmC2020:set_int(45687+1392+53, v) end)
CSYONSPERICO:add_array_item("TP's Scope Out", {"Communications Tower", "Control Tower", "Power Station", "Bolt Cutters #1", "Bolt Cutters #2", "Bolt Cutters #3", "Bolt Cutters #4", "Bolt Cutters #5", "Bolt Cutters #6", "Bolt Cutters #7", "Bolt Cutters #8", "Bolt Cutters #9", "Bolt Cutters #10", "Bolt Cutters #11", "Bolt Cutters #12", "Bolt Cutters #13", "Bolt Cutters #14", "Bolt Cutters #15", "Cutting Powder #1", "Cutting Powder #2", "Cutting Powder #3", "Grappling Hook #1", "Grappling Hook #2", "Grappling Hook #3", "Grappling Hook #4", "Grappling Hook #5", "Grappling Hook #6", "Grappling Hook #7", "Grappling Hook #8", "Grappling Hook #9", "Grappling Hook #10", "Guard Clothes #1", "Guard Clothes #2", "Guard Clothes #3", "Guard Clothes #4", "Guard Clothes #5", "Guard Clothes #6", "Guard Clothes #7", "Signal Box #1", "Signal Box #2", "Signal Box #3", "Supply Truck #1", "Supply Truck #2", "Supply Truck #3", "Supply Truck #4", "Water Tower #1 (North Dock)", "Water Tower #2 (Main Dock)"}, function()
return xox_6 end, function(value)
if value == 1 then TP(5266.797363, -5427.772461, 139.746445, -0.943473, 0.000000, -0.000000)
elseif value == 2 then TP(4350.219238, -4577.410645, 2.899095, -1.119934, -0.000000, 0.000000)
elseif value == 3 then TP(4478.291992, -4580.129883, 4.258523, -2.885009, -0.000000, 0.000000)
elseif value == 4 then TP(5097.452637, -4620.177734, 1.193875, -2.592525, -0.000000, 0.000000)
elseif value == 5 then TP(4880.295898, -5112.941406, 1.053022, 1.313561, -0.000346, 0.000020)
elseif value == 6 then TP(4537.624512, -4542.424805, 3.546365, 1.941974, 0.000004, -0.000007)
elseif value == 7 then TP(5466.320801, -5230.169922, 25.993027, 2.763307, -0.000000, 0.000000)
elseif value == 8 then TP(4075.548828, -4663.984863, 2.994547, -2.552265, -0.000000, 0.000000)
elseif value == 9 then TP(4522.588867, -4509.868652, 3.188455, -2.631163, -0.000000, 0.000000)
elseif value == 10 then TP(4506.013672, -4656.211914, 10.579565, -0.049160, -0.000000, 0.000000)
elseif value == 11 then TP(4803.885742, -4317.895020, 6.201560, -0.422076, -0.000000, 0.000000)
elseif value == 12 then TP(5071.072266, -4639.869629, 2.112077, 0.523910, 0.000000, -0.000000)
elseif value == 13 then TP(5179.191895, -4669.967285, 5.832691, -2.465155, -0.000000, 0.000000)
elseif value == 14 then TP(5214.377441, -5126.496582, 4.925748, -1.519287, -0.000000, 0.000000)
elseif value == 15 then TP(4954.719727, -5180.171875, 2.966018, -2.558609, -0.000000, 0.000000)
elseif value == 16 then TP(4903.507812, -5345.524414, 8.850177, 2.197429, -0.000000, 0.000000)
elseif value == 17 then TP(4756.349609, -5539.995605, 17.625168, 2.077786, -0.000000, 0.000000)
elseif value == 18 then TP(5365.069336, -5438.819824, 47.831707, 0.996262, -0.000000, 0.000000)
elseif value == 19 then TP(5404.111328, -5171.486328, 30.132875, -0.749873, -0.000000, 0.000000)
elseif value == 20 then TP(5214.664551, -5131.837402, 4.938407, -1.654735, -0.000000, 0.000000)
elseif value == 21 then TP(4924.137695, -5271.690918, 4.351841, -2.826915, -0.000000, 0.000000)
elseif value == 22 then TP(4901.115723, -5332.090820, 27.841076, -0.469437, -0.000000, 0.000000)
elseif value == 23 then TP(4882.464355, -4487.831543, 8.713233, 1.552495, -0.000000, 0.000000)
elseif value == 24 then TP(5609.771484, -5653.084473, 8.651618, -2.502223, -0.000000, 0.000000)
elseif value == 25 then TP(5125.838379, -5095.626953, 0.893209, 2.800476, -0.000000, 0.000000)
elseif value == 26 then TP(4529.709961, -4700.855957, 3.120182, 2.906318, -0.000000, 0.000000)
elseif value == 27 then TP(3901.137451, -4690.617676, 2.826484, 2.661214, -0.000000, 0.000000)
elseif value == 28 then TP(5404.485840, -5170.345215, 30.130934, -1.991591, -0.000000, 0.000000)
elseif value == 29 then TP(5333.016602, -5264.369629, 31.446018, 1.854885, -0.000000, 0.000000)
elseif value == 30 then TP(5110.171387, -4579.133301, 28.417776, 0.901852, -0.000000, 0.000000)
elseif value == 31 then TP(5267.243164, -5429.493164, 139.747177, 2.378908, -0.000000, 0.000000)
elseif value == 32 then TP(5059.213867, -4592.870605, 1.595251, -0.291761, -0.000000, 0.000000)
elseif value == 33 then TP(4949.736328, -5320.138672, 6.776219, 3.108989, -0.000000, 0.000000)
elseif value == 34 then TP(4884.802734, -5452.898926, 29.437197, -2.087807, -0.000000, 0.000000)
elseif value == 35 then TP(4764.295898, -4781.471680, 2.501517, -0.586741, -0.000000, 0.000000)
elseif value == 36 then TP(5170.228516, -4677.545898, 1.122545, -0.371411, -0.000000, 0.000000)
elseif value == 37 then TP(5161.595215, -4993.595215, 11.394773, -2.397844, -0.000000, 0.000000)
elseif value == 38 then TP(5128.021484, -5530.752930, 52.743076, 1.605217, -0.000000, 0.000000)
elseif value == 39 then TP(5262.136719, -5432.140625, 64.297203, 2.467814, -0.000000, 0.000000)
elseif value == 40 then TP(5265.863281, -5421.060059, 64.297638, 0.805274, -0.000000, 0.000000)
elseif value == 41 then TP(5266.750977, -5426.982910, 139.746857, -0.631726, -0.000000, 0.000000)
elseif value == 42 then TP(4517.433105, -4531.979492, 2.820656, -1.275829, -0.000000, 0.000000)
elseif value == 43 then TP(5148.460938, -4620.099121, 1.108461, -1.422905, -0.000000, 0.000000)
elseif value == 44 then TP(4901.324219, -5216.216797, 2.768269, -2.631163, -0.000000, 0.000000)
elseif value == 45 then TP(5152.886719, -5143.897949, 0.997772, -0.205993, -0.000000, 0.000000)
elseif value == 46 then TP(5108.437012, -4580.132812, 28.417776, 1.720010, -0.000000, 0.000000)
elseif value == 47 then TP(4903.939453, -5337.220703, 34.306366, 0.821753, -0.000000, 0.000000)
end xox_6 = value end)
CSYONSPERICO:add_array_item("TP's Heist", {"Drainage Pipe", "Entry Drain", "Cayo Office", "Cayo Primary", "Basement Storage", "North Storage", "West Storage", "South Storage", "Cayo Gate", "Escaped"}, function() return xox_7 end, function(value)
if value == 1 then menu.end_cutscene() TP(5045.980957, -5816.833984, -11.489866, 0.884011, -0.000000, 0.000121)
elseif value == 2 then TP(5052.879395, -5771.335938, -6.004176, 1.169803, -0.000000, 0.001638)
elseif value == 3 then menu.end_cutscene() TP(5005.557617, -5754.321289, 27.545269, 2.586560, -0.000000, 0.000000)
elseif value == 4 then menu.end_cutscene() TP(5007.763184, -5756.029785, 14.184443, 2.467127, -0.000000, 0.000000)
elseif value == 5 then menu.end_cutscene() TP(4999.613281, -5749.913086, 13.540487, 2.613005, -0.000000, 0.000000)
elseif value == 6 then TP(5080.862305, -5756.300781, 14.529651, -0.575850, -0.000000, 0.000000)
elseif value == 7 then TP(5030.722168, -5736.470703, 16.565588, 2.439484, -0.000000, 0.000000)
elseif value == 8 then TP(5007.434570, -5787.255859, 16.531698, 0.680315, -0.000000, 0.000000)
elseif value == 9 then menu.end_cutscene() TP(4990.194824, -5716.448730, 18.580215, 0.946360, -0.000000, 0.000000)
elseif value == 10 then menu.end_cutscene() TP(4639.124023, -6010.004883, -7.475036, 1.930023, -0.000000, -0.000000)

end xox_7 = value end) CsyonCutsMenu = CSYONSPERICO:add_submenu("Cuts") CsyonCutsMenu:add_array_item("Preset cuts", {"65 all", "80 all", "90 all", "100 all", "138 all-Panther only", "202 all-PinkD only"}, function() return xox_32 end, function(G) if G == 1 then for i = 1978573, 1978576 do globals.set_int(i, 65) end elseif G == 2 then for i = 1978573, 1978576 do globals.set_int(i, 80) end elseif G == 3 then for i = 1978573, 1978576 do globals.set_int(i, 90) end elseif G == 4 then for i = 1978573, 1978576 do globals.set_int(i, 100) end elseif G == 5 then for i = 1978573, 1978576 do globals.set_int(i, 138) end elseif G == 6 then for i = 1978573, 1978576 do globals.set_int(i, 202) end end xox_32 = value end)
CsyonCutsMenu:add_int_range("Player 1", 1, 15, 300, function() return globals.get_int(1978573) end, function(value) globals.set_int(1978573, value) end) CsyonCutsMenu:add_int_range("Player 2", 1, 15, 300, function() return globals.get_int(1978574) end, function(value) globals.set_int(1978574, value) end) CsyonCutsMenu:add_int_range("Player 3", 1, 15, 300, function() return globals.get_int(1978575) end, function(value) globals.set_int(1978575, value) end) CsyonCutsMenu:add_int_range("Player 4", 1, 15, 300, function() return globals.get_int(1978576) end, function(value) globals.set_int(1978576, value) end) CsyonCutsMenu:add_int_range("Non-Host Self", 1, 15, 300, function() return globals.get_int(2722267) end, function(value) globals.set_int(2722267, value) end)
CsyonCPMenu = CSYONSPERICO:add_submenu("Size/Value Editor") CsyonCPMenu:add_int_range("Bag Size", 900.0, 1800, 99999, function() return globals.get_int(BAS1) end, function(value) globals.set_int(BAS1, value) end) CsyonCPMenu:add_int_range("Panther Statue", 50000, 1900000, 25500000, function() return globals.get_int(PAS1) end, function(value) globals.set_int(PAS1, value) end) CsyonCPMenu:add_int_range("Pink Diamond", 50000, 1300000, 25500000, function() return globals.get_int(PID1) end, function(value) globals.set_int(PID1, value) end) CsyonCPMenu:add_int_range("Bearer Bonds", 50000, 1100000, 25500000, function() return globals.get_int(BEB1) end, function(value) globals.set_int(BEB1, value) end) CsyonCPMenu:add_int_range("Ruby Necklace", 50000, 1000000, 25500000, function() return globals.get_int(RUN1) end, function(value) globals.set_int(RUN1, value) end) CsyonCPMenu:add_int_range("Tequila", 50000, 900000, 25500000, function() return globals.get_int(TEQ1) end, function(value) globals.set_int(TEQ1, value) end) CsyonCPMenu:add_int_range("Gold", 82587, 330350, 5000000, function() return stats.get_int(MPX .. "H4LOOT_GOLD_V") end, function(value) stats.set_int(MPX .. "H4LOOT_GOLD_V", value) end) CsyonCPMenu:add_int_range("Paintings", 50000, 189500, 5000000, function() return stats.get_int(MPX .. "H4LOOT_PAINT_V") end, function(value) stats.set_int(MPX .. "H4LOOT_PAINT_V", value) end) CsyonCPMenu:add_int_range("Cocaine", 50000, 200095, 5000000, function() return stats.get_int(MPX .. "H4LOOT_COKE_V") end, function(value) stats.set_int(MPX .. "H4LOOT_COKE_V", value) end) CsyonCPMenu:add_int_range("Weed", 50000, 147870, 5000000, function() return stats.get_int(MPX .. "H4LOOT_WEED_V") end, function(value) stats.set_int(MPX .. "H4LOOT_WEED_V", value) end) CsyonCPMenu:add_int_range("Cash", 50000, 90000, 5000000, function() return stats.get_int(MPX .. "H4LOOT_CASH_V") end, function(value) stats.set_int(MPX .. "H4LOOT_CASH_V", value) end) CsyonCPMenu:add_action("--For default values, Dont Change", function() end)


local CSYONCASINO = CSYONCASINO:add_submenu("Casino Heists Editor")
PlayerIndex = globals.get_int(1574918)

	if PlayerIndex == 0 then
		MPX = "MP0_"
	else
		MPX = "MP1_"
	end
 
local function Text(text)
	CSYONCASINO:add_action(text, function() end)
end
Text(" _______________Casino Setup________________")
 
CSYONCASINO:add_int_range("Target - Cash1/Gold2/Art3/Diam4", 1, 1, 4, function() return stats.get_int(MPX .. "H3OPT_TARGET") end, function(TGT)
	PlayerIndex = globals.get_int(1574918)
	if PlayerIndex == 0 then
		MPX = "MP0_"
	else
		MPX = "MP1_"
	end
	if TGT == 1 then
		H3t = 0
	elseif TGT == 2 then
		H3t = 1
	elseif TGT == 3 then
		H3t = 2
	elseif TGT == 4 then
		H3t = 3
	end
		stats.set_int(MPX .. "H3OPT_TARGET", H3t)
end)

CSYONCASINO:add_int_range("Random Approach - Normal/Hard", 1, 1, 2, function() return 1 end, function(H3lvl)
	LstAp = stats.get_int(MPX() .. "H3_LAST_APPROACH")
	HrdAp = stats.get_int(MPX() .. "H3_HARD_APPROACH")
	PlayerIndex = globals.get_int(1574918)
	if PlayerIndex == 0 then
		MPX = "MP0_"
	else
		MPX = "MP1_"
	end
	if H3lvl == 2 then
		Apr = HrdAp
	else
		if LstAp == 2 and HrdAp == 3 then
		Apr = 1
		elseif LstAp == 3 and HrdAp == 2 then
		Apr = 1
		elseif LstAp == 3 and HrdAp == 1 then
		Apr = 2
		elseif LstAp == 1 and HrdAp == 3 then
		Apr = 2
		else
		Apr = 3
		end
	end
		stats.set_int(MPX .. "H3OPT_APPROACH", Apr)
end)
 
CSYONCASINO:add_int_range("EasyApproach - Snk/BgCon/Aggr", 1, 1, 3, function() return 1 end, function(Approach)
	PlayerIndex = globals.get_int(1574918)
	if PlayerIndex == 0 then
		MPX = "MP0_"
	else
		MPX = "MP1_"
	end
	if Approach == 1 then
		LastApproach = 3
		HardApproach = 2
		Weapon = 1
	elseif Approach == 2 then
		LastApproach = 3
		HardApproach = 1
		Weapon = 0
	else
		LastApproach = 1
		HardApproach = 2
		Weapon = 0
	end
		stats.set_int(MPX .. "H3_LAST_APPROACH", LastApproach)
		stats.set_int(MPX .. "H3_HARD_APPROACH", HardApproach)
		stats.set_int(MPX .. "H3OPT_APPROACH", Approach)
end)
 
CSYONCASINO:add_int_range("HardApproach - Snk/BgCon/Aggr", 1, 1, 3, function() return stats.get_int(MPX .. "H3_HARD_APPROACH") end, function(Approach)
	PlayerIndex = globals.get_int(1574918)
	if PlayerIndex == 0 then
		MPX = "MP0_"
	else
		MPX = "MP1_"
	end
	if Approach == 1 then
		LastApproach = 3
		HardApproach = 1
	elseif Approach == 2 then
		LastApproach = 3
		HardApproach = 2
	else
		LastApproach = 1
		HardApproach = 3
	end
		stats.set_int(MPX .. "H3_LAST_APPROACH", LastApproach)
		stats.set_int(MPX .. "H3_HARD_APPROACH", Approach)
		stats.set_int(MPX .. "H3OPT_APPROACH", Approach)
end)
 
CSYONCASINO:add_action("             ---[[Complete Board1]]---", function()
	PlayerIndex = globals.get_int(1574918)
	if PlayerIndex == 0 then
		MPX = "MP0_"
	else
		MPX = "MP1_"
	end
		stats.set_int(MPX .. "H3OPT_BITSET1", -1)
end)
 
CSYONCASINO:add_int_range("Hacker - Rickie 3%/Avi 10%/Paige 9%", 1, 1, 3, function() return stats.get_int(MPX .. "H3OPT_CREWHACKER") end, function(Hkr)
	PlayerIndex = globals.get_int(1574918)
	if PlayerIndex == 0 then
		MPX = "MP0_"
	else
		MPX = "MP1_"
	end
	if Hkr == 1 then
		H3Hcr = 1
	elseif Hkr == 2 then
		H3Hcr = 4
	else
		H3Hcr = 5
	end
		stats.set_int(MPX .. "H3OPT_CREWHACKER", H3Hcr)
end)
 

CSYONCASINO:add_int_range("Grlla/Clwn/Anml9/Riot/OniF/Hockey", 1, 1, 12, function() return stats.get_int(MPX .. "H3OPT_MASKS") end, function(H3Msk)
	PlayerIndex = globals.get_int(1574918)
	if PlayerIndex == 0 then
		MPX = "MP0_"
	else
		MPX = "MP1_"
	end
--	hMsk = H3Msk
		stats.set_int(MPX .. "H3OPT_MASKS", H3Msk)
end)

CSYONCASINO:add_int_range("Weap-Karl/Gus/Char/Ches/Pat", 1, 1, 5, function() return stats.get_int(MPX .. "H3OPT_CREWWEAP") end, function(H3Weap)
	PlayerIndex = globals.get_int(1574918)
	if PlayerIndex == 0 then
		MPX = "MP0_"
	else
		MPX = "MP1_"
	end
--	hWeap = H3Weap
		stats.set_int(MPX .. "H3OPT_CREWWEAP", H3Weap)
end)
 
CSYONCASINO:add_action("       ---[[Complete Board2 - Finale]]---", function()
	PlayerIndex = globals.get_int(1574918)
	if PlayerIndex == 0 then
		MPX = "MP0_"
	else
		MPX = "MP1_"
	end
		stats.set_int(MPX .. "H3OPT_DISRUPTSHIP", 3)
		stats.set_int(MPX .. "H3OPT_KEYLEVELS", 2)
		stats.set_int(MPX .. "H3OPT_CREWWEAP", 1)
		stats.set_int(MPX .. "H3OPT_CREWDRIVER", 1)
		stats.set_int(MPX .. "H3OPT_VEHS", 3)
		stats.set_int(MPX .. "H3OPT_WEAPS", 0)
		stats.set_int(MPX .. "H3OPT_BITSET0", -129)
end)

local DPCO=1966533 + 1497 + 736 + 92 
local CSK=1973320 + 823 + 56 	
local MPX = stats.get_int("MPPLY_LAST_MP_CHAR")
local Weapon = 0
local function Text(text)
	CSYONCASINO:add_action(text, function() end)
end
Text("--------------Casino Cuts--------------------")
 
CSYONCASINO:add_int_range("Casino Player1 Cut", 5.0, 15, 100, function() 
	return globals.get_int(1970895+2325+1)
end, function(value)
	globals.set_int(1970895+2325+1, value)
H3C1 = p1
end)
 
CSYONCASINO:add_int_range("Casino Player2 Cut", 5.0, 15, 100, function() 
	return globals.get_int(1970895+2325+1+1)
end, function(value)
	globals.set_int(1970895+2325+1+1, value)
H3C2 = p2

end)
 
CSYONCASINO:add_int_range("Casino Player3 Cut", 5.0, 15, 100, function() 
	return globals.get_int(1970895+2325 + 1 + 1 + 1)
end, function(value)
	globals.set_int(1970895+2325 + 1 + 1 + 1, value)
H3C3 = p3

end)
 
CSYONCASINO:add_int_range("Casino Player4 Cut", 5.0, 15, 100, function() 
	return globals.get_int(1970895+2325+ 1 + 1 + 1 + 1)
end, function(value)
	globals.set_int(1970895+2325 + 1 + 1 + 1 + 1, value)
H3C4 = p4

end)

CSYONCASINO:add_int_range("Casino Lifes - Self", 1, 1, 999999999, function() return fmC:get_int(26133 + 1325 + 1) end, function(life) if fmC and fmC:is_active() then fmC:set_int(26133 + 1325 + 1,life) end end)

local STRKM52=52962;
CSYONCASINO:add_action("Casino Fingerprint", function()
	local heist_script = script("fm_mission_controller")
	if heist_script and heist_script:is_active() then
		if heist_script:get_int(STRKM52) == 3 or heist_script:get_int(STRKM52) == 4 then
			heist_script:set_int(STRKM52, 5)
		end
	end
end)

local STRKM51=54024;
CSYONCASINO:add_action("Hack Casino Keypads", function()
	local heist_script = script("fm_mission_controller")
	if heist_script and heist_script:is_active() then
		if heist_script:get_int(STRKM51) >= 3 or heist_script:get_int(STRKM51) < 100 then
			heist_script:set_int(STRKM51, 5)
		end
	end
end)

CSYONSAPARTMENT:add_action("Skip Current Apartment Heist Preps", function() stats.set_int(MPX() .. "HEIST_PLANNING_STAGE", -1) end) 

CSYONApartmentsCuts = CSYONSAPARTMENT:add_submenu("Apartmen Cuts Editor")


CSYONApartmentsCuts:add_int_range("Apt Player 1", 1.0, 15, 100, function() return globals.get_int(1940667) end, function(value) globals.set_int(1940667, value) end) 
CSYONApartmentsCuts:add_int_range("Apt Player 2", 1.0, 15, 100, function() return globals.get_int(1940668) end, function(value) globals.set_int(1940668, value) end) 
CSYONApartmentsCuts:add_int_range("Apt Player 3", 1.0, 15, 100, function() return globals.get_int(1940669) end, function(value) globals.set_int(1940669, value) end) 
CSYONApartmentsCuts:add_int_range("Apt Player 4", 1.0, 15, 100, function() return globals.get_int(1940670) end, function(value) globals.set_int(1940670, value) end) 


CSYONApartmentsCuts:add_action("All 200", function() for i = 1940667, 1940670 do globals.set_int(i, 200) end end)

CSYONApartmentsCuts:add_action("All 179", function() for i = 1940667, 1940670 do globals.set_int(i, 179) end end)
CSYONApartmentsCuts:add_action("All 150", function() for i = 1940667, 1940670 do globals.set_int(i, 150) end end)
CSYONApartmentsCuts:add_action("All 120", function() for i = 1940667, 1940670 do globals.set_int(i, 120) end end)
CSYONApartmentsCuts:add_action("All 100", function() for i = 1940667, 1940670 do globals.set_int(i, 100) end end)

CSYONApartmentsCuts:add_action("All 85", function() for i = 1940667, 1940670 do globals.set_int(i, 85) end end)
CSYONApartmentsCuts:add_action("All 75", function() for i = 1940667, 1940670 do globals.set_int(i, 75) end end)
CSYONApartmentsCuts:add_action("All 50", function() for i = 1940667, 1940670 do globals.set_int(i, 50) end end)
CSYONApartmentsCuts:add_action("All 25", function() for i = 1940667, 1940670 do globals.set_int(i, 25) end end)
CSYONApartmentsCuts:add_action("All 0", function() for i = 1940667, 1940670 do globals.set_int(i, 0) end end)


Csyonn2 = CSYONCarShopPrep:add_submenu("Skip Auto Shop Skip Preps Menu")
Csyonn2:add_array_item("Prep Skip", {"The Union Depository Contract", "The Superdollar Deal", "The Bank Contract", "The ECU Job", "The Prison Contract", "The Agency Deal", "The Lost Contract", "The Data Contract"}, function() return xox_18 end, function(value) if value == 1 then stats.set_int(MPX() .. "TUNER_GEN_BS", 12543) stats.set_int(MPX() .. "TUNER_CURRENT", 0) elseif value == 2 then stats.set_int(MPX() .. "TUNER_GEN_BS", 4351) stats.set_int(MPX() .. "TUNER_CURRENT", 1) elseif value == 3 then stats.set_int(MPX() .. "TUNER_GEN_BS", 12543) stats.set_int(MPX() .. "TUNER_CURRENT", 2) elseif value == 4 then stats.set_int(MPX() .. "TUNER_GEN_BS", 12543) stats.set_int(MPX() .. "TUNER_CURRENT", 3) elseif value == 5 then stats.set_int(MPX() .. "TUNER_GEN_BS", 12543) stats.set_int(MPX() .. "TUNER_CURRENT", 4) elseif value == 6 then stats.set_int(MPX() .. "TUNER_GEN_BS", 12543) stats.set_int(MPX() .. "TUNER_CURRENT", 5) elseif value == 7 then stats.set_int(MPX() .. "TUNER_GEN_BS", 12543) stats.set_int(MPX() .. "TUNER_CURRENT", 6) else stats.set_int(MPX() .. "TUNER_GEN_BS", 12543) stats.set_int(MPX() .. "TUNER_CURRENT", 7) end xox_18 = value end) 

Csyonn1 = CSYONCarShopPrep:add_submenu("Auto Shop Preps Cuts $ Menu")

Csyonn1:add_int_range("The Union Depository  Payout", 100000, 0, 900000, function()
	return globals.get_int(262145 + 31030 + 0 + 1)
end, function(value)
	globals.set_int(262145 + 31030 + 0 + 1, value)
end)
Csyonn1:add_int_range("The Superdollar Deal  Payout", 100000, 0, 900000, function()
	return globals.get_int(262145 + 31030 + 1 + 1)
end, function(value)
	globals.set_int(262145 + 31030 + 1 + 1, value)
end)
Csyonn1:add_int_range("The Bank Contract   Payout", 100000, 0, 900000, function()
	return globals.get_int(262145 + 31030 + 2 + 1)
end, function(value)
	globals.set_int(262145 + 31030 + 2 + 1, value)
end)
Csyonn1:add_int_range("The ECU Job   Payout", 100000, 0, 900000, function()
	return globals.get_int(262145 + 31030 + 3 + 1)
end, function(value)
	globals.set_int(262145 + 31030 + 3 + 1, value)
end)
Csyonn1:add_int_range("The Prison Contract   Payout", 100000, 0, 900000, function()
	return globals.get_int(262145 + 31030 + 4 + 1)
end, function(value)
	globals.set_int(262145 + 31030 + 4 + 1, value)
end)
Csyonn1:add_int_range("The Agency Deal Payout", 100000, 0, 900000, function()
	return globals.get_int(262145 + 31030 + 5 + 1)
end, function(value)
	globals.set_int(262145 + 31030 + 5 + 1, value)
end)
Csyonn1:add_int_range("The LOST Contract  Payout", 100000, 0, 900000, function()
	return globals.get_int(262145 + 31030 + 6 + 1)
end, function(value)
	globals.set_int(262145 + 31030 + 6 + 1, value)
end)
Csyonn1:add_int_range("The Data Contract Payout", 100000, 0, 900000, function()
	return globals.get_int(262145 + 31030 + 7 + 1)
end, function(value)
	globals.set_int(262145 + 31030 + 7 + 1, value)
end)


Csyonn1:add_action("__________________________________", function() end)
local function Text(text)
	Csyonn1:add_action(text, function() end)
end

Csyonn1:add_action("Get Money ( 1 Million - (( Heist Auto Shop )) ", function() end)
local function Text(text)
	Csyonn1:add_action(text, function() end)
end

Csyonn1:add_action(" Get  All 1 Min $ ", function() for i = 293174, 293182 do globals.set_int(i, 1000000) end globals.set_float(293171,0) end) 

function MPX()return stats.get_int("MPPLY_LAST_MP_CHAR") end


script_name = "fm_mission_controller_2020"
AutoShop_passed_trigger = 42280
AutoShop_heist_passed_value = 43655

 Csyonn3 = CSYONCarShopPrep:add_submenu("Instant Heist Passed")

Csyonn3:add_action("Instant Heist Passed", function()
    if(script(script_name):is_active()) then
        script(script_name):set_int(AutoShop_passed_trigger, 51338977)
        script(script_name):set_int(AutoShop_heist_passed_value, 101)
    end
end)

 Csyonn3:add_action("(Wait 5 secs to use after loading)", function() end)


Csyonn388 = CSYONCarShopPrep:add_submenu("Missions Tools")

local cooldownGlobalAddress = 262145 + 31126
local isRemoved = false
 
local function removeCooldown(state)
    if not localplayer then
        return
    end
    if state then
        globals.set_int(cooldownGlobalAddress, 0)
    else
        globals.set_int(cooldownGlobalAddress, 2880)
    end
end
 
Csyonn388:add_toggle("Remove AutoShop Cooldown", function()
        return isRemoved
    end,
    function()
        isRemoved = not isRemoved
        removeCooldown(isRemoved)
    end
)

Csyonn388:add_action("---------------Contracts Stats Editor-----------------", function() end) 
Csyonn388:add_int_range("Contracts Done", 1, 0, 9999, function()
 return stats.get_int(MPX().."TUNER_COUNT") end, function(v)
 stats.set_int(MPX().."TUNER_COUNT", v) end) 
Csyonn388:add_int_range("Contracts Earnings", 500000, 0, 1000000000, function()
 return stats.get_int(MPX().."TUNER_EARNINGS") end, function(v)
 stats.set_int(MPX().."TUNER_EARNINGS", v) end) 

Csyonn388:add_action("-----", function() end) 

 CSYONCONTRACTS:add_action("Set Up Dre Finale Mission", function()
	 PlayerIndex = globals.get_int(1574918)
	 if PlayerIndex == 0 then
		 stats.set_int("MP0_FIXER_STORY_BS", 4092)
		 stats.set_int("MP0_FIXER_STORY_STRAND", -1)
	 else
		 stats.set_int("MP1_FIXER_STORY_BS", 4092)
		 stats.set_int("MP1_FIXER_STORY_STRAND", -1)
	 end
 end)
 
 CSYONCONTRACTS:add_int_range("Payout", 100000, 0, 2500000, function()
	 return globals.get_int(262145 + 31735)
 end, function(value)
	 globals.set_int(262145 + 31735, value)
 end)
 
 local function teleport_myself(x,y,z)
	 localplayer:set_position((vector3(x, y, z)))
 end
  
 CSYONCONTRACTS:add_action("-------------- Teleport Dre --------------", function() end)
 CSYONCONTRACTS:add_action("Dre 1", function()
	 teleport_myself(507.766602, -605.932678, 23.451139)
 end)
  
 CSYONCONTRACTS:add_action("Dre 2", function()
	 teleport_myself(-927.370483, -2923.859131, 12.644426)
 end)
  
 CSYONCONTRACTS:add_action("Dre 3", function()
	 teleport_myself(-933.519897, -3010.231201, 18.540413)
 end)
 
 CSYONCONTRACTS:add_action("Dre 4", function()
	 teleport_myself(-3036.250488, 111.499924, 10.599296)
 end)

CSYONCONTRACTS:add_action("-------No. of security contracts done---------", function() end) 
CSYONCONTRACTS:add_int_range("Asset Protection", 1, 0, 500, function()
 return stats.get_int(MPX().."FIXER_SC_ASSETS_PROTECTED") end, function(v)
 stats.set_int(MPX().."FIXER_SC_ASSETS_PROTECTED", v) end) 
CSYONCONTRACTS:add_int_range("Gang Termination", 1, 0, 500, function()
 return stats.get_int(MPX().."FIXER_SC_GANG_TERMINATED") end, function(v)
 stats.set_int(MPX().."FIXER_SC_GANG_TERMINATED", v) end) 
CSYONCONTRACTS:add_int_range("Liquidize Assets", 1, 0, 500, function()
 return stats.get_int(MPX().."FIXER_SC_EQ_DESTROYED") end, function(v)
 stats.set_int(MPX().."FIXER_SC_EQ_DESTROYED", v) end) 
CSYONCONTRACTS:add_int_range("Recover Valuables", 1, 0, 500, function()
 return stats.get_int(MPX().."FIXER_SC_VAL_RECOVERED") end, function(v)
 stats.set_int(MPX().."FIXER_SC_VAL_RECOVERED", v) end) 
CSYONCONTRACTS:add_int_range("Rescue Operation", 1, 0, 500, function()
 return stats.get_int(MPX().."FIXER_SC_VIP_RESCUED") end, function(v)
 stats.set_int(MPX().."FIXER_SC_VIP_RESCUED", v) end) 
CSYONCONTRACTS:add_int_range("Vehicle Recovery", 1, 0, 500, function()
 return stats.get_int(MPX().."FIXER_SC_VEH_RECOVERED") end, function(v)
 stats.set_int(MPX().."FIXER_SC_VEH_RECOVERED", v) end) 
CSYONCONTRACTS:add_int_range("Contract Earnings", 250000, 0, 20000000, function()
 return stats.get_int(MPX().."FIXER_EARNINGS") end, function(v)
 stats.set_int(MPX().."FIXER_EARNINGS", v) end)
CSYONCONTRACTS:add_action("------------Payphone Hits Stats-------------", function() end) 
CSYONCONTRACTS:add_int_range("Payphone hits Completed", 1, 0, 999, function()
 return stats.get_int(MPX().."FIXERTELEPHONEHITSCOMPL") end, function(v)
 stats.set_int(MPX().."FIXERTELEPHONEHITSCOMPL", v) end)