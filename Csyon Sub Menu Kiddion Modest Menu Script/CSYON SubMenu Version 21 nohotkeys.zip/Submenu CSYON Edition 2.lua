--░█████╗░░██████╗██╗░░░██╗░█████╗░███╗░░██╗
--██╔══██╗██╔════╝╚██╗░██╔╝██╔══██╗████╗░██║
--██║░░╚═╝╚█████╗░░╚████╔╝░██║░░██║██╔██╗██║
--██║░░██╗░╚═══██╗░░╚██╔╝░░██║░░██║██║╚████║
--╚█████╔╝██████╔╝░░░██║░░░╚█████╔╝██║░╚███║
--░╚════╝░╚═════╝░░░░╚═╝░░░░╚════╝░╚═╝░░╚══╝
function CheckOnlineVersion()
	major, minor, build, patch = menu.get_game_version()
	if build ~= 3095 then
		main = menu.add_submenu("⚠The game current version is: "..major.."."..minor.."."..build.."."..patch)
		main:add_submenu("Game updated!!!")
		main:add_submenu("The sctipt is outdated!!!")
	end
end
CheckOnlineVersion()
require_game_build(3095) -- GTA Online version 1.68

local function Texterrrsa(text)
	mainMenu3:add_action(text,  function() end)
end

local function Text(text)
	Online:add_action(text,  function() end)
end

local function Text(text)
	menu.add_action(text,  function() end)
end

-- Required Script Handles
boolCeoBanager = false
funcCeoBanger = false
local scrWarehouse = script("am_mp_warehouse")
local scrSellContraband = script("gb_contraband_sell")
local scrSecuroServ = script("appsecuroserv")
local scrBuyContraband = script("gb_contraband_buy")

-- get the right variable prefix
if stats.get_int("MPPLY_LAST_MP_CHAR") == 0 then
  MPX = "MP0_"
else
  MPX = "MP1_"
end

local function funcCeoBanger(isRunning)

  while isRunning == true do
    local numLifetimeSales = stats.get_int(MPX .. "LIFETIME_SELL_COMPLETE")
    if scrWarehouse:is_active() then
          globals.set_int(278108 + 15991, 6000000)
          globals.set_int(277873 + 15756, 0)
          globals.set_int(277874 + 15757, 0)
        end
          globals.set_int(4537356,  0)
          globals.set_int(4537357,  0)
          globals.set_int(4537358,  0)


        if scrSecuroServ:is_active() then
          scrSecuroServ:set_int(739, 1)
          sleep(1)
          scrSecuroServ:set_int(740, 1)
          sleep(1)
          scrSecuroServ:set_int(558, 3012)
        end


-----------------------------------------------------------------------------------------------------------------

        if scrSellContraband:is_active() then
          scrSellContraband:set_int(1136, 1)
          scrSellContraband:set_int(596, 0)
          scrSellContraband:set_int(1125, 0)
          scrSellContraband:set_int(543 + 7, 7)
          sleep(1)
          scrSellContraband:set_int(543 + 1,  99999)
        end
      end
    end

-----------------------------------------------------------------------------------------------------------------

    if scrBuyContraband:is_active() then
        sleep(1)
        scrBuyContraband:set_int(601 + 5, 1)
        scrBuyContraband:set_int(601 + 1, CV)  
        scrBuyContraband:set_int(601 + 191, 6)
        scrBuyContraband:set_int(601 + 192, 4)
		GCv2 = CV
      end
-------
--local function Text(text)
--	csyons:add_action(text, function() end)
--end
-------
local autorepairvehicle = false
local function repaircar()
    if autorepairvehicle then
		current_vehicle = localplayer:get_current_vehicle()
		 current_vehicle:set_health(current_vehicle:get_max_health())
		 menu.repair_online_vehicle()
		current_vehicle:set_dirt_level(0.0)
    end 
end
---
----------
local boolall = false 
local blockSocialClubSpamState = false

local function Activity(bool)
	globals.set_bool(1669794, bool) 
end
 
local function Bounty(bool)
	globals.set_bool(1669276, bool) 
end
 
local function CeoKick(bool)
	globals.set_bool(1669766, bool) 
end
 
local function KickCrashes(bool)
	globals.set_bool(1669936, bool)
	globals.set_bool(1669663, bool)
	globals.set_bool(1669818, bool)
	globals.set_bool(1669833, bool)
	globals.set_bool(1669733, bool)
	globals.set_bool(1669810, bool)
	globals.set_bool(1670028, bool)
end
 
local function getKickCrashesState()
	return ( globals.get_bool(1669936) and
	globals.get_bool(1669663) and 
	globals.get_bool(1669818) and
	globals.get_bool(1669833) and
	globals.get_bool(1669733) and
	globals.get_bool(1669810) and
	globals.get_bool(1670028))
end
 
local function CeoBan(bool)
	globals.set_bool(1669788, bool) 
end
 
local function SoundSpam(bool)
	globals.set_bool(1669661, bool)
	globals.set_bool(1670033, bool)
	globals.set_bool(1669211, bool)
	globals.set_bool(1670529, bool)
	globals.set_bool(1669840, bool)
	globals.set_bool(1669228, bool)
end
 
local function getSoundSpamState()
	return (globals.get_bool(1669661) and
	globals.get_bool(1670033) and
	globals.get_bool(1669211) and
	globals.get_bool(1670529) and
	globals.get_bool(1669840) and
	globals.get_bool(1669228))
end
 
local function InfiniteLoad(bool)	
	globals.set_bool(1669729, bool) 
	globals.set_bool(1669858, bool)
end
 
local function getInfiniteLoadState()
	return (globals.get_bool(1669729) and
	globals.get_bool(1669858))
end
 
local function Collectibles(bool)
	globals.set_bool(1669998, bool) 
end
 
local function PassiveMode(bool)
	globals.set_bool(1669778, bool) 
end
 
local function TransactionError(bool) 
	globals.set_bool(4537356 + 4537358, bool) 
end
 
local function RemoveMoneyMessage(bool) 
	globals.set_bool(1669662, bool)
	globals.set_bool(1669233, bool)
	globals.set_bool(1669839, bool)
end
 
local function getRemoveMoneyMessageState()
	return (globals.get_bool(1669662) and
	globals.get_bool(1669233) and
	globals.get_bool(1669839))
end
 
local function ExtraTeleport(bool) 
	globals.set_bool(1669534, bool) 
	globals.set_bool(1669928, bool) 
    globals.set_bool(1670027, bool)
    globals.set_bool(1670028, bool)
    globals.set_bool(1670023, bool) 
end
 
local function getExtraTeleportState()
	return (globals.get_bool(1669534) and
	globals.get_bool(1669928) and globals.get_bool(1670027) and globals.get_bool(1670028) and globals.get_bool(1670023))
end
 
local function ClearWanted(bool) 
	globals.set_bool(1669720, bool)
end
 
local function OffTheRadar(bool) 
	globals.set_bool(1669722, bool) 
end
 
local function SendCutscene(bool) 
	globals.set_bool(1669988, bool)
end
 
local function Godmode(bool) 
	globals.set_bool(1669213, bool)
end
 
local function PersonalVehicleDestroy(bool) 
	globals.set_bool(1669284, bool)
	globals.set_bool(1669845, bool) 
end
 
local function getPersonalVehicleDestroyState()
	return (globals.get_bool(1669284) and
	globals.get_bool(1669845))
end
 
local function RemoteGlobalModification(bool)
	local setting = 0
	if bool then
		setting = 1
	end
	globals.set_int(1669976, setting)
	globals.set_int(1669680, setting)
end
 
local function getRemoteGlobalModificationState()
	return ((globals.get_int(1669976) == 1) and
	(globals.get_int(1669680) == 1))
end
 
local function BlockSocialclubSpam(bool)
	blockSocialClubSpamState = bool
end
 
local function getBlockSocialClubSpamState()
	return blockSocialClubSpamState
end

local function teleport_myself(x, y, z)
	localplayer:set_position((vector3(x, y, z)))
end
 
local function All(bool) 
	Activity(bool)
	Bounty(bool)
	CeoKick(bool)
	CeoBan(bool)
	SoundSpam(bool)
	InfiniteLoad(bool)
	PassiveMode(bool)
	TransactionError(bool)
	RemoveMoneyMessage(bool)
	ClearWanted(bool)
	OffTheRadar(bool)
	PersonalVehicleDestroy(bool)
	SendCutscene(bool)
	Godmode(bool)
	Collectibles(bool)
	ExtraTeleport(bool)
	KickCrashes(bool)
	RemoteGlobalModification(bool)
	BlockSocialclubSpam(bool)
end
----------
function force_gun()
	local gun = localplayer:get_current_weapon()
	gun:set_heli_force(99900000.00)
    gun:set_ped_force(99900000.00)
    gun:set_vehicle_force(99900000.00)
end
----------
function boom_gun()
	local gun = localplayer:get_current_weapon()
	gun:set_explosion_type(1)
	gun:set_damage_type(5)
end
----------
function nuke_gun()
	local gun = localplayer:get_current_weapon()
	gun:set_explosion_type(82)
	gun:set_damage_type(5)
end
----------
function CarDrop()
	local position = localplayer:get_position()
	position.z = position.z + 5
	for c in replayinterface.get_vehicles() do
		print(c)
		print(replayinterface.get_vehicles())
		print(replayinterface)
		c:set_position(position)
		return
	end
end
----------
--function MPX()return stats.get_int("MPPLY_LAST_MP_CHAR")end

local function MPX()
	return "MP" .. stats.get_int("MPPLY_LAST_MP_CHAR") .. "_"
end

--function MPX()
--	return "MP"..stats.get_int("MPPLY_LAST_MP_CHAR").."_"
--end

--local MPX() = function()
--	return "MP"..stats.get_int("MPPLY_LAST_MP_CHAR").."_"
--end
----------
fmC2020 = script("fm_mission_controller_2020") fmC = script("fm_mission_controller") PlayerIndex = stats.get_int("MPPLY_LAST_MP_CHAR") mpx = PlayerIndex if PlayerIndex == 0 then mpx = "MP0_" else mpx = "MP1_" end xox_00 = 1 xox_01 = 1 xox_0 = 1 xox_1 = 1 xox_2 = 1 xox_3 = 1 xox_4 = 1 xox_5 = 1 xox_6 = 1 xox_7 = 1 xox_8 = 1 xox_9 = 1 xox_10 = 1 xox_11 = 1 xox_12 = 1 xox_13 = 1 xox_14 = 1 xox_15 = 1 xox_16 = 1 xox_17 = 1 xox_18 = 1 xox_19 = 1 xox_20 = 1 xox_21 = 1 xox_22 = 1 xox_23 = 1 xox_24 = 1 xox_25 = 1 xox_26 = 1 xox_27 = 1 xox_28 = 1 xox_29 = 1 xox_30 = 1 xox_31 = 1 xox_32 = 1 xox_33 = 1 xox_34 = 1 xox_35 = 1 xox_36 = 1 xox_37 = 1 e0 = false e1 = false e2 = false e3 = false e4 = false e5 = false e6 = false e7 = false e8 = false e9 = false e10 = false e11 = false e12 = false e13 = false e14 = false e15 = false e16 = false e17 = false e18 = false e19 = false e20 = false e21 = false e22 = false e23 = false e24 = false e25 = false e26 = false e27 = false e28 = false e29 = false e30 = false e31 = false e32 = false e33 = false e34 = false e35 = false e36 = false e37 = false e38 = false e39 = false e40 = false e41 = false e42 = false e43 = false e44 = false e45 = false e46 = false e47 = false e48 = false e49 = false e50 = false e51 = false e52 = false e53 = false
function TP(x, y, z, yaw, roll, pitch) if localplayer:is_in_vehicle() then localplayer:get_current_vehicle():set_position(x, y, z) localplayer:get_current_vehicle():set_rotation(yaw, roll, pitch) else localplayer:set_position(x, y, z) localplayer:set_rotation(yaw, roll, pitch) end end 
--Globals ---
CsyonsACL1=262145+17425
CsyonsACL2=262145+17396
CsyonsACL3=262145+18949
CsyonsACL4=262145+21869
CsyonsACL5=262145+21870
CsyonsACL6=262145+21866
----------
local fmC2020 = script("fm_csyon_script_2023") local fmC = script("fm_csyon_script") local PlayerIndex = stats.get_int("MPPLY_LAST_MP_CHAR") local mpx = PlayerIndex if PlayerIndex == 0 then mpx = "MP0_" else mpx = "MP1_" end local xox_00 = 1 local xox_01 = 1 local xox_0 = 1 local xox_1 = 1 local xox_2 = 1 local xox_3 = 1 local xox_4 = 1 local xox_5 = 1 local xox_6 = 1 local xox_7 = 1 local xox_8 = 1 local xox_9 = 1 local xox_10 = 1 local xox_11 = 1 local xox_12 = 1 local xox_13 = 1 local xox_14 = 1 local xox_15 = 1 local xox_16 = 1 local xox_17 = 1 local xox_18 = 1 local xox_19 = 1 local xox_20 = 1 local xox_21 = 1 local xox_22 = 1 local xox_23 = 1 local xox_24 = 1 local xox_25 = 1 local xox_26 = 1 local xox_27 = 1 local xox_28 = 1 local xox_29 = 1 local xox_30 = 1 local xox_31 = 1 local xox_32 = 1 local xox_33 = 1 local xox_34 = 1 local xox_35 = 1 local e0 = false local e1 = false local e2 = false local e3 = false local e4 = false local e5 = false local e6 = false local e7 = false local e8 = false local e9 = false local e10 = false local e11 = false local e12 = false local e13 = false local e14 = false local e15 = false local e16 = false local e17 = false local e18 = false local e19 = false local e20 = false local e21 = false local e22 = false local e23 = false local e24 = false local e25 = false local e26 = false local e27 = false local e28 = false local e29 = false local e30 = false local e31 = false local e32 = false local e33 = false local e34 = false local e35 = false local e36 = false local e37 = false local e38 = false local e39 = false local e40 = false local function TP(x, y, z, yaw, roll, pitch) if localplayer:is_in_vehicle() then localplayer:get_current_vehicle():set_position(x, y, z) localplayer:get_current_vehicle():set_rotation(yaw, roll, pitch) else localplayer:set_position(x, y, z) localplayer:set_rotation(yaw, roll, pitch) end end
----------
local VehicleSpawnGlobal2 = 2694613
local VehicleSpawnGlobal = 2639889
 
local function createVehicle(modelHash, pos)
	if not localplayer:is_in_vehicle() then
		globals.set_int(VehicleSpawnGlobal + 46, modelHash)
		globals.set_float(VehicleSpawnGlobal + 42, pos.x)
		globals.set_float(VehicleSpawnGlobal + 43, pos.y)
		globals.set_float(VehicleSpawnGlobal + 44, pos.z)
		local vector = localplayer:get_heading()
		local angle = math.deg(math.atan(vector.y, vector.x))
		if angle < 0 then angle = angle + 360 end
		globals.set_float(VehicleSpawnGlobal + 45, angle)
		globals.set_boolean(VehicleSpawnGlobal + 41, true)
	else
		globals.set_boolean(VehicleSpawnGlobal2 + 5, false) -- SpawnVehicles
		globals.set_boolean(VehicleSpawnGlobal2 + 2, false) -- SpawnVehicles
		globals.set_float(VehicleSpawnGlobal2 + 7 + 0, pos.x) -- pos.x
		globals.set_float(VehicleSpawnGlobal2 + 7 + 1, pos.y) -- pos.y
		globals.set_float(VehicleSpawnGlobal2 + 7 + 2, pos.z) -- pos.z
		globals.set_int(VehicleSpawnGlobal2 + 27 + 66, modelHash) -- modelHash
		globals.set_boolean(VehicleSpawnGlobal2 + 5, true) -- SpawnVehicles
		globals.set_boolean(VehicleSpawnGlobal2 + 2, true) -- SpawnVehicles
	end
end
 
local weapon_data = {}
local enabled = false
local isActive = false
local function spawnCarWhereAiming()
	if not enabled then return end
	isActive = true
	local weapon = localplayer:get_current_weapon()
	local pos
	if weapon ~= nil then 
		local force = weapon:get_vehicle_force()
		if force ~= nil and force < 100000 then
			weapon_data[weapon:get_name_hash()] = force
			weapon:set_vehicle_force(99900000)
		end
	end
	local pos = (localplayer:get_position() + localplayer:get_heading()*2.2)
	if localplayer:is_in_vehicle() then
		pos = (localplayer:get_position() + localplayer:get_heading()*11)
	end
	createVehicle(joaat("Youga4"), pos + vector3(0,0,1))
	sleep(0.2)
	isActive = false
end
 
local weapon_data = {}
local enabled = false
local isActive = false
local function spawnCarWhereAiming()
	if not enabled then return end
	isActive = true
	--check weapon hit force and put in table
	local weapon = localplayer:get_current_weapon()
	if weapon ~= nil then
		local force = weapon:get_vehicle_force()
		if force ~= nil and force < 100000 then
			weapon_data[weapon:get_name_hash()] = force
			weapon:set_vehicle_force(99900000)
		end
	end
	local pos = (localplayer:get_position() + localplayer:get_heading()*2.2)
	if localplayer:is_in_vehicle() then
		pos = (localplayer:get_position() + localplayer:get_heading()*11)
	end
	createVehicle(joaat("Youga4"), pos + vector3(0,0,1))
	sleep(0.2)
	isActive = false
end
 
local hotkey
local function carAPult()
	if not localplayer or localplayer == nil then return end
	
	enabled = not enabled
	if enabled then
		--register hotkey to left click for continually spawning cars
		hotkey = menu.register_hotkey(1, function() if not isActive then spawnCarWhereAiming() end end)
	else
		--reset weapon hit force from table
		local weapon = localplayer:get_current_weapon()
		if weapon ~= nil and weapon:get_vehicle_force() == 99900000 then
			local force = weapon_data[weapon:get_name_hash()]
			if force ~= nil then
				weapon:set_vehicle_force(force)
			end
		end
		
		--unregister hotkey
		menu.remove_hotkey(hotkey)
	end
end
----------
local enable_SG = false
local enable_on_select = true
local exclude_map = {
	[joaat("WEAPON_RAILGUN")] = 1,
}
local SG_map = {}
-- SG_map[3] = "Molotov"
SG_map[12] = "Flame"
SG_map[20] = "Teargas"
SG_map[22] = "Flare"
-- SG_map[36] = "Railgun"
-- SG_map[64] = "Kinetic"
SG_map[65] = "EMP"

-- Trollings
-- SG_map[11] = "Steam"
-- SG_map[13] = "Water"
-- SG_map[38] = "Firework"
SG_map[45] = "ExpAmmo" -- weaker than railgun
-- SG_map[67] = "Slick"
-- SG_map[68] = "Tar"
SG_map[70] = "Atmzr" -- dmg: kine>atmzr for veh, vice versa for ped
-- More at https://altv.stuyk.com/docs/articles/tables/explosions.html

local active_type = 45
local gun_map = {}

function ResetWeaponStats(oldWeapon, og_exp, og_dmg_t, og_dmg_v)	
	oldWeapon:set_explosion_type(og_exp)
	oldWeapon:set_damage_type(og_dmg_t)
	oldWeapon:set_bullet_damage(og_dmg_v)
end

function ResetAllWeaponStats()
	sleep(0.2)
	for w, p in pairs(gun_map) do
		ResetWeaponStats(w, p[1], p[2], p[3])	
	end
end

local function OnWeaponChanged(oldWeapon, newWeapon)
	if oldWeapon ~= nil and gun_map[oldWeapon] ~= nil then
		p = gun_map[oldWeapon]
		ResetWeaponStats(oldWeapon, p[1], p[2])
	end
	if newWeapon ~= nil and exclude_map[newWeapon:get_name_hash()] == nil  then
		local original_explosion_type = newWeapon:get_explosion_type()
		local original_damage_type = newWeapon:get_damage_type()
		local original_damage_val = newWeapon:get_bullet_damage()
		if original_damage_type == 3 then
			newWeapon:set_explosion_type(active_type)
			newWeapon:set_damage_type(5)
			if active_type == 22 then
				newWeapon:set_bullet_damage(0)
			end
			gun_map[newWeapon] = {original_explosion_type, original_damage_type, original_damage_val}
		end
	end
end

------
if SGcallback then menu.remove_callback(SGcallback) end
local SGcallback=nil
if enable_SG then
	local SGcallback = menu.register_callback('OnWeaponChanged', OnWeaponChanged)
end
local function Handle_SG(e)
	if e then
		SGcallback = menu.register_callback('OnWeaponChanged', OnWeaponChanged)
		OnWeaponChanged(nil, localplayer:get_current_weapon())
	else
		menu.remove_callback(SGcallback)		
		ResetAllWeaponStats()
	end
end
----------

----------

----------

----------

----------

----------

----------

----------

mainMenu3 = menu.add_submenu("【 CSYON 】 SubMenu E2")

Texterrrsa("**************************************************************************")
Texterrrsa("            ** CSYON SubMenu 1.68 **                  ")
Texterrrsa("                               **✅ V21 **                   ")
Texterrrsa("            ** ⚠️Game Build Version 3095⚠️ **                  ")
Texterrrsa("**************************************************************************")
	
Online= mainMenu3:add_submenu("🚨 Csyon Submenu")

CSYON29 = Online:add_submenu("🙎‍Player Features")

CSYON22 = Online:add_submenu("💵 Money Options")

CSYON55 = Online:add_submenu("💵 Deposit Money 🏧")

CSYON35 = Online:add_submenu("🎴Events")

CSYON475 = Online:add_submenu("🎅Xmas Unlocks🧑‍🎄")

CSYON85 = Online:add_submenu("🎃HALLOWEEN🎃")

CSYON24 = Online:add_submenu("✨ Misc things activater")

CSYON27 = Online:add_submenu("🚩flags options")

CSYON9740 = Online:add_submenu("📑Achievements Unlocker📑")

CSYON28 = Online:add_submenu("🔫Weapons Options")

CSYON26 = Online:add_submenu("🛡️ Protections")

CSYON25 = Online:add_submenu("🎮Unlock Alls")

CSYON21 = Online:add_submenu("⚠info for help")

--------------------------------------------------------------------------------------------------------

CSYONS22 = CSYON22:add_submenu("---> Press here the Pay Respect")

CSYONS55 = CSYON55:add_submenu("💵are you sure to Deposit Cash?🏧")

CSYONS475 = CSYON475:add_submenu("🎄Christmas Unlocker🎄")

CSYONS9740 = CSYON9740:add_submenu("📑Achievements Unlocker?📑")

CSYONS85 = CSYON85:add_submenu("🎃Halloween Features🎃")

CSYONS24 = CSYON24:add_submenu("✨ Misc things activater? ")

CSYONS26 = CSYON26:add_submenu("🛡️ Give your self Protection? ")

CSYONS25 = CSYON25:add_submenu("🎮Unlock All? ")

CSYONS35 = CSYON35:add_submenu("🎴do you wanna Play a Event?")

CSYONS27 = CSYON27:add_submenu("🚩flags? ")

CSYONS29 = CSYON29:add_submenu("🙎‍Player Options? ")

CSYONS28 = CSYON28:add_submenu("🔫Weapon Features ")

CSYONS21 = CSYON21:add_submenu("⚠Settings")

--------------------------------------------------------------------------------------------------------

CSYONS21:add_action("***********************************************************", function() end)
CSYONS21:add_action("for Help join my Discord Server", function() end)
CSYONS21:add_action("https://discord.gg/JaCvtj6yQK", function() end)
CSYONS21:add_action("***********************************************************", function() end)

--------------------------------------------------------------------------------------------------------

CSYON22:add_action("Biker Clubhouse Bar Earnings ($100,000 every 48 minutes)", function()
	stats.set_int("MP"..stats.get_int("MPPLY_LAST_MP_CHAR").."_BIKER_BAR_RESUPPLY_CASH", 100000)
end)

CSYONS9740:add_action("Unlock Good Samaritan Award", function()
    stats.set_int(MPX().."AWD_GOODSAMARITAN", 5)
end)

CSYONS24:add_action("Complete Objectives", function()
	stats.set_int(MPX().."COMPLETEDAILYOBJ", 100)
	stats.set_int(MPX().."COMPLETEDAILYOBJTOTAL", 100)
	stats.set_int(MPX().."TOTALDAYCOMPLETED", 100)
	stats.set_int(MPX().."TOTALWEEKCOMPLETED", 400)
	stats.set_int(MPX().."TOTALMONTHCOMPLETED", 1800)
	stats.set_int(MPX().."CONSECUTIVEDAYCOMPLETED", 30)
	stats.set_int(MPX().."CONSECUTIVEWEEKCOMPLETED", 4)
	stats.set_int(MPX().."CONSECUTIVEMONTHCOMPLETE", 1)
	stats.set_int(MPX().."COMPLETEDAILYOBJSA", 100)
	stats.set_int(MPX().."COMPLETEDAILYOBJTOTALSA", 100)
	stats.set_int(MPX().."TOTALDAYCOMPLETEDSA", 100)
	stats.set_int(MPX().."TOTALWEEKCOMPLETEDSA", 400)
	stats.set_int(MPX().."TOTALMONTHCOMPLETEDSA", 1800)
	stats.set_int(MPX().."CONSECUTIVEDAYCOMPLETEDSA", 30)
	stats.set_int(MPX().."CONSECUTIVEWEEKCOMPLETEDSA", 4)
	stats.set_int(MPX().."CONSECUTIVEMONTHCOMPLETESA", 1)
	stats.set_int(MPX().."AWD_DAILYOBJCOMPLETEDSA", 100)
	stats.set_int(MPX().."AWD_DAILYOBJCOMPLETED", 100)
	stats.set_bool(MPX().."AWD_DAILYOBJMONTHBONUS", true)
	stats.set_bool(MPX().."AWD_DAILYOBJWEEKBONUS", true)
	stats.set_bool(MPx().."AWD_DAILYOBJWEEKBONUSSA", true)
	stats.set_bool(MPX().."AWD_DAILYOBJMONTHBONUSSA", true)
end)

CSYONS24:add_action("Unlock Police Vehicles Price Trade", function()
	stats.set_int(MPX() .. "MOST_TIME_ON_3_PLUS_STARS", 300000)
	stats.set_int(MPX() .. "SALV23_SCOPE_BS", -1)
	stats.set_int(MPX() .. "SALV23_INST_PROG", -1)
	stats.set_int(MPX() .. "SALV23_GEN_BS", -1)
end)

CSYONS25:add_action("Temporarily Unlocking the Police Cars", function()
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL1", true, 62)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL1", true, 63)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL2", true, 4)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL2", true, 5)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL2", true, 6)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL2", true, 7)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL2", true, 9)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL2", true, 10)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL2", true, 11)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL2", true, 12)
    stats.set_int(MPX() .. "SALV23_GEN_BS", -1)
    stats.set_int(MPX() .. "SALV23_INST_PROG", -1)
    stats.set_int(MPX() .. "SALV23_SCOPE_BS", -1)
    stats.set_int(MPX() .. "MOST_TIME_ON_3_PLUS_STARS", 300000)
end)

CSYONS25:add_action("Unlock Race n' Chase arcade cabinets", function()
		globals.set_int(262145 + 31401, 1)
end)

CSYONS475:add_action("Gun Liveries", function()
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL0", true, 13)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL0", true, 14)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL0", true, 15)
end)

CSYONS475:add_action("Christmas and New Year Gifts 2023", function()
		globals.set_int(262145, 36250)
		globals.set_int(262145, 36251)
end)

packed_bool = false
CSYONS475:add_toggle("Unlock snowman etc.", function()
	return packed_bool
end, function(status)
	packed_bool = status
	stats.set_bool_masked(MPX() .. "DLC22022PSTAT_BOOL2", status, 20)
	stats.set_bool_masked(MPX() .. "DLC22022PSTAT_BOOL2", status, 21)
    stats.set_bool_masked(MPX() .. "DLC22022PSTAT_BOOL1", status, 28)
end)

CSYONS475:add_action("Weazel Plaza / WM 29 Pistol Event", function() -- Made by ShinyWasabi
	globals.set_int(1575032, 11) -- joining to invite only to reset the timer
	globals.set_int(1574589, 1)
	sleep(2)
	globals.set_int(1574589, 0)
	sleep(1)
	globals.set_int(262145 + 34547, 1) -- Tunable: ENABLE_MAZEBANKSHOOTOUT_DLC22022
	globals.set_int(262145 + 34270, 1000) -- This is the cooldown (default 1200000ms) - Tunable: 1839585304
end)
CSYONS475:add_action("Teleport to Weazel", function()
	localplayer:set_position(vector3(-902.81, -511.51, 35.71))
end)
 
CSYONS475:add_action("Christmas Truck Event", function()
	globals.set_int(1575032, 1)
	globals.set_int(1574589, 1)
	sleep(2)
	globals.set_int(1574589, 0)
	sleep(1)
    globals.set_int(262145 + 36055, 1) -- Enable Christmas Truck Event - Tunable: 2093114948
    globals.set_int(262145 + 36157, 1000) -- Cooldown - Tunable: -1136431517
    globals.set_int(262145 + 36158, 1000) -- Availability - Tunable: 890076076
end)
CSYONS475:add_action("Teleport to Truck", function()
    localplayer:set_position(vector3(235, -957, 29))
end)
 
CSYONS475:add_action("Gooch Event", function()
    globals.set_int(2698947 + 3 + 1, 171)
    globals.set_int(2698947 + 2, 6)
end)
 
CSYONS475:add_action("Yeti Event", function() -- Thanks to ShinyWasabi for the positions
    globals.set_int(262145 + 36054, 1)
end)
CSYONS475:add_action("Position 1", function()
    localplayer:set_position(vector3(-1562.69, 4699.04, 50.426))
end)
CSYONS475:add_action("Position 2", function()
    localplayer:set_position(vector3(-1359.869, 4733.429, 46.919))
end)
CSYONS475:add_action("Position 3", function()
    localplayer:set_position(vector3(-1715.398, 4501.203, 0.096))
end)
CSYONS475:add_action("Position 4", function()
    localplayer:set_position(vector3(-1282.18, 4487.826, 12.643))
end)
CSYONS475:add_action("Position 5", function()
    localplayer:set_position(vector3(-1569.665, 4478.485, 20.215))
end)
 
CSYONS475:add_action("Gun Liveries", function()
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL0", true, 13)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL0", true, 14)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL0", true, 15)
end)


CSYONS25:add_action("Unlock GTA 5 Birthday Gifts", function()
	for i = 23, 39 do
		stats.set_bool_masked(MPX().."DLC22023PSTAT_BOOL0", true, i)
	end
end)


CSYONS25:add_action("Unlock Christmas Liveries and Blue Goach Outfit", function()
	stats.set_bool_masked(MPX().."DLC12023PSTAT_BOOL11", true, 49) --Snowman Finish for Combat Pistol
	stats.set_bool_masked(MPX().."DLC12023PSTAT_BOOL11", true, 50) --Santa's Helper Finish for Heavy Sniper
	stats.set_bool_masked(MPX().."DLC22023PSTAT_BOOL0", true, 15)  --Skull Santa Finish for Special Carbine
	stats.set_bool_masked(MPX().."DLC_MP_X23_M_OUTFIT_7", true, 1575697431)  --Gooch Outfit
	stats.set_bool_masked(MPX().."DLC_MP_X23_F_OUTFIT_7", true, -1263177681)
	globals.set_int(34761, -1)
end)

CSYONS25:add_action("Unlocks liveries for Sultan RS Classic", function()
		stats.set_int("MPPLY_XMASLIVERIES", 11)
		stats.set_int("MPPLY_XMASLIVERIES", 12)
		stats.set_int("MPPLY_XMASLIVERIES", 13)
		stats.set_int("MPPLY_XMASLIVERIES", 14)
		stats.set_int("MPPLY_XMASLIVERIES", 15)
end)

--CSYONS24:add_float_range("⚠ Salvage Value Multiplier ⚠", 0.2, 0, 999,
CSYONS24:add_float_range("⚠ Salvage Value Multiplier ⚠", 0.2, 0, 999,
	function()
		return globals.get_float(262145 + 34100)
	end,
	function(value)
		globals.set_float(262145 + 34100, value)
	end)

CSYONS25:add_action("Unlock E-Cola and Sprunk License Plate", function()
		stats.set_int("MPPLY_XMAS23_PLATES0", -1)
end)

CSYONS25:add_action("Unlock Oppressor MKII Trade Price", function()
		stats.set_masked_int(MPX().. "BUSINESSBATPSTAT_INT379", 5, 5, 5) --Pegassi Oppressor Mk II (Trade Price)		
end)

CSYONS25:add_action("Unlock all Parachutes", function()
	stats.set_bool_masked(MPX() .. "TUNERPSTAT_BOOL1", true, 20)  --  Unlock for Sprunk Chute Bag
	stats.set_bool_masked(MPX() .. "TUNERPSTAT_BOOL1", true, 21)  --  Unlock for eCola Chute Bag
	stats.set_bool_masked(MPX() .. "TUNERPSTAT_BOOL1", true, 22)  --  Unlock for Halloween Chute Bag
	stats.set_bool_masked(MPX() .. "TUNERPSTAT_BOOL1", true, 23)  --  Unlock for Sprunk Chute
	stats.set_bool_masked(MPX() .. "TUNERPSTAT_BOOL1", true, 24)  --  Unlock for eCola Chute
	stats.set_bool_masked(MPX() .. "TUNERPSTAT_BOOL1", true, 25)  --  Unlock for Halloween Chute
	stats.set_bool_masked(MPX() .. "DLC12022PSTAT_BOOL1", true, 63)  --  Unlock Junk Energy Drink Chute Bag
	stats.set_bool_masked(MPX() .. "DLC12022PSTAT_BOOL2", true, 0)  --  Unlock Junk Energy Drink Chute
	stats.set_bool_masked(MPX() .. "TUPSTAT_BOOL7", true, 50)  --  Unlock High Flyer Chute Bag
end)

CSYONS25:add_action("Gooch Outfit and XMAS Liveries 😱", function()
    stats.set_bool_masked(MPX() .. "DLC12022PSTAT_BOOL7", true, 62) -- Gooch Outfit lol
    stats.set_bool_masked(MPX() .. "DLC12023PSTAT_BOOL11", true, 49)
    stats.set_bool_masked(MPX() .. "DLC12023PSTAT_BOOL11", true, 50)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL0", true, 14)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL0", true, 15)
    stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL0", true, 16)
end)

CSYONS24:add_action("Resupply your Supplements Instantly WOW😱", function()
		globals.set_int(1662873 + 1, 1)
		globals.set_int(1662873 + 2, 1)
		globals.set_int(1662873 + 3, 1)
		globals.set_int(1662873 + 4, 1)
		globals.set_int(1662873 + 5, 1)
		globals.set_int(1662873 + 6, 1)
		globals.set_int(1662873 + 7, 1)
end)

CSYONS25:add_action("instant win vehicle in Casino WOW😱", function()
		globals.set_int(1575032, -1)
		globals.set_int(1574589, 1)
		globals.set_int(1574589, 0)
end)

CSYONS24:add_action("Bypass 1 Week Robberies WOW😱", function()
		globals.set_int(262145, 34108)
end)

CSYONS25:add_action("Unlocking Unreleased Podium & Tony McTony Robberies", function()
globals.set_int(262145 + 34080, 3)
globals.set_int(262145 + 34080, 4)
end)

CSYONS25:add_action("Unlocked Not Released Awards 1.68", function()
		globals.set_int(262145, 36068)
		globals.set_int(262145, 36069)
		globals.set_int(262145, 36070)
		globals.set_int(262145, 36071)
		globals.set_int(262145, 36072)
		globals.set_int(262145, 36073)
		globals.set_int(262145, 36074)
		globals.set_int(262145, 36075)
		globals.set_int(262145, 36305)
		globals.set_int(262145, 36306)
end)

CSYONS25:add_action("Unlocked the Score Media-stick", function()
		globals.set_int(262145, 36180)
		globals.set_int(262145, 36181)
end)

CSYONS25:add_action("A media stick will spawn at 1 of 5 possible locations after calling 6115510115", function()
		globals.set_int(262145 + 2708365, 36182)
end)

CSYONS25:add_action("Unlock new Snow Launcher", function()
		globals.set_int(262145 + 36066, 1) --//1816349283
end)

CSYONS24:add_action("Enable Vincent Contact Mission", function()
		globals.set_int(262145 + 36058, 1) --1541719696
end)

CSYONS24:add_action("Enable Yeti Hunt", function()
		globals.set_int(262145 + 36054, 1)
end)


CSYONS24:add_action("Activate Random Event Christmas Truck", function()
		globals.set_int(262145, 36055) --// enable the event
		globals.set_int(262145 + 36055, 3600000) --// cooldown
		globals.set_int(262145 + 36158, 1800000) --// availability
end)

CSYONS24:add_action("Automatically Skip Cutscene", function()
    menu.end_cutscene()
end)

ut=table.unpack
function e(xx,fx)		--for each string word		(string, function)
local o={} for x in xx:gmatch("[^ ]+") do for x in x:gmatch("[^,]*") do o[1+#o]=x~="" and (tonumber(x) or x) or nil end o={fx(ut(o))} if o[1] then return ut(o) end end end
function mp()		--get saved character number		() = mx
mx="mp"..stats.get_int("mpply_last_mp_char").."_" return mx end
 
CSYONS25:add_action("get all collectibles",function() 
mp() e("casino,1,154,action_figures,playing_cards casinohst,1,50,signal_jammers su20,3,10,movie_props dlc12022,11,100,ld_organics_products dlc22022,3,25,snowmen dlc12023,1,10,ghost_hunt",function(x,o,i) x=mx..x.."pstat_bool" for i=o,-1+o+i do stats.set_bool_masked(x..(i//64),true,i%64) end end) end)

CSYONS25:add_action("Unlock all 100 Action Figures", function()
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 1)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 2)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 3)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 4)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 5)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 6)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 7)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 8)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 9)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 10)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 11)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 12)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 13)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 14)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 15)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 16)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 17)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 18)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 19)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 20)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 21)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 22)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 23)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 24)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 25)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 26)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 27)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 28)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 29)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 30)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 31)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 32)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 33)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 34)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 35)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 36)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 37)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 38)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 39)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 40)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 41)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 42)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 43)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 44)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 45)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 46)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 47)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 48)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 49)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 50)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 51)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 52)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 53)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 54)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 55)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 56)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 57)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 58)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 59)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 60)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 61)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 62)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL0", true, 63)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 0)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 1)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 2)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 3)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 4)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 5)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 6)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 7)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 8)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 9)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 10)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 11)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 12)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 13)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 14)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 15)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 16)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 17)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 18)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 19)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 20)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 21)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 22)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 23)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 24)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 25)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 26)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 27)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 28)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 29)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 30)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 31)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 32)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 33)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 34)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 35)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 36)
end)	
 
CSYONS25:add_action("Unlock all 54 Playing Cards", function()
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 37)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 38)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 39)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 40)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 41)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 42)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 43)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 44)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 45)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 46)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 47)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 48)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 49)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 50)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 51)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 52)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 53)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 54)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 55)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 56)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 57)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 58)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 59)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 60)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 61)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 62)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL1", true, 63)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 0)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 1)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 2)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 3)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 4)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 5)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 6)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 7)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 8)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 9)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 10)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 11)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 12)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 13)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 14)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 15)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 16)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 17)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 18)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 19)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 20)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 21)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 22)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 23)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 24)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 25)
	stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL2", true, 26)
end)

CSYONS25:add_action("UNLOCK ALL 9 MEDIA STICKS", function()
	stats.set_bool_masked(MPX().."TUNERPSTAT_BOOL0", true, 1)
	stats.set_bool_masked(MPX().."TUNERPSTAT_BOOL0", true, 2)
	stats.set_bool_masked(MPX().."TUNERPSTAT_BOOL0", true, 3)
	stats.set_bool_masked(MPX().."TUNERPSTAT_BOOL0", true, 4)	
	stats.set_bool_masked(MPX().."TUNERPSTAT_BOOL0", true, 5)
	stats.set_bool_masked(MPX().."TUNERPSTAT_BOOL0", true, 6)
	stats.set_bool_masked(MPX().."TUNERPSTAT_BOOL0", true, 7)
	stats.set_bool_masked(MPX().."FIXERPSTAT_BOOL0", true, 4)
end)
CSYONS25:add_action("you can find it Inventory > Media Player", function() end)

CSYONS24:add_action("Skip Nightclub Setup", function()
	stats.set_bool_masked("MP"..stats.get_int("MPPLY_LAST_MP_CHAR").."_GANGOPSPSTAT_BOOL0", true, 63) -- Staff
	stats.set_bool_masked("MP"..stats.get_int("MPPLY_LAST_MP_CHAR").."_BUSINESSBATPSTAT_BOOL0", true, 1) -- Equipment
	stats.set_bool_masked("MP"..stats.get_int("MPPLY_LAST_MP_CHAR").."_BUSINESSBATPSTAT_BOOL0", true, 2) -- Collect DJs
end)

CSYONS28:add_action("_________Weapons Ammo modifyer_________", function() end)
CSYONS28:add_array_item("Special Type", SG_map, function()
	return active_type
end, function(value)
	active_type = value
	if enable_SG then
		ResetAllWeaponStats()
		OnWeaponChanged(nil, localplayer:get_current_weapon())
	elseif enable_on_select then
		enable_SG = true
		Handle_SG(enable_SG)
	end
end)

CSYONS28:add_toggle("Special Gun", function()
	return enable_SG
end, function()
	enable_SG = not enable_SG
	Handle_SG(enable_SG)
end)

CSYONS28:add_action("Reset All Guns", function()
	enable_SG = false
 	ResetAllWeaponStats()
 end)
CSYONS28:add_action("____________________________________", function() end)

CSYON85:add_action("Enable Ghosts Exposed Event", function()
    globals.set_int(262145 + 35299, 1)
end)
 
CSYON85:add_action("Unlock Ghosts Exposed Livery", function()
	stats.set_bool_masked(MPX().."DLC12023PSTAT_BOOL0", true, 1)
	stats.set_bool_masked(MPX().."DLC12023PSTAT_BOOL0", true, 2)
	stats.set_bool_masked(MPX().."DLC12023PSTAT_BOOL0", true, 3)
	stats.set_bool_masked(MPX().."DLC12023PSTAT_BOOL0", true, 4)
	stats.set_bool_masked(MPX().."DLC12023PSTAT_BOOL0", true, 5)
	stats.set_bool_masked(MPX().."DLC12023PSTAT_BOOL0", true, 6)
	stats.set_bool_masked(MPX().."DLC12023PSTAT_BOOL0", true, 7)
	stats.set_bool_masked(MPX().."DLC12023PSTAT_BOOL0", true, 8)
	stats.set_bool_masked(MPX().."DLC12023PSTAT_BOOL0", true, 9)
	stats.set_bool_masked(MPX().."DLC12023PSTAT_BOOL0", true, 10)
end)

CSYONS85i = CSYON85:add_submenu("🎃 Jack O' Lantern🎃")
	Preset = 1
CSYONS85i:add_array_item("Unlock", {"Select", "Mask", "T-Shirt"},
	function()
		return Preset0
	end,
	function(value)
		if value == 1 then
			value = 1
		elseif value == 2 then 
			globals.set_int(2765084 + 591, 9)
		elseif value == 3 then
			globals.set_int(2765084 + 591, 199)
		end
		Preset = value
	end)
CSYONS85i:add_int_range("Set Jack O' Lanterns", 1, 0, 199,
	function()
		return globals.get_int(2765084 + 591)
	end,
	function(value)
		globals.set_int(2765084 + 591, value)
	end)

CSYONS24:add_action("*********************Night Club Editior**********************", function() end)
local CSYON24 = CSYONS24:add_submenu("Nightclub Money Methode")
local tunnableGlobalBaseIndex = 262145
 
CSYONS24:add_int_range("Sporting Goods Value", 5000, 5000, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24563)
    end, function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24563, value)
    end)
	
CSYONS24:add_int_range("S.A. Imports Value", 10000, 27000, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24564)
    end, function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24564, value)
    end)
	
CSYONS24:add_int_range("Pharmaceutical Value", 10000, 11475, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24565)
    end, function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24565, value)
    end)
	
CSYONS24:add_int_range("Organic Produce Value", 10000, 2025, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24566)
    end, function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24566, value)
    end)
	
CSYONS24:add_int_range("Printing and Copying Value", 10000, 1350, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24567)
    end, function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24567, value)
    end)
	
CSYONS24:add_int_range("Cash Creation Value", 10000, 4725, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24568)
    end, function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24568, value)
    end)
	
CSYONS24:add_int_range("Cargo Shipments Value", 10000, 10000, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24569)
    end, function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24569, value)
    end)
CSYONS24:add_action("***********************************************************", function() end)

CSYONS85:add_action("Trigger Posssessed Animals", function() 
    globals.set_int(1575020, 11)
    globals.set_int(1574589, 1) --    sleep(2)
    globals.set_int(1574589, 0) --    sleep(1)
    globals.set_int(262145 + 31881, 1000) --	sleep(2)
	globals.set_int(1890378 + 492, 1)
end)

CSYONS85:add_action("2023 POSIX", function() 
    globals.set_int(262145 + 33050, 1697101200)
end)

CSYONS85:add_action("seed values for 2023 Halloween", function() 
	globals.set_int(2794162 +6818 +3 , 19642)
	globals.set_int(2794162 +6818 +3 , 19643)
	globals.set_int(2794162 +6818 +3 , 19644)
	globals.set_int(2794162 +6818 +3 , 19645)
	globals.set_int(2794162 +6818 +3 , 19646)
	globals.set_int(2794162 +6818 +3 , 19647)
	globals.set_int(2794162 +6818 +3 , 19648)
	globals.set_int(2794162 +6818 +3 , 19649)
	globals.set_int(2794162 +6818 +3 , 19650)
	globals.set_int(2794162 +6818 +3 , 19651)
	globals.set_int(2794162 +6818 +3 , 19652)
	globals.set_int(2794162 +6818 +3 , 19653)
	globals.set_int(2794162 +6818 +3 , 19654)
	globals.set_int(2794162 +6818 +3 , 19655)
	globals.set_int(2794162 +6818 +3 , 19656)
	globals.set_int(2794162 +6818 +3 , 19657)
	globals.set_int(2794162 +6818 +3 , 19658)
	globals.set_int(2794162 +6818 +3 , 19659)
	globals.set_int(2794162 +6818 +3 , 19660)
	globals.set_int(2794162 +6818 +3 , 19661)
end)	

CSYONS25:add_action("Unlock 50 Races Won", function()
	stats.set_int("mp"..(stats.get_int("mpply_last_mp_char") or 0).."_races_won",50)
end)

CSYONS22:add_action("Nightclub $$$", function() end)
local tunnableGlobalBaseIndex = 262145
CSYONS22:add_int_range("Sporting Goods Value", 5000, 5000, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24563)
    end,
    function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24563, value)
    end)
CSYONS22:add_int_range("S.A. Imports Value", 10000, 27000, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24564)
    end,
    function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24564, value)
    end)
CSYONS22:add_int_range("Pharmaceutical Value", 10000, 11475, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24565)
    end,
    function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24565, value)
    end)
CSYONS22:add_int_range("Organic Produce Value", 10000, 2025, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24566)
    end,
    function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24566, value)
    end)
CSYONS22:add_int_range("Printing and Copying Value", 10000, 1350, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24567)
    end,
    function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24567, value)
    end)
CSYONS22:add_int_range("Cash Creation Value", 10000, 4725, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24568)
    end,
    function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24568, value)
    end)
CSYONS22:add_int_range("Cargo Shipments Value", 10000, 10000, 4000000, function()
        return globals.get_int(tunnableGlobalBaseIndex + 24569)
    end,
    function(value)
        globals.set_int(tunnableGlobalBaseIndex + 24569, value)
    end)

CSYONS29:add_action("Remove Orbital Cannon Cooldown", function() 
			stats.set_int(MPX() .. "ORBITAL_CANNON_COOLDOWN", 0) end)


CSYONS22:add_action("Remove Transaction Error", function() for i = 4537356, 4537357, 4537358 do globals.set_int(i, 0) end end)

CSYONS55:add_action("------------------------------------------------------", function() end)
CSYONS55:add_action("Deposit 500k one Click", function()
	    globals.set_int(1961347, 1)
		sleep(50)
        globals.set_int(1961347, 0)
    end
)	
 
CSYONS55:add_action("Deposit 750k one Click", function()
	    globals.set_int(1961347, 2)
		sleep(50)
        globals.set_int(1961347, 0)
    end
)	
 
CSYONS55:add_action("Deposit 1Mi one Click", function()
        globals.set_int(4536533+ 1, 2147483646)
        globals.set_int(4536533+ 7, 2147483647)
        globals.set_int(4536533+ 6, 0)
        globals.set_int(4536533+ 5, 0)
        globals.set_int(4536533+ 3, 0x615762F1)
        globals.set_int(4536533+ 2, 1000000)
        globals.set_int(4536533, 2) 
    end
)
CSYONS55:add_action("------------------------------------------------------", function() end)
CSYONS55:add_action("Don't let greed dominate you...", function() end)
CSYONS55:add_action("Enjoy with moderation.", function() end)
CSYONS55:add_action("", function() end)

CSYONS25:add_action("Unlock Taxi Livery for Broadway", function()
	stats.set_int(MPX() .. "AWD_TAXIDRIVER", 50)
end)
 
CSYONS25:add_action("Unlock Taxi Livery for Eudora", function()
	stats.set_masked_int(MPX() .. "DLC22022PSTAT_INT536", 10, 16, 8)
end)

CSYONS25:add_action("Unlock Sasquatch Costume", function()
	globals.set_int(262145 + 33157, 1)
end)

local toggle = false
CSYONS24:add_toggle("auto get hangar cargo", function()
	return toggle
end, function(bool)
	toggle = bool
	while toggle do
		if not stats.get_bool_masked(MPX().."DLC22022PSTAT_BOOL3", 9) then
			stats.set_bool_masked(MPX().."DLC22022PSTAT_BOOL3", 9, true)
		end
		sleep(1)
	end
end)

CSYONS22:add_int_range("Supply Acid Free", 1, 0, 1, function() return      
globals.get_int(262145+22049) end, function(value) 
globals.set_int(262145+22049, value) end)

CSYONS85:add_action("Enable Armoured Trucks", function()
		globals.set_int(262145 + 35055, 1)
		globals.set_int(262145 + 34038, 1200000)	
		globals.set_int(262145 + 34039, 600000)		
end)	

CSYONS85:add_action("Enable UFO Event", function()
		globals.set_int(262145 + 33172)
		globals.set_int(2738587  + 6856, 3)	
end)	

CSYONS85:add_action("Enable Possessed Animals", function()
		globals.set_int(262145 + 35065, 1)
		globals.set_int(262145 + 31881, 960000)
		globals.set_int(262145 + 31373, 1200000)			
--		globals.set_int(1484 + 128, 1)
--		globals.set_int(1484 + 128, 4)
end)	
 
CSYONS28:add_toggle("Enable Car-A-Pult", function() return enabled end, carAPult)
 
--multiply key on numpad
--menu.register_hotkey(106, carAPult)

acid_lab_production = false
CSYONS22:add_toggle("auto acid lab production", function()
    return acid_lab_production
end, function(bool)
    acid_lab_production = bool
    while (acid_lab_production == true) do
        menu.trigger_acid_lab_production()
        sleep(1)
    end
end)

CSYONS22:add_action("--------------Acid Labs Editior--------------", function() end)
CSYONS22:add_action("--------------Dont Exceed More than 2 Million --------------", function() end)
CSYONS22:add_int_range("Acid Labs Inrease Prodution Speed", 1.0, 1, 10, function()
	return globals.get_int(262145 + 32700)
end, function(value)
	globals.set_int(262145 + 32700, 0)
end)

function AL(e) if not localplayer then return end if e then globals.set_int(262145+17576, 0) else globals.set_int(262145+17576, 135000) end end 
function AC(e) if not localplayer then return end if e then globals.set_int(262145+22813, 0) else globals.set_int(262145+22813, 300000) end end 
function ACL(e) if not localplayer then return end if e then globals.set_int(262145+23412, 0) globals.set_int(262145+15797, 0) else globals.set_int(262145+23412, 12000) globals.set_int(262145+15797, 12000) end end
CSYONS22:add_int_range("Set $$", 50000, 10000, 2000000, function() return globals.get_int(262145+28200) end, function(Val) globals.set_int(262145+28200, Val) end) 
CSYONS22:add_toggle("Remove Production Delay", function() return e52 end, function() e52 = not e52 AL(e52) end)
CSYONS22:add_toggle("Remove Supply Delay", function() return e53 end, function() e53 = not e53 AC(e53) end)
CSYONS22:add_toggle("Remove Supply Cost", function() return e51 end, function() e51 = not e51 ACL(e51) end)

CSYONS22:add_int_range("Set Acid Value 2Mil", 10000.0, 10000, 99999, function()
return globals.get_int(262145 + 17425)
end, function(value)
globals.set_int(262145 + 17425, value)
end)

CSYONS22:add_int_range("Decrease Production Time", 1.0, 0, 100, function() 
	return globals.get_int(262145 + 17396)
end, function(value)
	globals.set_int(262145 + 17396, value)
end)

CSYONS22:add_int_range("Product Capacity", 1, 0, 100, function() 
	return globals.get_int(262145+19159)
end, function(value)
	globals.set_int(262145+19159, value)
end)


CSYONS22:add_int_range("Change Supplies Cost", 1, 0, 10, function() 
	return globals.get_int(262145+21869)
end, function(value)
	globals.set_int(262145+21869, value)
end)

CSYONS22:add_action("------------------------------------------------------", function() end)

CSYONS24:add_toggle('Activate new Vehicles',
function()
    return globals.get_bool(262145 + 35462)
end,
function(toggle)
    local loop = {{35462, 35469}, {35471, 35474}}
 
    for k = 1, #loop do
        for i = loop[k][1], loop[k][2] do
            globals.set_bool(262145 + i, toggle)
        end
    end
end)

--CsyonDV=Enable Deleted Vehicles----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

CsyonDV1 = 262145 + 14936
CsyonDV2 = 262145 + 14941
CsyonDV3 = 262145 + 17682
CsyonDV4 = 262145 + 17703
CsyonDV5 = 262145 + 21304
CsyonDV6 = 262145 + 21309
CsyonDV7 = 262145 + 22103
CsyonDV8 = 262145 + 22122
CsyonDV9 = 262145 + 23071
CsyonDV10 = 262145 + 23098
CsyonDV11 = 262145 + 24292
CsyonDV12 = 262145 + 24307


local DeletedVehicles = {
	262145 + 35402,
	262145 + 35404,
	262145 + 35406,
	262145 + 35408,
	262145 + 35410,
	262145 + 35412,
	262145 + 35414,
	262145 + 35416,
	262145 + 35418,
	262145 + 35420,
	262145 + 35422,
	262145 + 35424,
	262145 + 35426,
	262145 + 35428,
	262145 + 35430,
	262145 + 35432,
	262145 + 35434,
	262145 + 35436,
	262145 + 35438,
	262145 + 35440,
	262145 + 35442,
	262145 + 35444,
	262145 + 35446,
	262145 + 35448,
	262145 + 35450,
	262145 + 35452,
	262145 + 35454,
	262145 + 35456,
	262145 + 35458,
	262145 + 35460,
	262145 + 35462,
	262145 + 35464,
	262145 + 35466,
	262145 + 35468,
	262145 + 35470,
	262145 + 35472,
	262145 + 35474,
	262145 + 35476,
	262145 + 35478,
	262145 + 35480,
	262145 + 35482,
	262145 + 35484,
	262145 + 35486,
	262145 + 35488,
	262145 + 35490,
	262145 + 35492,
	262145 + 35494,
	262145 + 35496,
	262145 + 35498,
	262145 + 35500,
	262145 + 35502,
	262145 + 35504,
	262145 + 35506,
	262145 + 35508,
	262145 + 35510,
	262145 + 35512,
	262145 + 35514,
	262145 + 35516,
	262145 + 35518,
	262145 + 35520,
	262145 + 35522,
	262145 + 35524,
	262145 + 35526,
	262145 + 35528,
	262145 + 35530,
	262145 + 35532,
	262145 + 35534,
	262145 + 35536,
	262145 + 35538,
	262145 + 35540,
	262145 + 35542,
	262145 + 35544,
	262145 + 35546,
	262145 + 35548,
	262145 + 35550,
	262145 + 35552,
	262145 + 35554,
	262145 + 35556,
	262145 + 35558,
	262145 + 35560,
	262145 + 35562,
	262145 + 35564,
	262145 + 35566,
	262145 + 35568,
	262145 + 35570,
	262145 + 35572,
	262145 + 35574,
	262145 + 35576,
	262145 + 35578,
	262145 + 35580,
	262145 + 35582,
	262145 + 35584,
	262145 + 35586,
	262145 + 35588,
	262145 + 35590,
	262145 + 35592,
	262145 + 35594,
	262145 + 35596,
	262145 + 35598,
	262145 + 35600,
	262145 + 35602,
	262145 + 35604,
	262145 + 35606,
	262145 + 35608,
	262145 + 35610,
	262145 + 35612,
	262145 + 35614,
	262145 + 35616,
	262145 + 35618,
	262145 + 35620,
	262145 + 35622,
	262145 + 35624,
	262145 + 35626,
	262145 + 35628,
	262145 + 35630,
	262145 + 35632,
	262145 + 35634,
	262145 + 35636,
	262145 + 35638,
	262145 + 35640,
	262145 + 35642,
	262145 + 35644,
	262145 + 35646,
	262145 + 35648,
	262145 + 35650,
	262145 + 35652,
	262145 + 35654,
	262145 + 35656,
	262145 + 35658,
	262145 + 35660,
	262145 + 35662,
	262145 + 35664,
	262145 + 35666,
	262145 + 35668,
	262145 + 35670,
	262145 + 35672,
	262145 + 35674,
	262145 + 35676,
	262145 + 35678,
	262145 + 31306,
	262145 + 32221,
}

CSYONS24:add_toggle("Activate old Vehicles", function()
	return globals.get_boolean(262145 + 35402)
end, function(value)
	for a = CsyonDV1, CsyonDV2 do
		globals.set_boolean(a, value)
	end
	for b = CsyonDV3, CsyonDV4 do
		globals.set_boolean(b, value)
	end
	for c = CsyonDV5, CsyonDV6 do
		globals.set_boolean(c, value)
	end
	for d = CsyonDV7, CsyonDV8 do
		globals.set_boolean(d, value)
	end
	for e = CsyonDV9, CsyonDV10 do
		globals.set_boolean(e, value)
	end
	for f = CsyonDV11, CsyonDV12 do
		globals.set_boolean(f, value)
	end
	for q = 1, #DeletedVehicles do
		globals.set_boolean(DeletedVehicles[q], value)
	end
end)


CSYONS25:add_action("Unlocking the Gun Van Weapons", function()
globals.set_int(262145 + 34094 + 3, -22923932) ----- The RailGun
globals.set_int(262145 + 34094 + 4, -1238556825) -----The WidoMaker
globals.set_int(262145 + 34094 + 5, -1355376991) -----The RayPistol
globals.set_int(262145 + 34094 + 6, 1198256469) -----The HellBringer
globals.set_int(262145 + 34094 + 7, -1786099057) -----The BaseBall Bat
end)

CSYONS24:add_toggle("Enable Removed Vehicles", function() 
return globals.get_int(262145+1845263) end, 
function(value) local EnableNumb = 35167 
local StopNumb = 20394 for i = EnableNumb, StopNumb, 2 do globals.set_int(262145 + i, 1) 
   end 
end)

CSYONS35:add_action("Enable Random Spawn Ghost Hunt 8PM & 6AM", function()
		globals.set_int(262145 + 33050, 1665662400)
		globals.set_int(262145 + 33051, 1)
		globals.set_int(2794162 + 6818 + 3, 19294)	
--		globals.set_int(262145 + 35064, 0)
--		globals.set_int(262145 + 35158, 50000)
end)	

CSYONS35:add_action("Enable Original Freemode Events", function()
		globals.set_int(262145 + 12046, 1)
end)

CSYONS35:add_action("Create Drop ", function()
		globals.set_int(262145 + 7203, 0)
end)

CSYONS35:add_action("Armoured Truck", function()
		globals.set_int(262145 + 7204, 0)
end)

CSYONS35:add_action("Destroy Vehicle", function()
		globals.set_int(262145 + 8742, 0)
end)

CSYONS35:add_action("Distract Cops", function()
		globals.set_int(262145 + 8737, 0)
end)

CSYONS35:add_action("Plane Takedown", function()
		globals.set_int(262145 + 8732, 0)
end)

CSYONS25:add_action("Unlock BaseBall Bat And Knife Skin In GunVan Drug Wars 1.67", function()
globals.set_int(262145 + 34365, 0) ----- Crazy Globals for this W Option lel
globals.set_int(262145 + 34328 + 9, -1716189206) ----- Knife Skin 
globals.set_int(262145 + 34328 + 10, -1786099057) ----- BaseBall Bat Skin
end)

CSYONS25:add_action("Unlock Diamond Casino Heist Outfits", function()
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL1", true, 63) -- Refuse Collectors
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 0) -- Undertakers
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 1) -- Valet Outfits
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 3) -- Prison Guards
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 4) -- FIB Suits
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 6) -- Gruppe Sechs Gear
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 7) -- Bugstars Uniforms
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 8) -- Maintenance
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 9) -- Yung Ancestors
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 10) -- Firefighter Gear
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 11) -- Orderly Armor
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 12) -- Upscale Armor
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 13) -- Evening Armor
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 14) -- Reinforced: Padded Combat
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 15) -- Reinforced: Bulk Combat
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 16) -- Reinforced: Compact Combat
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 17) -- Balaclava Crook
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 18) -- Classic Crook
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 19) -- High-end Crook
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 20) -- Infiltration: Upgraded Tech
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 21) -- Infiltration: Advanced Tech
	stats.set_bool_masked(MPX() .. "CASINOHSTPSTAT_BOOL2", true, 22) -- Infiltration: Modernized Tech
end)

CSYONS25:add_action("Unlock exclusive Outfits", function() 
			stats.set_int(262145, 16964) --White Jock Cranley Suit
			stats.set_int(262145, 16966) --Red Jock Cranley Suit
			stats.set_int(262145, 16965) --Blue Jock Cranley Suit
			stats.set_int(262145, 16967) --Gold Jock Cranley Suit
			stats.set_int(262145, 16968) --Black Jock Cranley Suit
			stats.set_int(262145, 16969) --Pink Jock Cranley Suit
			stats.set_int(262145, 16970) --Silver Jock Cranley Suit
			stats.set_int(262145, 23588) --Green Wireframe Bodysuit
			stats.set_int(262145, 23589) --Orange Wireframe Bodysuit
			stats.set_int(262145, 23590) --Blue Wireframe Bodysuit
			stats.set_int(262145, 23591) --Pink Wireframe Bodysuit
			stats.set_int(262145, 23592) --Yellow Wireframe Bodysuit
			stats.set_int(262145, 27315) --High Roller Outfit
			stats.set_int(262145, 31415) --Penitentiary Coveralls
			stats.set_int(262145, 31398) --LS Customs Coveralls
			stats.set_int(262145, 31405) --eCola Bodysuit
			stats.set_int(262145, 31406) --Sprunk Bodysuit
			stats.set_int(262145, 35510) --The Retired Criminal
			stats.set_int(262145, 35511) --The Groupie
			stats.set_int(262145, 35509) --The Homie
end)

CSYONS25:add_action("Unlock Junk Energy", function()
globals.set_int(262145+35056,0)--Junk Energy Time Trial
globals.set_int(262145+35156,-1)--Junk Energy Time Trial location
end)

CSYONS25:add_action("Unlock Ace Mask Diamond Restore Store", function()
		globals.set_int(262145 + 27533, 1) --Ace of Diamonds
		globals.set_int(262145 + 27532, 1) --Ace of Clubs
		globals.set_int(262145 + 27531, 1) --Ace of Hearts
		globals.set_int(262145 + 27530, 1) --Ace of Spades
end)

CSYONS25:add_action('Unlock Vanilla Unicorn', function()
        stats.set_int(MPX() .. 'LAP_DANCED_BOUGHT', 0)
        stats.set_int(MPX() .. 'LAP_DANCED_BOUGHT', 5)
        stats.set_int(MPX() .. 'LAP_DANCED_BOUGHT', 10)
        stats.set_int(MPX() .. 'LAP_DANCED_BOUGHT', 15)
        stats.set_int(MPX() .. 'LAP_DANCED_BOUGHT', 25)
        stats.set_int(MPX() .. 'PROSTITUTES_FREQUENTED', 1000)
    end
)

CSYONS28:add_action("Get all Weapons Upgrades (Temporary)", function() stats.set_int(MPX() .. "CHAR_WEAP_ADDON_1_UNLCK", -1) stats.set_int(MPX() .. "CHAR_WEAP_ADDON_2_UNLCK", -1) stats.set_int(MPX() .. "CHAR_WEAP_ADDON_3_UNLCK", -1) stats.set_int(MPX() .. "CHAR_WEAP_ADDON_4_UNLCK", -1) stats.set_int(MPX() .. "CHAR_WEAP_FREE", -1) stats.set_int(MPX() .. "CHAR_WEAP_FREE2", -1) stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE", -1) stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE2", -1) stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE3", -1) stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE4", -1) stats.set_int(MPX() .. "CHAR_WEAP_PURCHASED", -1) stats.set_int(MPX() .. "CHAR_WEAP_PURCHASED2", -1) stats.set_int(MPX() .. "WEAPON_PICKUP_BITSET", -1) stats.set_int(MPX() .. "WEAPON_PICKUP_BITSET2", -1) stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED", -1) stats.set_int(MPX() .. "NO_WEAPONS_UNLOCK", -1) stats.set_int(MPX() .. "NO_WEAPON_MODS_UNLOCK", -1) stats.set_int(MPX() .. "NO_WEAPON_CLR_MOD_UNLOCK", -1) stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE", -1) stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE", -1) stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE2", -1) stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE3", -1) stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE4", -1) stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH", -1) for i = 2, 19 do stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH"..i, -1) end for l = 2, 41 do stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE"..l, -1) end globals.set_int(1575015, 1) globals.set_int(1575015, 1) globals.set_int(LOBS2, 1) sleep(0.2) globals.set_int(LOBS2, 0) end)

CSYONS24:add_action("reset LSC vehicle sell limit", function() 
			stats.set_int("MPPLY_VEHICLE_SELL_TIME", 0)
			stats.set_int("MPPLY_NUM_CARS_SOLD_TODAY", 0)
end)

CSYONS22:add_action("Bunker $$$ Methode", function() end)
CSYONS22:add_float_range("Sale Multiplier", 0.5, 1, 1000, function() return globals.get_float(BSM1) end, function(value) globals.set_float(BSM1, value) globals.set_float(BSM2, value) end) 
local function EBdt(e) if not localplayer then return end if e then globals.set_int(EBD1, 14400000) globals.set_int(EBD2, 15000000) globals.set_int(EBD3, 15600000) globals.set_int(EBD4, 16200000) globals.set_int(EBD5, 16800000) globals.set_int(EBD6, 17400000) globals.set_int(EBD7, 18000000) globals.set_int(EBD8, 18600000) globals.set_int(EBD9, 19200000) globals.set_int(EBD10, 19800000) globals.set_int(EBD11, 20400000) globals.set_int(EBD12, 21000000) globals.set_int(EBD13, 21600000) globals.set_int(EBD14, 22200000) globals.set_int(EBD15, 22800000) globals.set_int(EBD16, 23400000) globals.set_int(EBD17, 24000000) globals.set_int(EBD18, 24600000) globals.set_int(EBD19, 25200000) globals.set_int(EBD20, 25800000) else  globals.set_int(EBD1, 1800000) globals.set_int(EBD2, 1800000) globals.set_int(EBD3, 1800000) globals.set_int(EBD4, 1800000) globals.set_int(EBD5, 1800000) globals.set_int(EBD6, 1800000) globals.set_int(EBD7, 1800000) globals.set_int(EBD8, 1800000) globals.set_int(EBD9, 1800000) globals.set_int(EBD10, 1800000) globals.set_int(EBD11, 1800000) globals.set_int(EBD12, 1800000) globals.set_int(EBD13, 1800000) globals.set_int(EBD14, 1800000) globals.set_int(EBD15, 900000) globals.set_int(EBD16, 900000) globals.set_int(EBD17, 1800000) globals.set_int(EBD18, 900000) globals.set_int(EBD19, 900000) globals.set_int(EBD20, 900000) end end 
CSYONS22:add_toggle("Extend Bunker Delivery Timer", function() return e45 end, function() e45 = not e45 EBdt(e45) end)
local function BRd(e) if not localplayer then return end if e then globals.set_int(RBD1, 10) else globals.set_int(RBD1, 600) end end 
CSYONS22:add_toggle("Remove Bunker Resupply Delay", function() return e47 end, function() e47 = not e47 BRd(e47) end)
local function BRC(e) if not localplayer then return end if e then globals.set_int(RBS1, 1000) globals.set_int(RBS2, 1000) else globals.set_int(RBS1, 15000) globals.set_int(RBS2, 15000) end end 
CSYONS22:add_toggle("Reduce Bunker Resupply Cost", function() return e23 end, function() e23 = not e23 BRC(e23) end)
local function Brr(e) if not localplayer then return end if e then stats.set_int(MPX().."PAYRESUPPLYTIMER5", 1) sleep(0.1)  else stats.set_int(MPX().."PAYRESUPPLYTIMER5", 0) end end 
CSYONS22:add_toggle("Refill Bunker Supplies(experimental)", function() return e27 end, function() e27 = not e27 Brr(e27) end)
local function SbP(e) if not localplayer then return end if e then globals.set_int(BSU1, 0) menu.trigger_bunker_production() else globals.set_int(BSU1, 600000) end end 
CSYONS22:add_toggle("Speed Up Production", function() return e49 end, function() e49 = not e49 SbP(e49) end)
CSYONS22:add_action("----------------Cargo Sell Methode-------------------", function() end) 
CSYONS22:add_action("Reset Stats 20M/1000 sales", function() stats.set_int(MPX() .. "LFETIME_BIKER_SELL_COMPLET5", 500) stats.set_int(MPX() .. "LIFETIME_BKR_SEL_COMPLETBC5", 500) stats.set_int(MPX() .. "LIFETIME_BKR_SELL_EARNINGS5", 20000000) globals.set_int(SCG1, 1) globals.set_int(SCG2, 1) sleep(0.2) globals.set_int(SCG2, 0) end) 
CSYONS22:add_action("-------~Max=8M------------", function() end)
CSYONS22:add_action("Get Crates", function() for i = 12, 16 do stats.set_bool_masked(MPX().."FIXERPSTAT_BOOL1", true, i, MPX()) end end)
local function CCooldown(e) if not localplayer then return end if e then globals.set_int(CRC1, 0) globals.set_int(CRC2, 0) else globals.set_int(CRC1, 300000) globals.set_int(CRC2, 1800000) end end 
CSYONS22:add_toggle("Remove Cooldowns", function() return e13 end, function() e13 = not e13 CCooldown(e13) end)
CSYONS22:add_toggle("Random Unique Cargo Toggle", function() return globals.get_boolean(1949968) end, function(value) globals.set_boolean(1949968, value) end) 
CSYONS22:add_array_item("Select Unique Cargo", {"Ornamental Egg", "Gold Minigun", "Large Diamond", "Rage Hide", "Film Reel", "Rare Pocket Watch"}, function() return xox_33 end, function(value) xox_33 = value if value == 1 then globals.set_int(1949968, 1) globals.set_int(1949814, 2) elseif value == 2 then globals.set_int(1949968, 1) globals.set_int(1949814, 4) elseif value == 3 then globals.set_int(1949968, 1) globals.set_int(1949814, 6) elseif value == 4 then globals.set_int(1949968, 1) globals.set_int(1949814, 7) elseif value == 5 then globals.set_int(1949968, 1) globals.set_int(1949814, 8) else globals.set_int(1949968, 1) globals.set_int(1949814, 9) end end) 
CSYONS22:add_action("-------~Max=6M------------", function() end)
CSYONS22:add_action("Auto-Reset stats-20M/1000Sales", function() stats.set_int(MPX() .. "LIFETIME_BUY_COMPLETE", 1000) stats.set_int(MPX() .. "LIFETIME_BUY_UNDERTAKEN", 1000) stats.set_int(MPX() .. "LIFETIME_SELL_COMPLETE", 1000) stats.set_int(MPX() .. "LIFETIME_SELL_UNDERTAKEN", 1000) stats.set_int(MPX() .. "LIFETIME_CONTRA_EARNINGS", 20000000) globals.set_int(SCG1, 1) globals.set_int(SCG2, 1) sleep(0.2) globals.set_int(SCG2, 0) end)
CSYONS22:add_int_range("Manually Reset stats-No. of Sales", 1, 0, 1000, function() return stats.get_int(MPX() .. "LIFETIME_SELL_COMPLETE") end, function(value) stats.set_int(MPX() .. "LIFETIME_BUY_COMPLETE", value) stats.set_int(MPX() .. "LIFETIME_BUY_UNDERTAKEN", value) stats.set_int(MPX() .. "LIFETIME_SELL_COMPLETE", value) stats.set_int(MPX() .. "LIFETIME_SELL_UNDERTAKEN", value) stats.set_int(MPX() .. "LIFETIME_CONTRA_EARNINGS", value * 20000) globals.set_int(SCG1, 1) globals.set_int(SCG2, 1) sleep(0.2) globals.set_int(SCG2, 0) end)
CSYONS22 = CSYON22:add_submenu("Nightclub $$$ Methode") local function NCooldown(e) if not localplayer then return end if e then globals.set_int(NRC1, 0) globals.set_int(NRC2, 0) globals.set_int(NRC3, 0) else globals.set_int(NRC1, 300000) globals.set_int(NRC2, 300000) globals.set_int(NRC3, 300000) end end 
CSYONS22:add_toggle("Remove Cooldowns", function() return e14 end, function() e14 = not e14 NCooldown(e14) end)
CSYONS22:add_action("-----------------NC Money Methode--------------------------", function() end)
CSYONS22:add_float_range("TTP Multiplier", 0.5, 0.5, 1000, function() return globals.get_float(TTM1) end, function(value) globals.set_float(TTM1, value) end)
CSYONS22:add_array_item("Production", {"Speed Up", "Reset Speed"}, function() return xox_17 end, function(v) if v == 1 then for i = PSU1, PSU2 do globals.set_int(i, 1) end menu.trigger_nightclub_production() else globals.set_int(PSU1, 4800000) globals.set_int(PSU3, 14400000) globals.set_int(PSU4, 7200000) globals.set_int(PSU5, 2400000) globals.set_int(PSU6, 1800000) globals.set_int(PSU7, 3600000) globals.set_int(PSU2, 8400000) end xox_17 = v end) 
CSYONS22:add_action("---", function() end)
CSYONS22:add_int_range("Sporting Goods Value", 5000, 5000, 4000000, function() return globals.get_int(SGV1) end, function(value) globals.set_int(SGV1, value) end)
CSYONS22:add_int_range("S.A. Imports Value", 10000, 27000, 4000000, function() return globals.get_int(SAV1) end, function(value) globals.set_int(SAV1, value) end)
CSYONS22:add_int_range("Pharmaceutical Value", 10000, 11475, 4000000, function() return globals.get_int(PHV1) end, function(value) globals.set_int(PHV1, value) end)
CSYONS22:add_int_range("Organic Produce Value", 10000, 2025, 4000000, function() return globals.get_int(OPV1) end, function(value) globals.set_int(OPV1, value) end)
CSYONS22:add_int_range("Printing and Copying Value", 10000, 1350, 4000000, function() return globals.get_int(PCV1) end, function(value) globals.set_int(PCV1, value) end)
CSYONS22:add_int_range("Cash Creation Value", 10000, 4725, 4000000, function() return globals.get_int(CCV1) end, function(value) globals.set_int(CCV1, value) end)
CSYONS22:add_toggle("Remove Tony's cut", function() return e29 end, function() e29 = not e29 tonyC(e29) end) 
CSYONS22:add_action("-------~Max=8M------------", function() end)
CSYONS22:add_int_range("Reset Sales", 1, 0, 1000, function() return stats.get_int(MPX() .. "HUB_SALES_COMPLETED") end, function(value) stats.set_int(MPX() .. "HUB_S93271ALES_COMPLETED", value) end) 
CSYONS22:add_int_range("Reset Earnings", 500000, 0, 30000000, function() return stats.get_int(MPX() .. "HUB_EARNINGS") end, function(value) stats.set_int(MPX() .. "HUB_EARNINGS", value) globals.set_int(SCG1, 1) globals.set_int(SCG2, 1) sleep(0.2) globals.set_int(SCG2, 0) end)
CSYONS22 = CSYON22:add_submenu("Hanger Cargo $$$") local function Cooldown(e) if not localplayer then return end if e then for i = 284924, 284900 do globals.set_int(i, 0) globals.set_int(i, 1) end else globals.set_int(284868, 120000) globals.set_int(284897, 180000) globals.set_int(284898, 240000) globals.set_int(284927, 60000) globals.set_int(284900, 2000) end end 
CSYONS22:add_toggle("Remove Cooldowns", function() return e15 end, function() e15 = not e15 Cooldown(e15) end)
CSYONS22:add_action("-----------------Cargos Money Methode--------------------------", function() end)
CSYONS22:add_int_range("All/Mixed Value", 50000, 10000, 3100000, function() return globals.get_int(ALV1) end, function(value) globals.set_int(ALV1, value) end)
CSYONS22:add_int_range("Animal Material Value", 50000, 10000, 3100000, function() return globals.get_int(AMV1) end, function(value) globals.set_int(AMV1, value) end)
CSYONS22:add_int_range("Art n Antiques Value", 50000, 10000, 3100000, function() return globals.get_int(AAV1) end, function(value) globals.set_int(AAV1, value) end)
CSYONS22:add_int_range("Chemicals Value", 50000, 10000, 3100000, function() return globals.get_int(CHV1) end, function(value) globals.set_int(CHV1, value) end)
CSYONS22:add_int_range("Counterfeit Value", 50000, 10000, 3100000, function() return globals.get_int(COV1) end, function(value) globals.set_int(COV1, value) end)
CSYONS22:add_int_range("Jewelry Value", 50000, 10000, 3100000, function() return globals.get_int(JEV1) end, function(value) globals.set_int(JEV1, value) end)
CSYONS22:add_int_range("Medical Sup Value", 50000, 10000, 3100000, function() return globals.get_int(MSV1) end, function(value) globals.set_int(MSV1, value) end)
CSYONS22:add_int_range("Narcotics Value", 50000, 10000, 3100000, function() return globals.get_int(NAV1) end, function(value) globals.set_int(NAV1, value) end)
CSYONS22:add_int_range("Tabacco Value", 50000, 10000, 3100000, function() return globals.get_int(TAV1) end, function(value) globals.set_int(TAV1, value) end)
local function ronC(e) if not localplayer then return end if e then globals.set_float(RRC1, 0) else globals.set_float(RRC1, 0.025) end end 
CSYONS22:add_toggle("Remove Rons's cut", function() return e30 end, function() e30 = not e30 ronC(e30) end)
CSYONS22:add_int_range("Reset stats-No. of Sales", 1, 0, 500, function() return stats.get_int(MPX() .. "LFETIME_HANGAR_SEL_COMPLET") end, function(value) stats.set_int(MPX() .. "LFETIME_HANGAR_BUY_UNDETAK", value) stats.set_int(MPX() .. "LFETIME_HANGAR_BUY_COMPLET", value) stats.set_int(MPX() .. "LFETIME_HANGAR_SEL_UNDETAK", value) stats.set_int(MPX() .. "LFETIME_HANGAR_SEL_COMPLET", value) stats.set_int(MPX() .. "LFETIME_HANGAR_EARNINGS", value * 40000) globals.set_int(SCG1, 1) globals.set_int(SCG2, 1) sleep(0.2) globals.set_int(SCG2, 0) end)
CSYONS22 = CSYON22:add_submenu("MC $$$") local function Speed(e) if not localplayer then return end if e then for i = SUP1, SUP2 do globals.set_int(i, 0) globals.set_int(i, 1) end else globals.set_int(SUP3, 300000) globals.set_int(SUP2, 720000) globals.set_int(SUP4, 3000000) globals.set_int(SUP5, 1800000) globals.set_int(SUP1, 360000) end end 
CSYONS22:add_toggle("Speed Up Production", function() return e16 end, function() e16 = not e16 Speed(e16) end)
CSYONS22:add_action("-----------------MC Money Methode--------------------------", function() end)
local function EMCdt(e) if not localplayer then return end if e then globals.set_int(EMD1, 14400000) globals.set_int(EMD2, 6600000) globals.set_int(EMD3, 7200000) globals.set_int(EMD4, 7800000) globals.set_int(EMD5, 8400000) globals.set_int(EMD6, 9000000) globals.set_int(EMD7, 9600000) globals.set_int(EMD8, 10200000) globals.set_int(EMD9, 10800000) globals.set_int(EMD10, 11400000) globals.set_int(EMD11, 12000000) globals.set_int(EMD12, 12600000) globals.set_int(EMD13, 13200000) globals.set_int(EMD14, 13800000) else globals.set_int(EMD1, 1800000) globals.set_int(EMD2, 1800000) globals.set_int(EMD3, 1800000) globals.set_int(EMD4, 1800000) globals.set_int(EMD5, 1800000) globals.set_int(EMD6, 1800000) globals.set_int(EMD7, 1800000) globals.set_int(EMD8, 1800000) globals.set_int(EMD9, 900000) globals.set_int(EMD10, 900000) globals.set_int(EMD11, 1800000) globals.set_int(EMD12, 900000) globals.set_int(EMD13, 900000) globals.set_int(EMD14, 900000) end end 
CSYONS22:add_toggle("Extend MC Delivery Timer", function() return e46 end, function() e46 = not e46 EMCdt(e46) end)
local function VRC(e) if not localplayer then return end if e then globals.set_int(RSC1, 1000) else globals.set_int(RSC1, 1000) end end 
CSYONS22:add_toggle("Remove Resupply Cost", function() return e22 end, function() e22 = not e22 VRC(e22) end) 
local function VRD(e) if not localplayer then return end if e then globals.set_int(RSD1, 10) else globals.set_int(RSD1, 600) end end 
CSYONS22:add_toggle("Refill Supplies(experimental)", function() return e25 end, function() e25 = not e25 MCrr(e25) end)
local function MCgs(e) if not localplayer then return end if e then globals.set_int(GSM1, 0) else globals.set_int(GSM1, 40000) end end 
CSYONS22:add_toggle("Remove Global Signal", function() return e24 end, function() e24 = not e24 MCgs(e24) end)
CSYONS22:add_float_range("Sale Multiplier", 0.5, 1, 1000, function() return globals.get_float(MSM1) end, function(value) globals.set_float(MSM1, value) globals.set_float(MSM2, value) end) 
CSYONS22:add_action(" ~Use the multiplier to get max 8 mil~ ", function() end)
CSYONS22 = CSYON22:add_submenu("Autoshop Client Cars $$$ Methode") local function ACCC(e) if not localplayer then return end if e then globals.set_int(ACC1, 0) else globals.set_int(ACC1, 2880) end end 
CSYONS22:add_toggle("Remove Cooldown", function() return e35 end, function() e35 = not e35 ACCC(e35) end)
CSYONS22:add_int_range("% Chance", 5, 0, 100, function() return globals.get_int(CHA1) end, function(value) globals.set_int(CHA1, value) end)
CSYONS22:add_float_range("2 Lifts Cooldown Multiplier", 0.5, 0.0, 100, function() return globals.get_float(LOM1) end, function(value) globals.set_float(LOM1, value) end)
local function etCC(e) if not localplayer then return end if e then globals.set_int(EXT1, 99999) else globals.set_int(EXT1, 600) end end 
CSYONS22:add_toggle("Extend Timer", function() return e36 end, function() e36 = not e36 etCC(e36) end)
CSYONS22:add_int_range("Low Tier", 5000, 20000, 100000, function() return globals.get_int(MHT1) end, function(value) globals.set_int(MHT1, value) end)
CSYONS22:add_int_range("Mid Tier", 5000, 25000, 125000, function() return globals.get_int(MMT1) end, function(value) globals.set_int(MMT1, value) end)
CSYONS22:add_int_range("High Tier", 5000, 30000, 150000, function() return globals.get_int(MLT1) end, function(value) globals.set_int(MLT1, value) end)
CSYONS22 = CSYON22:add_submenu("Vehicle Cargo $$$ Methode") local function Max(e) if not localplayer then return end if e then globals.set_int(MAR1, 155000) globals.set_int(MAR2, 155000) globals.set_int(MAR3, 155000) globals.set_float(MAR4, 0) globals.set_float(MAR5, 0) else globals.set_int(MAR1, 40000) globals.set_int(MAR2, 25000) globals.set_int(MAR3, 15000) globals.set_float(MAR4, 0.25) globals.set_float(MAR5, 0.5) end end 
CSYONS22:add_toggle("Max all Ranges", function() return e17 end, function() e17 = not e17 Max(e17) end)
local function VCD(e) if not localplayer then return end if e then for i = VHR1, VHR2 do globals.set_int(i, 0) sleep(1) globals.set_int(i, 1) end globals.set_int(VHR3, 1) else globals.set_int(VHR3, 180000) globals.set_int(VHR1, 1200000) globals.set_int(VHR4, 1680000) globals.set_int(VHR5, 2340000) globals.set_int(VHR2, 2880000) end end 
CSYONS22:add_toggle("Remove Cooldown", function() return e18 end, function() e18 = not e18 VCD(e18) end)
local function VRC(e) if not localplayer then return end if e then for i = RRC1, RRC3 do globals.set_int(i, 0) end else globals.set_int(RRC1, 34000) globals.set_int(RRC2, 21250) globals.set_int(RRC3, 12750) end end 
CSYONS22:add_toggle("Remove Repair Cost", function() return e21 end, function() e21 = not e21 VRC(e21) end) 
CSYONS22:add_action("---", function() end)
CSYONS22:add_int_range("Top Range", 1000, 40000, 4000000, function() return globals.get_int(TOR1) end, function(value) globals.set_int(TOR1, value) end)
CSYONS22:add_int_range("Mid Range", 1000, 25000, 4000000, function() return globals.get_int(MIR1) end, function(value) globals.set_int(MIR1, value) end)
CSYONS22:add_int_range("Stanard Range", 1000, 15000, 4000000, function() return globals.get_int(STR1) end, function(value) globals.set_int(STR1, value) end)
CSYONS22:add_float_range("Sale Showroom", 0.5, 1.5, 1000, function() return globals.get_float(SAH1) end, function(value) globals.set_float(SAH1, value) end)
CSYONS22:add_float_range("Sale Specialist Dealer", 0.5, 2, 1000, function() return globals.get_float(SPD1) end, function(value) globals.set_float(SPD1, value) end)
CSYONS22:add_float_range("Upgrade Cost Showroom", 0.25, 0, 1000, function() return globals.get_float(UCR1) end, function(value) globals.set_float(UCR1, value) end)
CSYONS22:add_float_range("Upgrade Cost Specialist Dealer", 0.25, 0, 1000, function() return globals.get_float(UCS1) end, function(value) globals.set_float(UCS1, value) end)
CSYONS22:add_action("-----------------Supply Money Methode--------------------------", function() end)
CSYONS22:add_int_range("Set Sell price", 50000, 10000, 2000000, function() return globals.get_int(CsyonsACL1) end, function(Val) globals.set_int(CsyonsACL1, Val) end) 
CSYONS22:add_int_range("Product-Capacity", 1, 1, 2000000, function() return globals.get_int(CsyonsACL3) end, function(Val) globals.set_int(CsyonsACL3, Val) end) 
local function ACL(e) if not localplayer then return end if e then globals.set_int(CsyonsACL4, 0) globals.set_int(CsyonsACL5, 0) else globals.set_int(CsyonsACL4, 12000) globals.set_int(CsyonsACL5, 12000) end end 
CSYONS22:add_toggle("Reduce Resupply Cost", function() return e51 end, function() e51 = not e51 ACL(e51) end)
local function AC(e) if not localplayer then return end if e then globals.set_int(CsyonsACL6, 0) else globals.set_int(CsyonsACL6, 300000) end end 
CSYONS22:add_toggle("Remove Resupply Delay", function() return e53 end, function() e53 = not e53 AC(e53) end)
local function AL(e) if not localplayer then return end if e then globals.set_int(CsyonsACL2, 0) else globals.set_int(CsyonsACL2, 135000) end end 
CSYONS22:add_toggle("Remove Production Delay", function() return e52 end, function() e52 = not e52 AL(e52) end)
CSYONS22:add_action("--------------------------limit Max=2M--------------------------------", function() end)
CSYONS22:add_action("~~~~~~~~~~~Every Thing Tested in:solo public Lobby~~~~~~~~~~~~~~~~~~~~~~~", function() end)

local function reloadSpeed()
	if localplayer == number then
		return
	end
	current_weapon = localplayer:get_current_weapon()
		if current_weapon ~= number then
			current_weapon:set_reload_time_multiplier(0.1)
		end
    end
    
	CSYONS28:add_action("Reload Speed", reloadSpeed)
CSYONS28:add_action("_________Weapons modifyer_________", function() end)
local function wEp()if localplayer:get_current_weapon()then return true end return false end
 
local bT,WR,LR=0,0,0
local function OnWeaponChanged(oldWeapon, newWeapon)
	if newWeapon~=nil then NAME=localplayer:get_current_weapon():get_name_hash()
		if NAME==joaat("weapon_hominglauncher") then newWeapon:set_range(1500) elseif NAME==joaat("weapon_raypistol") then
			newWeapon:set_heli_force(1075) newWeapon:set_ped_force(63) newWeapon:set_vehicle_force(1075) end
		if bT==0 then if NAME==joaat("weapon_stungun_mp") or NAME==joaat("weapon_stungun") then newWeapon:set_time_between_shots(1)
			elseif NAME==joaat("weapon_raypistol") then newWeapon:set_time_between_shots(0.5) end
			else newWeapon:set_time_between_shots(bT) end
		if WR~=0 then newWeapon:set_range(WR) else if NAME==joaat("weapon_raypistol") then newWeapon:set_range(1200)
			elseif NAME==joaat("weapon_stungun_mp") or NAME==joaat("weapon_stungun") then newWeapon:set_range(1000) end end
		if LR==0 then if NAME==joaat("weapon_hominglauncher") then newWeapon:set_lock_on_range(1500) end
			else newWeapon:set_lock_on_range(LR) end end
end
------
if WCD then menu.remove_callback(WCD) end local WCD=nil
if enable then local WCD = menu.register_callback('OnWeaponChanged', OnWeaponChanged) end
 
local function mxwep()
	localplayer:get_current_weapon():set_heli_force(60000) localplayer:get_current_weapon():set_ped_force(60000)
	localplayer:get_current_weapon():set_vehicle_force(60000) localplayer:get_current_weapon():set_time_between_shots(0.1)
	localplayer:get_current_weapon():set_range(2000) localplayer:get_current_weapon():set_lock_on_range(2000)
	localplayer:get_current_weapon():set_spread(0.2)
end
if WepTw~=nil then menu.register_hotkey(WepTw, mxwep) end
 
CSYONS28:add_toggle("QuickFire-Atmzer,StnGun/Auto", function() return enable end, function()
	enable=not enable if enable then WCD=menu.register_callback('OnCSYONS28onChanged', OnWeaponChanged)else menu.remove_callback(WCD) bT,WR,LR=0,0,0 end
end)
 
CSYONS28:add_float_range("Time Between Shots for all", 0.1, 0, 4, function()if wEp()then return localplayer:get_current_weapon():get_time_between_shots()end end, function(BtSh)
	bT=BtSh localplayer:get_current_weapon():set_time_between_shots(BtSh)
end)
CSYONS28:add_float_range("Weapon Range for all", 10, 0, 1500, function()if wEp()then return localplayer:get_current_weapon():get_range()end end, function(range)
	WR=range localplayer:get_current_weapon():set_range(range)
end)
CSYONS28:add_float_range("Lock-On Range", 10, 0, 1500, function()if wEp()then return localplayer:get_current_weapon():get_lock_on_range()end end, function(Lock)
	LR=Lock localplayer:get_current_weapon():set_lock_on_range(Lock)
end)
CSYONS28:add_action("Max All weaponstats", function() mxwep() end)
WepTw=nil
CSYONS28:add_action("____________________________________", function() end)

CSYONS24:add_action("Share Cash from Last Job", function() 
			stats.set_int(2793046, 283) 
			stats.set_int(2793046, 284) -- Share Cash from Last Job (Total Earned)
end)

CSYONS25:add_action("Unlock Rare Outfits", function() 
			stats.set_int(262145, 16784) 
			stats.set_int(262145, 16785)
			stats.set_int(262145, 16786)
			stats.set_int(262145, 16787)
			stats.set_int(262145, 16788)
			stats.set_int(262145, 16789)
			stats.set_int(262145, 16790)
			stats.set_int(262145, 23407)
			stats.set_int(262145, 23408)
			stats.set_int(262145, 23409)
			stats.set_int(262145, 23410)
			stats.set_int(262145, 23411)
			stats.set_int(262145, 28690)
			stats.set_int(262145, 28691)
			stats.set_int(262145, 28692)
			stats.set_int(262145, 28693)
			stats.set_int(262145, 31208)
			stats.set_int(262145, 31191) 
			stats.set_int(262145, 31198)
			stats.set_int(262145, 31199)
			stats.set_int(262145, 32938)
			stats.set_int(262145, 34043)
			stats.set_int(262145, 34044)
			stats.set_int(262145, 34045)
			stats.set_int(262145, 33794)
end)

CSYONS25:add_action("Unlock Junk Energy Drink Chute Bag", function() 
			stats.set_boolean(34378, true) 
end)

CSYONS25:add_action("Unlock Rare Masks", function() 
			stats.set_boolean(27087, true) 
			stats.set_boolean(34372, true) 
			stats.set_boolean(27088, true)  
end)

CSYONS24:add_action(" Drop Car ", function() CarDrop() end)

CSYONS28:add_action(" Full Ammo ", function() menu.max_all_ammo() end)
local function reloadSpeed()
	if localplayer == number then
		return
	end
	current_weapon = localplayer:get_current_weapon()
		if current_weapon ~= number then
			current_weapon:set_time_between_shots(0.05)
		end
end
CSYONS28:add_action(" Reload ( stun Gun ) Speed ", reloadSpeed)

CSYONS28:add_action("Extreme Bullets", function() EXPLO() end)
function EXPLO()
    if localplayer ~= nil then
     localplayer:get_current_weapon():set_bullet_damage(1000000)
     localplayer:get_current_weapon():set_vehicle_force(1000000)
end end

CSYONS28:add_action(" Force Gun ", function() force_gun() end)
CSYONS28:add_action(" Boom Gun ", function() boom_gun() end)
CSYONS28:add_action(" Nuke Gun ", function() nuke_gun() end)

 CSYONS29:add_action(" Remove Cops ", function() menu.clear_wanted_level() end)

 CSYONS29:add_action(" Set 1* ", function() localplayer:set_wanted_level(1) end)
 CSYONS29:add_action(" Set 2** ", function() localplayer:set_wanted_level(2) end)
 CSYONS29:add_action(" Set 3*** ", function() localplayer:set_wanted_level(3) end)
 CSYONS29:add_action(" Set 4**** ", function() localplayer:set_wanted_level(4) end)
 CSYONS29:add_action(" Set 5***** ", function() localplayer:set_wanted_level(5) end)
 CSYONS29:add_action(" Set 6****** ", function() localplayer:set_wanted_level(6) end)

CSYONS24:add_action("name your Acids", function() 
globals.set_int(262145, 22054)
globals.set_int(262145, 22053)
end)

CSYONS24:add_action(" Kill Current Vehicle", function() menu.kill_current_vehicle() end)
CSYONS24:add_action(" Kill All Vehicles", function() menu.kill_all_vehicles() end)
CSYONS28:add_action(" Full All Ammo ", function() menu.max_all_ammo() end)
CSYONS24:add_toggle(" Big Map", function() return BigMap end, function() BigMap = not BigMap menu.set_big_map(BigMap) end)
CSYONS24:add_toggle(" Open Radio", function() return MobileRadio end, function() MobileRadio = not MobileRadio menu.set_mobile_radio(MobileRadio) end)
 
CSYONS29:add_action("Max Stats", function() 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_DRIV", 100) 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_FLY", 100) 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_LUNG", 100) 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_SHO", 100) 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_STAM", 100) 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_STL", 100) 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_STRN", 100) end)
		
	CSYONS29:add_int_range("Stamina", 2, 0, 100, function() return stats.get_int(MPX() .. "STAMINA") end, function(Stam) stats.set_int(MPX() .. "SCRIPT_INCREASE_STAM", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_STAM", Stam - stats.get_int(MPX() .. "STAMINA")) end)
	CSYONS29:add_int_range("Shooting", 2, 0, 100, function() return stats.get_int(MPX() .. "SHOOTING_ABILITY") end, function(Sho) stats.set_int(MPX() .. "SCRIPT_INCREASE_SHO", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_SHO", Sho - stats.get_int(MPX() .. "SHOOTING_ABILITY")) end)
	CSYONS29:add_int_range("Strength", 2, 0, 100, function() return stats.get_int(MPX() .. "STRENGTH") end, function(Strn) stats.set_int(MPX() .. "SCRIPT_INCREASE_STRN", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_STRN", Strn - stats.get_int(MPX() .. "STRENGTH")) end)
	CSYONS29:add_int_range("Stealth", 2, 0, 100, function() return stats.get_int(MPX() .. "STEALTH_ABILITY") end, function(Stl) stats.set_int(MPX() .. "SCRIPT_INCREASE_STL", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_STL", Stl - stats.get_int(MPX() .. "STEALTH_ABILITY")) end)
	CSYONS29:add_int_range("Flying", 2, 0, 100, function() return stats.get_int(MPX() .. "FLYING_ABILITY") end, function(Fly) stats.set_int(MPX() .. "SCRIPT_INCREASE_FLY", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_FLY", Fly - stats.get_int(MPX() .. "FLYING_ABILITY")) end)
	CSYONS29:add_int_range("Driving", 2, 0, 100, function() return stats.get_int(MPX() .. "WHEELIE_ABILITY") end, function(Driv) stats.set_int(MPX() .. "SCRIPT_INCREASE_DRIV", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_DRIV", Driv - stats.get_int(MPX() .. "WHEELIE_ABILITY")) end)
	CSYONS29:add_int_range("Swimming", 2, 0, 100, function() return stats.get_int(MPX() .. "LUNG_CAPACITY") end, function(Lung) stats.set_int(MPX() .. "SCRIPT_INCREASE_LUNG", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_LUNG", stats.get_int(MPX() .. "LUNG_CAPACITY")) end)
	CSYONS29:add_float_range("Psychics", 2, 0, 100, function() return stats.get_float(MPX() .. "PLAYER_MENTAL_STATE") end, function(Ment) stats.set_float(MPX() .. "PLAYER_MENTAL_STATE", Ment) end)

CSYONS28:add_action("WEAPON_LOADOUT_1", function()
	MPX = stats.get_int("mpply_last_mp_char")
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 2) -- Index: 7387 // Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 3) -- Index: 7388 // Combat Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 4) -- Index: 7389 // AP Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 5) -- Index: 7390 // SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 6) -- Index: 7391 // Assault Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 7) -- Index: 7392 // Carbine Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 8) -- Index: 7393 // Advanced Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 9) -- Index: 7394 // MG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 10) -- Index: 7395 // Combat MG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 11) -- Index: 7396 // Pump Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 12) -- Index: 7397 // Sawed-Off Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 13) -- Index: 7398 // Assault Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 14) -- Index: 7399 // Sniper Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 15) -- Index: 7400 // Grenade Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 16) -- Index: 7401 // RPG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 17) -- Index: 7402 // Minigun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 18) -- Index: 7403 // Grenade
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 19) -- Index: 7404 // Tear Gas
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 20) -- Index: 7405 // Sticky Bomb
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 21) -- Index: 7406 // Molotov
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 23) -- Index: 7408 // Knife
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 24) -- Index: 7409 // Nightstick
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 25) -- Index: 7410 // Hammer
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 26) -- Index: 7411 // Pistol .50
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 27) -- Index: 7412 // Assault SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 28) -- Index: 7413 // Heavy Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 29) -- Index: 7414 // Bullpup Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 32) -- Index: 7417 // Special Carbine
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 33) -- Index: 7418 // Bottle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 34) -- Index: 7419 // Bullpup Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 35) -- Index: 7420 // Heavy Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 36) -- Index: 7421 // SNS Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 37) -- Index: 7422 // Antique Cavalry Dagger
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 38) -- Index: 7423 // Vintage Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 39) -- Index: 7424 // Gusenberg Sweeper
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 40) -- Index: 7425 // Flare Gun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 41) -- Index: 7426 // Firework Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 42) -- Index: 7427 // Musket
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 44) -- Index: 7429 // Heavy Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 45) -- Index: 7430 // Marksman Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 46) -- Index: 7431 // Homing Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 47) -- Index: 7432 // Proximity Mine
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 49) -- Index: 7434 // Combat PDW
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 50) -- Index: 7435 // Knuckle Duster
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 51) -- Index: 7436 // Marksman Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 52) -- Index: 7437 // Hatchet
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 53) -- Index: 7438 // Compact Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 54) -- Index: 7439 // Double Barrel Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 55) -- Index: 7440 // Machete
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 56) -- Index: 7441 // Machine Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 57) -- Index: 7442 // Flashlight
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 58) -- Index: 7443 // Heavy Revolver
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 59) -- Index: 7444 // Switchblade
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 60) -- Index: 7445 // Micro SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 61) -- Index: 7446 // Heavy Sniper
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 62) -- Index: 7447 // Jerry Can
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 63) -- Index: 7448 // Golf Club
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", true, 0) -- Index: 7449 // Baseball Bat
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 1) -- Index: 7450 // All Melee Weapons 
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 2) -- Index: 7451 // All Pistols
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 3) -- Index: 7452 // All Machine Guns
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 4) -- Index: 7453 // All Rifles
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 5) -- Index: 7454 // All Shotguns
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 6) -- Index: 7455 // All Snipers
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 7) -- Index: 7456 // All Heavy Weapons
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 8) -- Index: 7457 // All Explosives
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 17) -- Index: 7466 // Crowbar
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", false, 44) -- Index: 7621 // Sweeper Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 45) -- Index: 7622 // Battle Axe
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", false, 46) -- Index: 7623 // Compact Grenade Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 47) -- Index: 7624 // Mini SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 48) -- Index: 7625 // Pipe Bomb
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 49) -- Index: 7626 // Pool Cue
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 50) -- Index: 7627 // Pipe Wrench
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL2", true, 51) -- Index: 15548 // Stone Hatchet
	stats.set_bool_masked("MP"..MPX().."_DLCSMUGCHARPSTAT_BOOL0", true, 49) -- Index: 15995 // Double-Action Revolver
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL4", false, 23) -- Index: 25241 // Up-n-Atomizer
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL4", true, 24) -- Index: 25242 // Unholy Hellbringer
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL4", true, 25) -- Index: 25243 // Widowmaker
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL8", true, 44) -- Index: 25518 // Ceramic Pistol
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL8", true, 45) -- Index: 25519 // Navy Revolver
	stats.set_bool_masked("MP"..MPX().."_CASINOHSTPSTAT_BOOL2", false, 33) -- Index: 28259 // Compact EMP Launcher
	stats.set_bool_masked("MP"..MPX().."_CASINOHSTPSTAT_BOOL2", true, 35) -- Index: 28261 // Stun Gun
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 8) -- Index: 15441 // Pistol Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 9) -- Index: 15442 // SMG Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", false, 10) -- Index: 15443 // Heavy Sniper Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 11) -- Index: 15444 // Combat MG Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 12) -- Index: 15445 // Assault Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 13) -- Index: 15446 // Carbine Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 2) -- Index: 18100 // Bullpup Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", false, 3) -- Index: 18101 // Marksman Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 4) -- Index: 18102 // Pump Shotgun Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 5) -- Index: 18103 // Heavy Revolver Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 6) -- Index: 18104 // SNS Pistol Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 7) -- Index: 18105 // Special Carbine Mk II
	stats.set_bool_masked("MP"..MPX().."_SU20PSTAT_BOOL1", true, 30) -- Index: 30321 // Military Rifle
	stats.set_bool_masked("MP"..MPX().."_SU20PSTAT_BOOL1", true, 31) -- Index: 30322 // Perico Pistol
	stats.set_bool_masked("MP"..MPX().."_SU20PSTAT_BOOL1", true, 32) -- Index: 30323 // Combat Shotgun
	stats.set_bool_masked("MP"..MPX().."_DLC12022PSTAT_BOOL1", true, 61) -- Index: 34376 // Service Carbine
	stats.set_bool_masked("MP"..MPX().."_DLC12022PSTAT_BOOL1", true, 62) -- Index: 34377 // Precision Rifle
	stats.set_bool_masked("MP"..MPX().."_DLC22022PSTAT_BOOL0", true, 43) -- Index: 36670 // WM 29 Pistol
	stats.set_bool_masked("MP"..MPX().."_DLC22022PSTAT_BOOL0", true, 44) -- Index: 36671 // Candy Cane
	stats.set_bool_masked("MP"..MPX().."_DLC22022PSTAT_BOOL0", false, 45) -- Index: 36672 // Railgun
end)
 
CSYONS28:add_action("WEAPON_LOADOUT_2", function()
	MPX = stats.get_int("mpply_last_mp_char")
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 2) -- Index: 7387 // Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 3) -- Index: 7388 // Combat Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 4) -- Index: 7389 // AP Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 5) -- Index: 7390 // SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 6) -- Index: 7391 // Assault Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 7) -- Index: 7392 // Carbine Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 8) -- Index: 7393 // Advanced Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 9) -- Index: 7394 // MG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 10) -- Index: 7395 // Combat MG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 11) -- Index: 7396 // Pump Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 12) -- Index: 7397 // Sawed-Off Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 13) -- Index: 7398 // Assault Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 14) -- Index: 7399 // Sniper Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 15) -- Index: 7400 // Grenade Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 16) -- Index: 7401 // RPG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 17) -- Index: 7402 // Minigun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 18) -- Index: 7403 // Grenade
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 19) -- Index: 7404 // Tear Gas
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 20) -- Index: 7405 // Sticky Bomb
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 21) -- Index: 7406 // Molotov
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 23) -- Index: 7408 // Knife
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 24) -- Index: 7409 // Nightstick
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 25) -- Index: 7410 // Hammer
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 26) -- Index: 7411 // Pistol .50
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 27) -- Index: 7412 // Assault SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 28) -- Index: 7413 // Heavy Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 29) -- Index: 7414 // Bullpup Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 32) -- Index: 7417 // Special Carbine
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 33) -- Index: 7418 // Bottle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 34) -- Index: 7419 // Bullpup Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 35) -- Index: 7420 // Heavy Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 36) -- Index: 7421 // SNS Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 37) -- Index: 7422 // Antique Cavalry Dagger
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 38) -- Index: 7423 // Vintage Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 39) -- Index: 7424 // Gusenberg Sweeper
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 40) -- Index: 7425 // Flare Gun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 41) -- Index: 7426 // Firework Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 42) -- Index: 7427 // Musket
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 44) -- Index: 7429 // Heavy Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 45) -- Index: 7430 // Marksman Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 46) -- Index: 7431 // Homing Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 47) -- Index: 7432 // Proximity Mine
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 49) -- Index: 7434 // Combat PDW
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 50) -- Index: 7435 // Knuckle Duster
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 51) -- Index: 7436 // Marksman Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 52) -- Index: 7437 // Hatchet
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 53) -- Index: 7438 // Compact Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 54) -- Index: 7439 // Double Barrel Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 55) -- Index: 7440 // Machete
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 56) -- Index: 7441 // Machine Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 57) -- Index: 7442 // Flashlight
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 58) -- Index: 7443 // Heavy Revolver
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 59) -- Index: 7444 // Switchblade
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 60) -- Index: 7445 // Micro SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 61) -- Index: 7446 // Heavy Sniper
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 62) -- Index: 7447 // Jerry Can
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 63) -- Index: 7448 // Golf Club
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", true, 0) -- Index: 7449 // Baseball Bat
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 1) -- Index: 7450 // All Melee Weapons 
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 2) -- Index: 7451 // All Pistols
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 3) -- Index: 7452 // All Machine Guns
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 4) -- Index: 7453 // All Rifles
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 5) -- Index: 7454 // All Shotguns
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 6) -- Index: 7455 // All Snipers
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 7) -- Index: 7456 // All Heavy Weapons
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 8) -- Index: 7457 // All Explosives
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", true, 17) -- Index: 7466 // Crowbar
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", false, 44) -- Index: 7621 // Sweeper Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 45) -- Index: 7622 // Battle Axe
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 46) -- Index: 7623 // Compact Grenade Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 47) -- Index: 7624 // Mini SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 48) -- Index: 7625 // Pipe Bomb
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 49) -- Index: 7626 // Pool Cue
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 50) -- Index: 7627 // Pipe Wrench
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL2", true, 51) -- Index: 15548 // Stone Hatchet
	stats.set_bool_masked("MP"..MPX().."_DLCSMUGCHARPSTAT_BOOL0", true, 49) -- Index: 15995 // Double-Action Revolver
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL4", true, 23) -- Index: 25241 // Up-n-Atomizer
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL4", true, 24) -- Index: 25242 // Unholy Hellbringer
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL4", true, 25) -- Index: 25243 // Widowmaker
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL8", true, 44) -- Index: 25518 // Ceramic Pistol
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL8", true, 45) -- Index: 25519 // Navy Revolver
	stats.set_bool_masked("MP"..MPX().."_CASINOHSTPSTAT_BOOL2", true, 33) -- Index: 28259 // Compact EMP Launcher
	stats.set_bool_masked("MP"..MPX().."_CASINOHSTPSTAT_BOOL2", true, 35) -- Index: 28261 // Stun Gun
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 8) -- Index: 15441 // Pistol Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 9) -- Index: 15442 // SMG Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 10) -- Index: 15443 // Heavy Sniper Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 11) -- Index: 15444 // Combat MG Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 12) -- Index: 15445 // Assault Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 13) -- Index: 15446 // Carbine Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 2) -- Index: 18100 // Bullpup Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 3) -- Index: 18101 // Marksman Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 4) -- Index: 18102 // Pump Shotgun Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 5) -- Index: 18103 // Heavy Revolver Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 6) -- Index: 18104 // SNS Pistol Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 7) -- Index: 18105 // Special Carbine Mk II
	stats.set_bool_masked("MP"..MPX().."_SU20PSTAT_BOOL1", true, 30) -- Index: 30321 // Military Rifle
	stats.set_bool_masked("MP"..MPX().."_SU20PSTAT_BOOL1", true, 31) -- Index: 30322 // Perico Pistol
	stats.set_bool_masked("MP"..MPX().."_SU20PSTAT_BOOL1", true, 32) -- Index: 30323 // Combat Shotgun
	stats.set_bool_masked("MP"..MPX().."_DLC12022PSTAT_BOOL1", true, 61) -- Index: 34376 // Service Carbine
	stats.set_bool_masked("MP"..MPX().."_DLC12022PSTAT_BOOL1", true, 62) -- Index: 34377 // Precision Rifle
	stats.set_bool_masked("MP"..MPX().."_DLC22022PSTAT_BOOL0", true, 43) -- Index: 36670 // WM 29 Pistol
	stats.set_bool_masked("MP"..MPX().."_DLC22022PSTAT_BOOL0", true, 44) -- Index: 36671 // Candy Cane
	stats.set_bool_masked("MP"..MPX().."_DLC22022PSTAT_BOOL0", false, 45) -- Index: 36672 // Railgun
end)

CSYONS27:add_toggle("limp", function()
	if localplayer == nil then
		return nil
	end
	return localplayer:get_config_flag(166)
end, function(value)
	localplayer:set_config_flag(166, value)
end)
 
CSYONS27:add_toggle("limp with weapon", function()
	if localplayer == nil then
		return nil
	end
 
	return localplayer:get_config_flag(187)
end, function(value)
	localplayer:set_config_flag(187, value)
end)
 
CSYONS27:add_toggle("disable engine auto stop", function()
	if localplayer == nil then
		return nil
	end
 
	return localplayer:get_config_flag(241)
end, function(value)
	localplayer:set_config_flag(241, value)
end)
 
CSYONS27:add_toggle("freeze player", function()
	if localplayer == nil then
		return nil
	end
 
	return localplayer:get_config_flag(292)
end, function(value)
	localplayer:set_config_flag(292, value)
end)
 
CSYONS27:add_toggle("attack friendlies", function()
	if localplayer == nil then
		return nil
	end
 
	return localplayer:get_config_flag(140)
end, function(value)
	localplayer:set_config_flag(140, value)
end)

CSYONS24:add_toggle("Freeze Momentum", function()	
	if localplayer == nil then
		return nil
	end
 
	return localplayer:get_freeze_momentum()
end, function(value)
	localplayer:set_freeze_momentum(value)
end)
 
CSYONS24:add_toggle("Passive/Pussymode", function()	
	if localplayer == nil then
		return nil
	end
 
	return menu.get_passive()
end, function(value)
	menu.set_passive(value)
end)
 
 
CSYONS24:add_toggle("No Ragdoll lool", function()	
	if localplayer == nil then
		return nil
	end
 
	return localplayer:get_no_ragdoll()
end, function(value)
	localplayer:set_no_ragdoll(value)
end)

--Protect him
CSYONS26:add_toggle("Activate All", function()
	return boolall
end, function()
	boolall = not boolall
	All(boolall)
end)
--Text("<Protections>")
CSYONS26:add_toggle("Block Start Activity", function() --Credits to YimMenu
	return globals.get_bool(1669794)
end, function()
	Activity(not globals.get_bool(1669794))
end)

CSYONS26:add_toggle("Block Bounty", function()
	return globals.get_bool(1669276)
end, function()
	Bounty(not globals.get_bool(1669276))
end)
 
 
CSYONS26:add_toggle("Block Socialclub Spam", function()
	return getBlockSocialClubSpamState()
end, function(value)
	BlockSocialclubSpam(value)
end)
 
CSYONS26:add_toggle("Block Remote Global Modification", function()
	return getRemoteGlobalModificationState()
end, function()
	RemoteGlobalModification(not getRemoteGlobalModificationState())
end)
 
CSYONS26:add_toggle("Block Some Kicks&&Crashes", function()
	return getKickCrashesState()
end, function()
	KickCrashes(not getKickCrashesState())
end)
 
CSYONS26:add_toggle("Block Ceo Kick", function()
	return globals.get_bool(1669766)
end, function()
	CeoKick(not globals.get_bool(1669766))
end)
 
CSYONS26:add_toggle("Block Ceo Ban", function()
	return globals.get_bool(1669788) 
end, function()
	CeoBan(not globals.get_bool(1669788))
end)
 
CSYONS26:add_toggle("Block Sound Spam", function()
	return getSoundSpamState()
end, function()
	SoundSpam(not getSoundSpamState())
end)
 
CSYONS26:add_toggle("Block Infinite Loadingscreen", function()
	return getInfiniteLoadState()
end, function()
	InfiniteLoad(not getInfiniteLoadState())
end)
 
CSYONS26:add_toggle("Block Passive Mode", function()
	return globals.get_bool(1669778) 
end, function()
	PassiveMode(not globals.get_bool(1669778))
end)
 
CSYONS26:add_toggle("Block Transaction Error", function()
	return globals.get_bool(4537356)
end, function()
	TransactionError(not globals.get_bool(4537358))
end)
 
CSYONS26:add_toggle("Block Modded Notifys/SMS", function()
	return getRemoveMoneyMessageState()
end, function()
	RemoveMoneyMessage(not getRemoveMoneyMessageState())
end)
 
CSYONS26:add_toggle("Block Clear Wanted", function()
	return globals.get_bool(1669720)
end, function()
	ClearWanted(not globals.get_bool(1669720))
end)
 
CSYONS26:add_toggle("Block Off The Radar", function()
	return globals.get_bool(1669722)
end, function()
	OffTheRadar(not globals.get_bool(1669722))
end)
 
CSYONS26:add_toggle("Block Personal Vehicle Destroy", function()
	return getPersonalVehicleDestroyState()
end, function()
	PersonalVehicleDestroy(not getPersonalVehicleDestroyState())
end)
 
CSYONS26:add_toggle("Block Send to Cutscene", function()
	return globals.get_bool(1669988)
end, function()
	SendCutscene(not globals.get_bool(1669988))
end)
 
CSYONS26:add_toggle("Block Remove Godmode", function()
	return globals.get_bool(1669213)
end, function()
	Godmode(not globals.get_bool(1669213))
end)
 
CSYONS26:add_toggle("Block Give Collectibles", function()
	return globals.get_bool(1669998)
end, function()
	Collectibles(not globals.get_bool(1669998))
end)
 
CSYONS26:add_toggle("Block Cayo && Beach Teleport", function()
	return getExtraTeleportState()
end, function()
	ExtraTeleport(not getExtraTeleportState())
end)
 
function OnScriptsLoaded()
	local social_controller = script("social_controller")
	while true do
		if blockSocialClubSpamState then
			if social_controller:is_active() then
				social_controller:set_int(169, 0)
			end
		end
		sleep(1)
	end
end
 
menu.register_callback('OnScriptsLoaded', OnScriptsLoaded)
--Protections

CSYONS26:add_action("Remove Transaction Error", function()
	globals.set_int(4537212 + 2147483646, 2147483647)
end)

	--menu.register_hotkey(35, function()	--END key
	--if localplayer:is_in_vehicle() then
		--current_vehicle = localplayer:get_current_vehicle()
		 --current_vehicle:set_health(current_vehicle:get_max_health())
		 --menu.repair_online_vehicle()
		--current_vehicle:set_dirt_level(0.0)
	--end
--end)

CSYONS22:add_toggle("Start Ceo Banager",
  function()
    return boolCeoBanager
  end,
  function()
    boolCeoBanager = not boolCeoBanager;
    funcCeoBanger(boolCeoBanager)
  end)

			NoRP = false
	CSYONS22:add_toggle("Disable RP Earning", function() return NoRP end, function() NoRP = not NoRP end)
            if NoRP == true then globals.set_float(262146, 1)
		else globals.set_float(262146, 0) end

CSYONS22:add_action("1-10 per Press", function() for i = 12, 16 do stats.set_bool_masked(MPX() .. "FIXERPSTAT_BOOL1", true, i, MPX()) end end)
	
			GCv0 = false
		local function GCv1()
		while GCv0 == true do for i = 12, 16 do stats.set_bool_masked(MPX() .. "FIXERPSTAT_BOOL1", true, i, MPX()) end end end
CSYONS22:add_toggle("Crates Loop", function() return GCv0 end, function() GCv0 = not GCv0 GCv1(GCv0) end)
	
			GCv2 = 1
CSYONS22:add_int_range("Instant Buy", 1, 1, 111, function() return GCv2 end, 
		function(CV) if GCB:is_active() then
					    GCB:set_int(598 + 5, 1)
					    GCB:set_int(598 + 1, CV)
					    GCB:set_int(598 + 191, 6)
					    GCB:set_int(598 + 192, 4)
					    GCv2 = CV end end)

local WH = script("am_mp_warehouse")
local function Cloop(bool)
	while bool do
		if WH:is_active() then
			menu.send_key_up(83)
			menu.send_key_press(69)
			sleep(1)
			if not WH:is_active() then
				menu.send_key_press(13)
				menu.send_key_down(83)
			end
		end
	end
end

CSYONS22:add_toggle("Automatic Sell Crate AFK Female & Male", function()
	return boolcl
end, function()
	boolcl = not boolcl
	Cloop(boolcl)
end)

CSYONS22r=CSYON22:add_submenu("Special Cargo Money methode") 
	 
	CSYONS22r:add_int_range("Price per Crate", 4995000, 10000, 9990000, function() 
    	return globals.get_int(262145 + 15991)
    end, function(value)
    	globals.set_int(262145 + 15991, value)
    end)
	
	CSYONS22r:add_int_range("Price per Crate 2)", 4995000, 10000, 6660000, function() 
    	return globals.get_int(262145 + 15992)
    end, function(value)
    	globals.set_int(262145 + 15992, value)
    end)
     
    CSYONS22r:add_int_range("Price per 3 Crate", 4995000, 11000, 4995000, function() 
    	return globals.get_int(262145 + 15993)
    end, function(value)
    	globals.set_int(262145 + 15993, value)
    end)
     
    CSYONS22r:add_int_range("Price per 4-5 Crate", 3330000, 12000, 3330000, function() 
    	return globals.get_int(262145 + 15994)
    end, function(value)
    	globals.set_int(262145 + 15994, value)
    end)
	
	CSYONS22r:add_int_range("Price per 111 Crate", 90000, 20000, 90000, function() 
    	return globals.get_int(262145 + 16011)
    end, function(value)
    	globals.set_int(262145 + 16011, value)
    end)
     
    CSYONS22r:add_int_range("Special Cargo CD Buy", 300000, 0, 300000, function() 
    	return globals.get_int(262145 + 15553)
    end, function(value)
    	globals.set_int(262145 + 15553, value)
    end)
     
    CSYONS22r:add_int_range("Special Cargo CD Sell", 1800000, 0, 1800000, function() 
    	return globals.get_int(262145 + 15554)
    end, function(value)
    	globals.set_int(262145 + 15554, value)
    end)
 
CSYONS22r:add_action("Insta Finish Sell Mission", function()
	sale_mission = script("gb_contraband_sell")
	if sale_mission:is_active()
		then
			base_address = 543
			sale_mission:set_int(base_address+1,99999)
		end
end)

CSYONS22r:add_action("Insta Finish Buy/Steal Mission", function()
	buy_mission = script("gb_contraband_buy")
	if buy_mission:is_active()
		then
			base_address = 601
			buy_mission:set_int(base_address+5, 1)
			buy_mission:set_int(base_address+191, 6)
			buy_mission:set_int(base_address+192, 4)
		end
end)

CSYONS22r:add_action("No Sell Cooldown", function()
    globals.set_int(262145+15757, 1800000) 
end)

CSYONS22r:add_action("No Buy Cooldown", function()
    globals.set_int(262145+15756, 0) 
end)
	
	CSYONS22r:add_action("Set Price(200K) for one crate", function()
    sale_price = 200000
    base_address = 15991
    globals.set_int(262145+base_address, sale_price//1)
end)
CSYONS22r:add_action("Set Price(500K) for two crate", function()
    sale_price = 500000
    base_address = 15991
    globals.set_int(262145+base_address+1, sale_price//2)
end)
CSYONS22r:add_action("Set Price(700K) for three crate", function()
    sale_price = 700000
    base_address = 15991
    globals.set_int(262145+base_address+2, sale_price//3)
end)
CSYONS22r:add_action("Set Price(1M) for five crate", function()
    sale_price = 1000000
    base_address = 15991
    globals.set_int(262145+base_address+3, sale_price//5)
end)
CSYONS22r:add_action("Set Price(1.5M) for nine crate", function()
    sale_price = 1500000
    base_address = 15991
    globals.set_int(262145+base_address+5, sale_price//9)
end)
 
CSYONS22r:add_action("Set Price for each (one crate 250k)", function()
    sale_price = 250000
    base_address = 15991
    globals.set_int(262145+base_address, (sale_price*1)//1)
    globals.set_int(262145+base_address+1, (sale_price*2)//2)
    globals.set_int(262145+base_address+2, (sale_price*3)//3)
    globals.set_int(262145+base_address+3, (sale_price*4)//5)
    globals.set_int(262145+base_address+4, (sale_price*5)//7)
    globals.set_int(262145+base_address+5, (sale_price*6)//9)
    globals.set_int(262145+base_address+6, (sale_price*7)//14)
    globals.set_int(262145+base_address+7, (sale_price*8)//19)
    globals.set_int(262145+base_address+8, (sale_price*9)//24)
    globals.set_int(262145+base_address+9, (sale_price*10)//29)
    globals.set_int(262145+base_address+10, (sale_price*10)//34)
    globals.set_int(262145+base_address+11, (sale_price*10)//39)
    globals.set_int(262145+base_address+12, (sale_price*10)//44)
    globals.set_int(262145+base_address+13, (sale_price*10)//49)
    globals.set_int(262145+base_address+14, (sale_price*10)//59)
    globals.set_int(262145+base_address+15, (sale_price*10)//69)
    globals.set_int(262145+base_address+16, (sale_price*10)//79)
    globals.set_int(262145+base_address+17, (sale_price*10)//89)
    globals.set_int(262145+base_address+18, (sale_price*10)//99)
    globals.set_int(262145+base_address+19, (sale_price*10)//110)
    globals.set_int(262145+base_address+20, (sale_price*10)//111)
end)
 
CSYONS22r:add_action("Set Price(2M)", function()
    sale_price = 2000000
    base_address = 15991
    globals.set_int(262145+base_address, sale_price//1)
    globals.set_int(262145+base_address+1, sale_price//2)
    globals.set_int(262145+base_address+2, sale_price//3)
    globals.set_int(262145+base_address+3, sale_price//5)
    globals.set_int(262145+base_address+4, sale_price//7)
    globals.set_int(262145+base_address+5, sale_price//9)
    globals.set_int(262145+base_address+6, sale_price//14)
    globals.set_int(262145+base_address+7, sale_price//19)
    globals.set_int(262145+base_address+8, sale_price//24)
    globals.set_int(262145+base_address+9, sale_price//29)
    globals.set_int(262145+base_address+10, sale_price//34)
    globals.set_int(262145+base_address+11, sale_price//39)
    globals.set_int(262145+base_address+12, sale_price//44)
    globals.set_int(262145+base_address+13, sale_price//49)
    globals.set_int(262145+base_address+14, sale_price//59)
    globals.set_int(262145+base_address+15, sale_price//69)
    globals.set_int(262145+base_address+16, sale_price//79)
    globals.set_int(262145+base_address+17, sale_price//89)
    globals.set_int(262145+base_address+18, sale_price//99)
    globals.set_int(262145+base_address+19, sale_price//110)
    globals.set_int(262145+base_address+20, sale_price//111)
end)
	
	CSYONS22r:add_action("Set Price(5M)", function()
    sale_price = 5000000
	base_address = 15991
    globals.set_int(262145+base_address, sale_price//1)
    globals.set_int(262145+base_address+1, sale_price//2)
    globals.set_int(262145+base_address+2, sale_price//3)
    globals.set_int(262145+base_address+3, sale_price//5)
    globals.set_int(262145+base_address+4, sale_price//7)
    globals.set_int(262145+base_address+5, sale_price//9)
    globals.set_int(262145+base_address+6, sale_price//14)
    globals.set_int(262145+base_address+7, sale_price//19)
    globals.set_int(262145+base_address+8, sale_price//24)
    globals.set_int(262145+base_address+9, sale_price//29)
    globals.set_int(262145+base_address+10, sale_price//34)
    globals.set_int(262145+base_address+11, sale_price//39)
    globals.set_int(262145+base_address+12, sale_price//44)
    globals.set_int(262145+base_address+13, sale_price//49)
    globals.set_int(262145+base_address+14, sale_price//59)
    globals.set_int(262145+base_address+15, sale_price//69)
    globals.set_int(262145+base_address+16, sale_price//79)
    globals.set_int(262145+base_address+17, sale_price//89)
    globals.set_int(262145+base_address+18, sale_price//99)
    globals.set_int(262145+base_address+19, sale_price//110)
    globals.set_int(262145+base_address+20, sale_price//111)
end)
	
	    local speccargo_script = script("gb_contraband_sell")
 
	CSYONS22r:add_toggle("Special Cargo Instant Sell", function() 
    	return speccargo_script:get_int(543) 
    end, function()
    if speccargo_script and speccargo_script:is_active() then
    	speccargo_script:set_int(543 + 1, 99999)
    end
    end)
	
	local function Text(text)
    	CSYONS22r:add_action(text, function() end)
    end
	
	Text("Instant Sell Mission Selector:") 
	CSYONS22r:add_int_range("0 to 6 Truck|7 to 11 Plane|12 = Boat", 1, 0, 12, function()
    	return speccargo_script:get_int(547) 
    end, function(value)
    if speccargo_script and speccargo_script:is_active() then
    	speccargo_script:set_int(547, value)
    end
    end)
	
	local speccargo_script = script("gb_contraband_buy")
	
	CSYONS22r:add_toggle("Special Cargo Instant Buy", function() 
    	return speccargo_script:get_int(601) 
    end, function()
    if speccargo_script and speccargo_script:is_active() then
    	speccargo_script:set_int(192, 4)
    end
    end)
	
	CSYONS22r:add_int_range("Special Cargo Crate Count", 1, 1, 111, function() 
    	return speccargo_script:get_int(599) 
    end, function(value)
    if speccargo_script and speccargo_script:is_active() then
    	speccargo_script:set_int(599, value)
    end
    end)
	
	local function Text(text)
    	CSYONS22r:add_action(text, function() end)
    end
 
    CSYONS22r:add_toggle("Unique Cargo Toggle", function()	
    	return globals.get_boolean(1949968) 
    end, function(value)
    	globals.set_boolean(1949968, value)
    end)
	
	local cargotype, ctype=2, {} ctype[2]="Ornamental Egg($25000)" ctype[4]="Golden Minigun($23000)" ctype[6]="Large Diamond($27000)" 
	ctype[7]="Rare Hide($21000)" ctype[8]="Film Reel($19000)" ctype[9]="Rare Pocket Watch($30000)"
	
	CSYONS22r:add_array_item("U.Cargo Type:", ctype, function()
		return cargotype
	end, function(CT)
		globals.get_int(1942640)
		cargotype=CT		
	if CT==2 then 
		globals.set_int(1942640, 2)
	elseif CT==4 then
		globals.set_int(1942640, 4)
	elseif CT==6 then
		globals.set_int(1942640, 6)
	elseif CT==7 then
		globals.set_int(1942640, 7)
	elseif CT==8 then
		globals.set_int(1942640, 8)
	elseif CT==9 then
		globals.set_int(1942640, 9)
		end
		cargotype = value
	end)
	cargotype = 1
 
--local PSTAT_BOOL0 = false
--CSYONS25:add_action("PSTAT_BOOL0", function()
--	return PSTAT_BOOL0
--end, function(bool)
--	PSTAT_BOOL0 = bool
--	for i = 0, 63 do -- the stat max index 
--		stats.set_bool_masked(MPX().."PSTAT_BOOL0", bool, i)
--	end
--end)

CSYONS25s = CSYON25:add_submenu("Packed Bools Unlocks")
CSYONS25s:add_action("packed bools 1.68", function()
for i = 0,63 do
	stats.set_bool_masked(MPX() .. "DLC22023PSTAT_BOOL2", true, i)
end
end)
CSYONS25s:add_action("ARENAWARSPSTAT_BOOL", function()	for j = 0, 63 do for i = 0, 8 do stats.set_bool_masked(MPX().."ARENAWARSPSTAT_BOOL"..i, true, j) end end end)
CSYONS25s:add_action("BUSINESSBATPSTAT_BOOL", function() for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."BUSINESSBATPSTAT_BOOL"..b, true, j) end end end)
CSYONS25s:add_action("CASINOHSTPSTAT_BOOL", function()	for j = 0, 63 do for f = 0, 4 do stats.set_bool_masked(MPX().."CASINOHSTPSTAT_BOOL"..f, true, j) end end end)
CSYONS25s:add_action("CASINOPSTAT_BOOL", function() for j = 0, 63 do for h = 0, 6 do stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL"..h, true, j) end end end)
CSYONS25s:add_action("DLCSMUGCHARPSTAT_BOOL", function() for j = 0, 63 do stats.set_bool_masked(MPX().."DLCSMUGCHARPSTAT_BOOL0", true, j) end end)
CSYONS25s:add_action("DLCGUNPSTAT_BOOL", function() for j = 0, 63 do for c = 0, 2 do stats.set_bool_masked(MPX().."DLCGUNPSTAT_BOOL"..c, true, j) end end end)
CSYONS25s:add_action("DLCBIKEPSTAT_BOOL", function() for j = 0, 63 do for c = 0, 2 do stats.set_bool_masked(MPX().."DLCBIKEPSTAT_BOOL"..c, true, j) end end end)
CSYONS25s:add_action("FIXERTATTOOSTAT_BOOL", function() for j = 0, 63 do stats.set_bool_masked(MPX().."FIXERTATTOOSTAT_BOOL0", true, j) end end)
CSYONS25s:add_action("FIXERPSTAT_BOOL", function()	for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."FIXERPSTAT_BOOL"..b, true, j) end end end)
CSYONS25s:add_action("GEN9PSTAT_BOOL", function()	for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."GEN9PSTAT_BOOL"..b, true, j) end end end)
CSYONS25s:add_action("GANGOPSPSTAT_BOOL", function() for j = 0, 63 do stats.set_bool_masked(MPX().."GANGOPSPSTAT_BOOL0", true, j) end end) 
CSYONS25s:add_action("GUNTATPSTAT_BOOL", function() for j = 0, 63 do for g = 0, 5 do stats.set_bool_masked(MPX().."GUNTATPSTAT_BOOL"..g, true, j) end end end)
CSYONS25s:add_action("HEIST3TATTOOSTAT_BOOL", function() for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."HEIST3TATTOOSTAT_BOOL"..b, true, j) end end end)
CSYONS25s:add_action("HISLANDPSTAT_BOOL", function() for j = 0, 63 do for c = 0, 2 do stats.set_bool_masked(MPX().."HISLANDPSTAT_BOOL"..c, true, j) end end end)
CSYONS25s:add_action("MP_NGDLCPSTAT_BOOL", function() for j = 0, 63 do stats.set_bool_masked(MPX().."MP_NGDLCPSTAT_BOOL0", true, j) end end)
CSYONS25s:add_action("MP_NGPSTAT_BOOL", function()	for j = 0, 63 do stats.set_bool_masked(MPX().."MP_NGPSTAT_BOOL0", true, j) end end)
CSYONS25s:add_action("MP_PSTAT_BOOL", function() for j = 0, 63 do for c = 0, 2 do stats.set_bool_masked(MPX().."MP_PSTAT_BOOL"..c, true, j) end end end)
CSYONS25s:add_action("MP_TUPSTAT_BOOL", function()	for j = 0, 63 do stats.set_bool_masked(MPX().."MP_TUPSTAT_BOOL0", true, j) end end)
CSYONS25s:add_action("NGDLCPSTAT_BOOL", function()	for j = 0, 63 do for e = 0, 3 do stats.set_bool_masked(MPX().."NGDLCPSTAT_BOOL"..e, true, j) end end end)
CSYONS25s:add_action("NGTATPSTAT_BOOL", function()	for j = 0, 63 do for g = 0, 5 do stats.set_bool_masked(MPX().."NGTATPSTAT_BOOL"..g, true, j) end end end) 
CSYONS25s:add_action("NGPSTAT_BOOL", function() for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."NGPSTAT_BOOL"..b, true, j) end end end)
CSYONS25s:add_action("PSTAT_BOOL", function() for j = 0, 63 do for d = 1, 2 do stats.set_bool_masked(MPX().."PSTAT_BOOL"..d, true, j) end end end) 
CSYONS25s:add_action("SU20TATTOOSTAT_BOOL", function()	for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."SU20TATTOOSTAT_BOOL"..b, true, j) end end end)
CSYONS25s:add_action("SU20PSTAT_BOOL", function() for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."SU20PSTAT_BOOL"..b, true, j) end end end)
CSYONS25s:add_action("TUNERPSTAT_BOOL", function()	for j = 0, 63 do for i = 0, 8 do stats.set_bool_masked(MPX().."TUNERPSTAT_BOOL"..i, true, j) end end end)
CSYONS25s:add_action("TUPSTAT_BOOL", function() for j = 0, 63 do for z = 0, 11 do stats.set_bool_masked(MPX().."TUPSTAT_BOOL"..z, true, j) end end end)
CSYONS25s:add_action("DLC12022PSTAT_BOOL", function() for j = 0, 63 do for z = 0, 7 do stats.set_bool_masked(MPX().."DLC12022PSTAT_BOOL"..z, true, j) end end end)
CSYONS25s:add_action("DLC22022PSTAT_BOOL", function() for j = 0, 63 do for z = 0, 4 do stats.set_bool_masked(MPX().."DLC22022PSTAT_BOOL"..z, true, j) end end end)
CSYONS25r = CSYON25:add_submenu("Packed Bools Unlocks Temporary")
local function RPB(e) if not localplayer then return end if e then globals.set_int(152523, 2) globals.set_int(103634, 90) globals.set_int(103634, 1) else globals.set_int(152523, 0) globals.set_int(103634, 0) end end CSYONS25r:add_toggle("Returning Player Bonus", function() return e31 end, function() e31 = not e31 RPB(e31) end)
CSYONS25r:add_toggle("DrugWars DLC Cloths", function() return globals.get_boolean(DWU1) end, function(value) for i = DWU1, DWU2 do globals.set_boolean(i, value) end end)
CSYONS25r:add_toggle("Dripfeed Vehicles Unlock", function() return globals.get_boolean(DR1) end, function(value) for i = DR1, DR2 do globals.set_boolean(i, value) end end)
CSYONS25r:add_toggle("M16 Unlock", function() return globals.get_boolean(MU1) end, function(value) globals.set_boolean(MU1, value) end)
CSYONS25r:add_toggle("Contract DLC Gunskins", function()	return globals.get_boolean(CG1) end, function(value) globals.set_boolean(CG1, value) globals.set_boolean(CG2, value) end)
CSYONS25r:add_toggle("ContractDLC Animal Masks", function() return globals.get_boolean(UA1) end, function(value) for i = UA1, UA2 do globals.set_boolean(i, value) end end)
CSYONS25r:add_toggle("ContractDLC DJ Cloths", function() return globals.get_boolean(CD1) end, function(value) globals.set_boolean(CD1, value) globals.set_boolean(CD2, value) globals.set_boolean(CD3, value) end)
local function AMCS(e) if not localplayer then return end if e then globals.set_int(AC1, -1) globals.set_int(AC2, -1) globals.set_int(AC3, -1) globals.set_int(AC4, -1)	else globals.set_int(AC1, 0) globals.set_int(AC2, 0) globals.set_int(AC3, 0) globals.set_int(AC4, 0) end end CSYONS25r:add_toggle("Ace Mask Casino Store", function() return e32 end, function() e32 = not e32 AMCS(e32) end)
local function PCS(e) if not localplayer then return end if e then for i = PC1, PC2 do globals.set_int(i, -1) end globals.set_int(PC3, -1) globals.set_int(PC4, -1) else for i = PC1, PC2 do globals.set_int(i, 0) end globals.set_int(PC3, 0) globals.set_int(PC4, 0) end end 
CSYONS25r:add_toggle("Paintings Casino Store", function() return e33 end, function() e33 = not e33 PCS(e33) end)
local function UnA(e) if not localplayer then return end if e then globals.set_int(103634, 90) else globals.set_int(103634, 0) end end CSYONS25r:add_toggle("Up-n-Atomizer", function() return e34 end, function() e34 = not e34 UnA(e34) end)
CSYONS25r:add_toggle("Festive tint", function() return globals.get_boolean(103634) end, function(value) globals.set_boolean(103634, value) end)
CSYONS25r:add_toggle("Valentine Unlocks", function() return globals.get_boolean(VU1) end, function(value) globals.set_boolean(VU1, value) globals.set_boolean(VU2, value) globals.set_boolean(VU3, value) globals.set_boolean(VU4, value) globals.set_boolean(VU5, value) globals.set_boolean(VU3, value) globals.set_boolean(VU6, value) globals.set_boolean(VU7, value) end)
local function J4A(e) if not localplayer then return end if e then globals.set_int(ID1, 1) for i = ID2, ID3 do globals.set_int(i, 1) end for j = ID4, ID5 do globals.set_int(j, 1) end else globals.set_int(ID1, 0) for i = ID2, 270419 do globals.set_int(i, 0) end for j = ID4, ID5 do globals.set_int(j, 0) end end end CSYONS25r:add_toggle("Independence Day Unlocks", function() return e38 end, function() e38 = not e38 J4A(e38) end)
CSYONS25r:add_toggle("Halloween Unlocks", function() return globals.get_boolean(HA1) end, function(value) globals.set_boolean(HA1,value) globals.set_boolean(HA2,value) globals.set_boolean(HA3,value) globals.set_boolean(HA4,value) globals.set_boolean(HA5,value) globals.set_boolean(HA6,value) globals.set_boolean(HA7,value) globals.set_boolean(HA8,value) globals.set_boolean(HA9,value) globals.set_boolean(HA10,value) globals.set_boolean(HA11,value) globals.set_boolean(HA12,value) end)
CSYONS25r:add_toggle("X-mas Unlocks", function() return globals.get_boolean(XM1) end, function(value) globals.set_boolean(XM1,value) globals.set_boolean(XM2,value) globals.set_boolean(XM3,value) globals.set_boolean(XM4,value) globals.set_boolean(XM5,value) globals.set_boolean(XM6,value) globals.set_boolean(XM7,value) globals.set_boolean(XM8,value) globals.set_boolean(XM9,value) globals.set_boolean(XM10,value) globals.set_boolean(XM11,value) globals.set_boolean(XM12,value) globals.set_boolean(XM13,value) globals.set_boolean(XM14,value) globals.set_boolean(XM15,value) globals.set_boolean(XM16,value) globals.set_boolean(XM17,value) globals.set_boolean(XM18,value) globals.set_boolean(XM19,value) globals.set_boolean(XM20,value) globals.set_boolean(XM21,value) globals.set_boolean(XM22,value) globals.set_boolean(XM23,value) globals.set_boolean(XM24,value) globals.set_boolean(XM25,value) globals.set_boolean(XM26,value) globals.set_boolean(XM27,value) globals.set_boolean(XM28,value) globals.set_boolean(XM29,value) globals.set_boolean(XM30,value) globals.set_boolean(XM31,value) globals.set_boolean(XM32,value) globals.set_boolean(XM33,value) globals.set_boolean(XM34,value) globals.set_boolean(XM35,value) globals.set_boolean(XM36,value) globals.set_boolean(XM37,value) globals.set_boolean(XM38,value) globals.set_boolean(XM39,value) globals.set_boolean(XM40,value) globals.set_boolean(XM41,value) globals.set_boolean(XM42,value) globals.set_boolean(XM43,value) for i = SS1, XM44 do globals.set_boolean(i,value) end for i = XM45, XM46 do globals.set_boolean(i, value) end globals.set_boolean(XM47,value) globals.set_boolean(XM48,value) end) 
CSYONS25r:add_toggle("Toggle Snow", function() return globals.get_boolean(SN1) end, function(value) globals.set_boolean(SN1,value) end)
CSYONS25r:add_toggle("Unlock Caps", function() return globals.get_boolean(CA1) end, function(value) globals.set_boolean(CA1,value) globals.set_boolean(CA2,value) globals.set_boolean(CA3,value) globals.set_boolean(CA4,value) globals.set_boolean(CA5,value) globals.set_boolean(CA6,value) globals.set_boolean(CA7,value) globals.set_boolean(CA8,value) end)
CSYONS25r:add_toggle("Unlock Hats", function() return globals.get_boolean(HA1) end, function(value) for i = HA1, HA2 do globals.set_boolean(i,value) end end)
CSYONS25r:add_toggle("Unlock Brand Shirts", function() return globals.get_boolean(BS1) end, function(value) for i = BS1, BS2 do globals.set_boolean(i,value) end for j = BS3, BS4 do globals.set_boolean(j,value) end for k = BS5, BS6 do globals.set_boolean(k,value) end for l = BS7, BS8 do globals.set_boolean(l,value) end globals.set_boolean(BS9,value) globals.set_boolean(BS10,value) globals.set_boolean(BS11,value) globals.set_boolean(BS12,value) globals.set_boolean(BS13,value) end)
CSYONS25r:add_toggle("Unlock Knock Offs T-shirts", function() return globals.get_boolean(KT1) end, function(value) for i = KT1, KT2 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Unlock Manufactures Clothing", function() return globals.get_boolean(MC1) end, function(value) globals.set_boolean(MC1,value) for i = MC2, MC3 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Unlock Movie Shirts", function() return globals.get_boolean(MS1) end, function(value) globals.set_boolean(MS2,value) for i = MS1, MS3 do globals.set_boolean(i,value) end for j = MS4, MS5 do globals.set_boolean(j,value) end end)
CSYONS25r:add_toggle("Unlock Radio Station T-shirts", function() return globals.get_boolean(RS1) end, function(value) globals.set_boolean(RS1,value) globals.set_boolean(RS2,value) globals.set_boolean(RS3,value) globals.set_boolean(RS4,value) globals.set_boolean(RS5,value) globals.set_boolean(RS6,value) globals.set_boolean(RS7,value) for i = RS8, RS9 do globals.set_boolean(i,value) end end)
CSYONS25r:add_toggle("Unlock Clubs T-shirts", function() return globals.get_boolean(CT1) end, function(value) for i = CT1, CT2 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Unlock DJ T-shirts", function() return globals.get_boolean(DT1) end, function(value) for i = DT1, DT2 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Unlock Hoodies", function() return globals.get_boolean(HO1) end, function(value) globals.set_boolean(HO1,value) globals.set_boolean(HO2,value) globals.set_boolean(HO3,value) globals.set_boolean(HO4,value) globals.set_boolean(HO5,value) globals.set_boolean(HO6,value) globals.set_boolean(HO7,value) globals.set_boolean(HO8,value) end)
CSYONS25r:add_toggle("Unlock Shirts", function() return globals.get_boolean(SH1) end, function(value) globals.set_boolean(SH1,value) globals.set_boolean(SH2,value) globals.set_boolean(SH3,value) globals.set_boolean(SH4,value) globals.set_boolean(SH5,value) globals.set_boolean(SH6,value) globals.set_boolean(SH7,value) globals.set_boolean(SH8,value) globals.set_boolean(SH9,value) globals.set_boolean(SH10,value) globals.set_boolean(SH11,value) globals.set_boolean(SH12,value) for i = HO8, SH13 do globals.set_boolean(i,value) end end)
CSYONS25r:add_toggle("Unlock Wireframe Bodysuits", function() return globals.get_boolean(WB1) end, function(value) for i = WB1, WB2 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Unlock Stunt Suits", function() return globals.get_boolean(SS1) end, function(value) for i = SS1, SS2 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Arena Clothing", function() return globals.get_boolean(AC1) end, function(value) for i = AC1, AC2 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Arcade and Casino Clothing", function() return globals.get_boolean(AR1) end, function(value) for i = AR1, AR2 do globals.set_boolean(i,value) end for j = AR3, AR4 do globals.set_boolean(j,value) end end)
CSYONS25r:add_toggle("LS Summer DLC Clothing", function() return globals.get_boolean(LS1) end, function(value) for i = LS1, LS2 do globals.set_boolean(i,value) end end)
CSYONS25r:add_toggle("LS Tuners DLC Clothing", function() return globals.get_boolean(LT1) end, function(value) globals.set_int(LT1,1) for i = LT2, LT3 do globals.set_boolean(i,value) end for j = LT4, LT5 do globals.set_boolean(j,value) end end)
CSYONS25r:add_toggle("Cayo Perico DLC Clothing", function() return globals.get_boolean(CP1) end, function(value) for i = CP1, CP2 do globals.set_boolean(i,value) end for j = CP3, CP4 do globals.set_boolean(j,value) end for l = CP5, CP6 do globals.set_boolean(l,value) end end)
CSYONS25r:add_int_range("Get All Clothing", 1, 1, 4, function() return 1 end, function(CSYONSUB)

	if CSYONSUB == 1 then
 stats.set_int(MPX() .. "DCTL_WINS", 500)
 stats.set_int(MPX() .. "DCTL_PLAY_COUNT", 750)
 stats.set_bool(MPX() .. "FILM4SHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "FILM5SHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "FILM6SHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "FILM7SHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "FILM8SHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "FILM9SHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "ACCOUNTANTSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "UNLOCK_RACE_HIPSTER_TSHIRT", true)
 stats.set_bool(MPX() .. "UNLOCK_DM_HIPSTER_TSHIRT", true)
 stats.set_bool(MPX() .. "UNLOCK_HIPSTER_TSHIRT_DOG", true)
 stats.set_bool(MPX() .. "UNLOCK_HIPSTER_TSHIRT_VINYL", true)
 stats.set_bool(MPX() .. "UNLOCK_HIPSTER_TSHIRT_MESS", true)
 stats.set_bool(MPX() .. "BAHAMAMAMASHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "DRONESHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "GROTTISHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "GOLFSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "MAISONETTESHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "MANOPAUSESHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "MELTDOWNSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "PACIFICBLUFFSSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "CSYONS26LAPSSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "TENNISSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "TOESHOESSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "VANILLAUNICORNSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "MARLOWESHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "CRESTSHIRTUNLOCK", true)
	for i = 0, 250 do
 stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_"..i, -1)
	end
	elseif CSYONSUB == 2 then
	for i = 1, 6 do
 for k = 1, 10 do
 for j = 1, 7 do
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_BERD", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_DECL", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_FEET", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_JBIB", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_LEGS", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_OUTFIT", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL2", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL2_1", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_TORSO", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_TEETH", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_TEETH_1", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_TEETH_2", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_BERD_"..i, -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_FEET_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_JBIB_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_LEGS_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS_"..k, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_DECL", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_FEET", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_HAIR", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_JBIB", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_LEGS", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_BERD", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_OUTFIT", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL2", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL2_1", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_TEETH", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_TEETH_1", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_TEETH_2", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_TORSO", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_BERD_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_FEET_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_HAIR_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_JBIB_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_LEGS_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS_"..k, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_HAIR", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_HAIR_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_JBIB", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_JBIB_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_LEGS", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_LEGS_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_FEET", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_FEET_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_BERD", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_BERD_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_CSYONS26PS", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_CSYONS26PS_"..k, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_OUTFIT", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_TORSO", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_SPECIAL", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_SPECIAL_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_SPECIAL2", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_SPECIAL2_1", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_DECL", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_TEETH", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_TEETH_1", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_TEETH_2", -1)
end
end
end
	elseif CSYONSUB == 3 then
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_1_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_2_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_3_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_4_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_5_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_6_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_7_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_8_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_9_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_10_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_11_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_1_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_2_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_3_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_4_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_5_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_6_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_7_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_8_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_9_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_10_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_11_OWNED", -1)
	for i = 0, 250 do
 stats.set_int(MPX() .. "DLC_APPAREL_USED_"..i, -1)
	end
elseif CSYONSUB == 4 then
	for i = 1, 40 do
 stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_"..i, -1)
 stats.set_int(MPX() .. "ADMIN_CLOTHES_RM_BS_"..i, -1)
	end
end
end)

mainMenu3:add_action("------------------------------------------------------", function() end)
Offlinex64 = mainMenu3:add_submenu("          	**💬 Read Me 💬**                        ")
mainMenu3:add_action("------------------------------------------------------", function() end)
local function Text(text)
	Offlinex64:add_action(text,  function() end)
end

--────────────────────────────────────────────────────────────────────────────────────────
--─██████████████─██████████████─████████──████████─██████████████─██████──────────██████─
--─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░██████████──██░░██─
--─██░░██████████─██░░██████████─████░░██──██░░████─██░░██████░░██─██░░░░░░░░░░██──██░░██─
--─██░░██─────────██░░██───────────██░░░░██░░░░██───██░░██──██░░██─██░░██████░░██──██░░██─
--─██░░██─────────██░░██████████───████░░░░░░████───██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────██░░░░░░░░░░██─────████░░████─────██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────██████████░░██───────██░░██───────██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────────────██░░██───────██░░██───────██░░██──██░░██─██░░██──██░░██████░░██─
--─██░░██████████─██████████░░██───────██░░██───────██░░██████░░██─██░░██──██░░░░░░░░░░██─
--─██░░░░░░░░░░██─██░░░░░░░░░░██───────██░░██───────██░░░░░░░░░░██─██░░██──██████████░░██─
--─██████████████─██████████████───────██████───────██████████████─██████──────────██████─
--────────────────────────────────────────────────────────────────────────────────────────