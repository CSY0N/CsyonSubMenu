-----------------------------------------
---- Hud Banner Display Credits to and by Quad_Plex ----
-----------------------------------------
--For GXT Labels look here:
--https://github.com/root-cause/v-labels/blob/master/labels.json
--not every label will work with this display but many short ones do
 
--func_15518 gta 2499
base_offset = 2672524 + 2514 + 1
displayboxtype = 112
--109/112 doesn't play a sound so they're good for just displaying stuff
-- in general many of these boxes have different designs/sounds so try around a bit
--10 displays my name (or 'undefined'? lol not sure how to control this)
--9 fades in from black (as do many others)
 
--Useful gfx strings:
--AMCH_KMHN             - number with 'km/h'
--FM_AE_SORT_3          - 'Speed'
--MBA_YES               - 'yes'
--MBA_NO                - 'no'
--IAA_LAUNCH            - 'Launch'
--PIM_NCL_PRIV0         - 'disabled'
--PIM_NCL_PRIV1         - 'enabled'
--CANNON_CAM_ACTIVE     - 'Active'
--CANNON_CAM_INACTIVE   - 'Inactive'
--FM_ISC_RAT1           - number with percent symbol
--FMMC_NO               - just the given number
--CELL_840              - 'Default'
--MO_CCONF_2            - 'Alternate'
--BLIP_125              - 'Vehicle Spawn'
--RESPAWN_W             - Red 'Wasted' text
--BLIP_3                - 'Police'
--PM_UCON_T32           - 'Off the Radar'
--GB_TICK_MC_FHE        - 'Health bonus activated'
--CHEAT_HEALTH_ARMOR    - 'Max health and armor.'
--PIM_FULL1             - 'Full Ammo'
--BLIP_402              - 'Repair'
--GREEN_LIV5            - 'Invincible'
--GBC_HUD_VH            - 'Vehicle Health'
--VEUI_SHAKE_EXPLOSION  - 'Explosion'
--PSF_FLYING            - 'Flying +'
--FM_PLY_CHEAT          - 'CHEATER'
--GBC_STPASS_CHE        - 'Cheaters caught'
--LOSE_WANTED           - 'Lose the Cops'
--LEST_NCOPS            - 'COPS TURN BLIND EYE'
--FGTXT_F_F3            - 'fuck you' lmao love this one
--VVHUD_GHOST           - 'Ghost'
--PIM_GS_09             - 'Protection'
--FACE_F_FAT            - 'Fat'
--FMSTP_PRCL3           - 'Vehicle'
--HUD_RANDOM            - 'Random'
 
--Credits to Kiddion for finding this stuff in an older version
--https://www.unknowncheats.me/forum/3523555-post2032.html
function displayHudBanner(headline, subheadline, number, box_type)
    if localplayer == nil then
        return
    end
 
    globals.set_string(base_offset + 21, headline, 16)
    globals.set_string(base_offset + 8, subheadline, 32)
    if number ~= "" then
        globals.set_int(base_offset + 3, number)
    end
 
 
    globals.set_int(base_offset + 1, box_type)
    globals.set_int(base_offset + 2, 1)
end
 
--Janky Speedometer implementation
constantupdate = false
function OnScriptsLoaded()
    while true do
        if constantupdate then
            local myplayer = player.get_player_ped()
            local current_vehicle = myplayer:get_current_vehicle()
            if current_vehicle == nil or not myplayer:is_in_vehicle() then
                return
            end
            local velocity = current_vehicle:get_velocity()
            abs_velocity = math.sqrt(velocity.x * velocity.x + velocity.y * velocity.y + velocity.z * velocity.z)
            if constantupdate then
                displayHudBanner("FM_AE_SORT_3", "AMCH_KMHN", math.floor(3.6 * abs_velocity), 109)
            end
        end
        sleep(0.2)
    end
end
menu.register_callback('OnScriptsLoaded', OnScriptsLoaded)